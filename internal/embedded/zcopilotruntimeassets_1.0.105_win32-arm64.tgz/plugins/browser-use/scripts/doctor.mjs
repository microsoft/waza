#!/usr/bin/env node
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};

// <define:__COPILOT_BROWSER_PLUGIN_CHANNEL__>
var define_COPILOT_BROWSER_PLUGIN_CHANNEL_default;
var init_define_COPILOT_BROWSER_PLUGIN_CHANNEL = __esm({
  "<define:__COPILOT_BROWSER_PLUGIN_CHANNEL__>"() {
    define_COPILOT_BROWSER_PLUGIN_CHANNEL_default = { channel: "production", productId: "github-copilot-browser", nativeMessagingHostName: "com.github.copilot.browser", extensionId: "hblomdgalaelcilcdepgohfcogjiijhe", extensionName: "GitHub Copilot", extensionInstallUrls: { chromeWebStore: "https://chromewebstore.google.com/detail/github-copilot/hblomdgalaelcilcdepgohfcogjiijhe" }, advancedPageSurfaces: true, extensionPublicKey: "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA08x5MXlp8uHflF+U7A/JPom4nno762WERnUs48S0+BqvlJTgGtyz1MaSVu4na61vaPelmBBAq40MAp2gzH4i4jK5AQBjHIkBm8sTe1ClAvJu9BiA4zxAm/lbyTPZjJTE2IbRIKVSiZs83UP31qwMJpwi3XmkgH4prWXH+IvNRSy985+hcZb25goCLk93WtbQDJDjYnLXzSZR3qyc/+KqZlcQ03lSGPjuKsyCZmG4e5Au7KNMG8PJuQPTAE+eO7BL3of6oJiLqyARj6KEDOWctREeLxqVhq9fp3MbuLBj9RxhvfJuUhYwIl+FpPuHc5wUzPOiJUDTtTVvHDZde2SigwIDAQAB" };
  }
});

// shared/browser-rpc/src/productIdentifiers.ts
var PRODUCT_ID;
var init_productIdentifiers = __esm({
  "shared/browser-rpc/src/productIdentifiers.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    PRODUCT_ID = true ? "github-copilot-browser" : "github-copilot-browser";
  }
});

// shared/browser-rpc/src/node/localEndpointDiscovery.ts
import { lstat, opendir, readFile } from "node:fs/promises";
import { homedir, tmpdir } from "node:os";
import { isAbsolute, join } from "node:path";
function localEndpointDirectory() {
  const override = process.env[RUNTIME_DIRECTORY_ENV];
  if (override !== void 0) {
    if (!isAbsolute(override)) {
      throw new Error(`${RUNTIME_DIRECTORY_ENV} must be an absolute path.`);
    }
    return override;
  }
  if (process.platform === "win32") {
    const localAppData = process.env.LOCALAPPDATA;
    const base2 = localAppData && isAbsolute(localAppData) ? localAppData : join(homedir(), "AppData", "Local");
    return join(base2, "GitHub", "Copilot Browser", "runtime");
  }
  const xdgRuntimeDirectory = process.env.XDG_RUNTIME_DIR;
  const useXdgRuntimeDirectory = xdgRuntimeDirectory !== void 0 && isAbsolute(xdgRuntimeDirectory);
  const base = useXdgRuntimeDirectory ? xdgRuntimeDirectory : tmpdir();
  const userSuffix = process.getuid === void 0 ? "" : `-${process.getuid()}`;
  return join(base, `${UNIX_RUNTIME_DIRECTORY_NAME}${useXdgRuntimeDirectory ? "" : userSuffix}`);
}
function localEndpointAddress(endpointId) {
  validateLocalEndpointId(endpointId);
  if (process.platform === "win32") {
    return `${WINDOWS_PIPE_ROOT}${PRODUCT_ID}-${endpointId}`;
  }
  return createUnixSocketAddress(localEndpointDirectory(), endpointId, UNIX_SOCKET_PATH_LIMIT);
}
function createUnixSocketAddress(runtimeDirectory, endpointId, pathLimit) {
  validateLocalEndpointId(endpointId);
  const token = endpointId.replaceAll("-", "");
  const fixedBytes = Buffer.byteLength(join(runtimeDirectory, ".sock"));
  const availableTokenBytes = pathLimit - 1 - fixedBytes;
  if (availableTokenBytes < MINIMUM_SOCKET_TOKEN_LENGTH) {
    throw new Error(`Local IPC path cannot fit within the ${pathLimit}-byte platform limit.`);
  }
  const address = join(
    runtimeDirectory,
    `${token.slice(0, Math.min(token.length, availableTokenBytes))}.sock`
  );
  if (Buffer.byteLength(address) >= pathLimit) {
    throw new Error(`Local IPC path exceeds the ${pathLimit}-byte platform limit.`);
  }
  return address;
}
async function discoverLocalEndpointDescriptorRecords() {
  const directory = localEndpointDirectory();
  let entries;
  try {
    entries = await opendir(directory);
  } catch {
    return [];
  }
  const records = [];
  let scanned = 0;
  for await (const entry of entries) {
    scanned += 1;
    if (scanned > MAX_DESCRIPTOR_FILES_SCANNED) break;
    if (!entry.isFile() || !entry.name.endsWith(DESCRIPTOR_SUFFIX)) continue;
    const descriptor = await readDescriptor(directory, entry.name);
    if (!descriptor) continue;
    records.push({ descriptor, processState: classifyLocalEndpointProcess(descriptor.pid) });
  }
  return records.sort((left, right) => right.descriptor.createdAt - left.descriptor.createdAt);
}
function classifyLocalEndpointProcess(pid) {
  try {
    process.kill(pid, 0);
    return "running";
  } catch (error) {
    return isErrorCode(error, "ESRCH") ? "missing" : "unknown";
  }
}
function validateLocalEndpointDiagnostics(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError("Endpoint diagnostics must be an object.");
  }
  const diagnostics = value;
  const requiredKeys = ["browserRpcVersion", "nativeHostVersion", "installationId"];
  const optionalKeys = ["extensionId", "extensionInstanceId", "extensionVersion"];
  if (Object.keys(diagnostics).some((key) => ![...requiredKeys, ...optionalKeys].includes(key))) {
    throw new TypeError("Endpoint diagnostics contain unsupported fields.");
  }
  if (typeof diagnostics.browserRpcVersion !== "number" || !Number.isSafeInteger(diagnostics.browserRpcVersion) || diagnostics.browserRpcVersion <= 0) {
    throw new TypeError("Endpoint diagnostics contain an invalid Browser RPC version.");
  }
  if (!isBoundedString(diagnostics.nativeHostVersion, 128)) {
    throw new TypeError("Endpoint diagnostics contain an invalid Native Host version.");
  }
  if (typeof diagnostics.installationId !== "string" || !/^[0-9a-f]{64}$/iu.test(diagnostics.installationId)) {
    throw new TypeError("Endpoint diagnostics contain an invalid Installation identity.");
  }
  for (const key of optionalKeys) {
    if (diagnostics[key] !== void 0 && !isBoundedString(diagnostics[key], 256)) {
      throw new TypeError(`Endpoint diagnostics contain an invalid ${key}.`);
    }
  }
  return value;
}
function validateLocalEndpointId(endpointId) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(endpointId)) {
    throw new TypeError("endpointId must be a UUID v4 value.");
  }
}
async function readDescriptor(directory, name) {
  const path = join(directory, name);
  try {
    const info = await lstat(path);
    if (!info.isFile() || info.isSymbolicLink() || info.size > LOCAL_ENDPOINT_DESCRIPTOR_MAX_BYTES) {
      return void 0;
    }
    if (process.platform !== "win32" && (info.uid !== process.getuid?.() || (info.mode & 63) !== 0)) {
      return void 0;
    }
    const value = JSON.parse(await readFile(path, "utf8"));
    if (!isEndpointDescriptor(value) || name !== `${value.endpointId}${DESCRIPTOR_SUFFIX}`) {
      return void 0;
    }
    return value.address === localEndpointAddress(value.endpointId) ? value : void 0;
  } catch {
    return void 0;
  }
}
function isEndpointDescriptor(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const descriptor = value;
  if (descriptor.schemaVersion !== LOCAL_ENDPOINT_DESCRIPTOR_SCHEMA_VERSION || typeof descriptor.endpointId !== "string" || typeof descriptor.address !== "string" || !Number.isSafeInteger(descriptor.pid) || descriptor.pid <= 0 || !Number.isSafeInteger(descriptor.createdAt) || descriptor.createdAt <= 0) {
    return false;
  }
  if (descriptor.diagnostics === void 0) return true;
  try {
    validateLocalEndpointDiagnostics(descriptor.diagnostics);
    return true;
  } catch {
    return false;
  }
}
function isBoundedString(value, maxLength) {
  return typeof value === "string" && value.length > 0 && value.length <= maxLength;
}
function isErrorCode(error, code) {
  return error !== null && typeof error === "object" && "code" in error && error.code === code;
}
var LOCAL_ENDPOINT_DESCRIPTOR_MAX_BYTES, LOCAL_ENDPOINT_DESCRIPTOR_SCHEMA_VERSION, DESCRIPTOR_SUFFIX, MAX_DESCRIPTOR_FILES_SCANNED, WINDOWS_PIPE_ROOT, UNIX_SOCKET_PATH_LIMIT, UNIX_RUNTIME_DIRECTORY_NAME, MINIMUM_SOCKET_TOKEN_LENGTH, RUNTIME_DIRECTORY_ENV;
var init_localEndpointDiscovery = __esm({
  "shared/browser-rpc/src/node/localEndpointDiscovery.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_productIdentifiers();
    LOCAL_ENDPOINT_DESCRIPTOR_MAX_BYTES = 4 * 1024;
    LOCAL_ENDPOINT_DESCRIPTOR_SCHEMA_VERSION = 1;
    DESCRIPTOR_SUFFIX = ".json";
    MAX_DESCRIPTOR_FILES_SCANNED = 1024;
    WINDOWS_PIPE_ROOT = "\\\\.\\pipe\\";
    UNIX_SOCKET_PATH_LIMIT = process.platform === "darwin" ? 103 : 107;
    UNIX_RUNTIME_DIRECTORY_NAME = "gcb";
    MINIMUM_SOCKET_TOKEN_LENGTH = 20;
    RUNTIME_DIRECTORY_ENV = "COPILOT_BROWSER_RUNTIME_DIR";
  }
});

// plugin/shared/scripts/doctor.mjs
init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
init_localEndpointDiscovery();
import { execFile as execFile4 } from "node:child_process";
import { createHash as createHash2 } from "node:crypto";
import { once } from "node:events";
import { readFile as readFile5 } from "node:fs/promises";
import { connect } from "node:net";
import { platform as platform3 } from "node:os";
import { join as join5 } from "node:path";
import { promisify as promisify4 } from "node:util";

// plugin/shared/scripts/browserPrerequisites.mjs
init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
import { execFile as execFile2 } from "node:child_process";
import { lstat as lstat2, readFile as readFile3, readdir } from "node:fs/promises";
import { homedir as homedir3, platform as platform2 } from "node:os";
import { isAbsolute as isAbsolute3, join as join3, resolve as resolve2 } from "node:path";
import { promisify as promisify2 } from "node:util";

// plugin/shared/scripts/pluginPlan.mjs
init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile as readFile2, stat } from "node:fs/promises";
import { homedir as homedir2, platform } from "node:os";
import { dirname, isAbsolute as isAbsolute2, join as join2, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

// plugin/shared/.plugin/plugin.json
var plugin_default = {
  name: "browser-use",
  description: "GitHub Copilot Browser Use plugin.",
  version: "0.0.4",
  author: {
    name: "GitHub"
  },
  mcpServers: ".mcp.json",
  skills: "skills",
  postInstallMessage: "Load the matching GitHub Copilot extension, then start a new session. If the extension is not installed or enabled, use `/browser-use:doctor` for channel-appropriate installation guidance. Browser registration activates automatically at session start, and Browser guidance loads automatically when needed. Use `/browser-use:activate` to activate this installation immediately or repair setup, `/browser-use:doctor` for diagnostics, and `/browser-use:deactivate` before uninstalling or replacing this installation."
};

// plugin/dev/channel.json
var channel_default = {
  channel: "dev",
  productId: "github-copilot-browser-dev",
  nativeMessagingHostName: "com.github.copilot.browser.dev",
  extensionId: "dpkmommpdhajlaebcicbbmfdmkohmehi",
  extensionName: "GitHub Copilot",
  advancedPageSurfaces: true,
  extensionPublicKey: "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0FaW7/YkDngCegAuXXxhhP72dJ3cERtCgXZ4oRLAzUU7yU2YTH7P/9pBvGcI7fhZKU0FvMtvGcakDnA5+5W7bcUlWx8R3oNSQe1OcTRDqk9yayKUnQb4I83yogkF2tWzsnt3sQNn/LzSFeXVWAYINLvhJ7O0dKJoh1rVH2/TzSkumq7Ey4OHb0bIefWYwJUEFXGj+F5amYDj4NowjekJTL1aiOAIj44xrLn06LvzYF3B58fqKgJzbBpuKjUbm5igCN/oydnlxc6SUaBhx6ilLAt/kFLzGnlkM9/l2h95RyJlvSYLcYhoWM6/R6IdqyE11s/aOGt3y/QIPgU6HuQnnwIDAQAB"
};

// plugin/shared/scripts/pluginPlan.mjs
var pluginRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
var execFileAsync = promisify(execFile);
var channel = typeof define_COPILOT_BROWSER_PLUGIN_CHANNEL_default === "object" ? define_COPILOT_BROWSER_PLUGIN_CHANNEL_default : channel_default;
var installRootEnvironment = `COPILOT_BROWSER_${channel.channel.replaceAll("-", "_").toUpperCase()}_INSTALL_ROOT`;
var PluginUserError = class extends Error {
};
function parsePluginVersion(value) {
  const match = /^(\d+(?:\.\d+){2,3})(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(
    value
  );
  if (!match) throw new PluginUserError("The plugin version is invalid.");
  const coreParts = match[1].split(".");
  const prerelease = match[2]?.split(".");
  if ([...coreParts, ...prerelease ?? []].some(
    (part) => /^\d+$/.test(part) && (part.length > 1 && part.startsWith("0") || !Number.isSafeInteger(Number(part)))
  )) {
    throw new PluginUserError("The plugin version is invalid.");
  }
  return { core: coreParts.map(Number), prerelease };
}
function comparePluginVersions(left, right) {
  const leftVersion = parsePluginVersion(left);
  const rightVersion = parsePluginVersion(right);
  const coreLength = Math.max(leftVersion.core.length, rightVersion.core.length);
  for (let index = 0; index < coreLength; index += 1) {
    const difference = (leftVersion.core[index] ?? 0) - (rightVersion.core[index] ?? 0);
    if (difference !== 0) return Math.sign(difference);
  }
  if (!leftVersion.prerelease && !rightVersion.prerelease) return 0;
  if (!leftVersion.prerelease) return 1;
  if (!rightVersion.prerelease) return -1;
  const length = Math.max(leftVersion.prerelease.length, rightVersion.prerelease.length);
  for (let index = 0; index < length; index += 1) {
    const leftPart = leftVersion.prerelease[index];
    const rightPart = rightVersion.prerelease[index];
    if (leftPart === void 0) return -1;
    if (rightPart === void 0) return 1;
    if (leftPart === rightPart) continue;
    const leftNumber = numericVersionIdentifier(leftPart);
    const rightNumber = numericVersionIdentifier(rightPart);
    if (leftNumber !== void 0 && rightNumber !== void 0) {
      return Math.sign(leftNumber - rightNumber);
    }
    if (leftNumber !== void 0) return -1;
    if (rightNumber !== void 0) return 1;
    return leftPart < rightPart ? -1 : 1;
  }
  return 0;
}
function numericVersionIdentifier(value) {
  if (!/^\d+$/.test(value)) return void 0;
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed)) throw new PluginUserError("The plugin version is invalid.");
  return parsed;
}
async function createRegistrationPlan() {
  const distDirectory = join2(pluginRoot, "dist");
  const sourceNativeHostBundle = join2(distDirectory, "native-host.cjs");
  const sourceBundle = await readRequiredFile(sourceNativeHostBundle);
  const bundleSha256 = createHash("sha256").update(sourceBundle).digest("hex");
  const installationSha256 = createHash("sha256").update(sourceBundle).update("\0").update(platform()).update("\0").update(normalizePath(pluginRoot)).digest("hex");
  const installRoot = pluginInstallRoot();
  const version = validateVersion(plugin_default.version);
  const versionDirectory = join2(installRoot, "versions", `${version}-${installationSha256}`);
  const nativeHostBundle = join2(versionDirectory, "native-host.cjs");
  const launcherPath = join2(
    versionDirectory,
    platform() === "win32" ? "native-host.bat" : "native-host"
  );
  const manifest = {
    name: channel.nativeMessagingHostName,
    description: "GitHub Copilot Browser Native Messaging Host",
    path: launcherPath,
    type: "stdio",
    allowed_origins: [`chrome-extension://${channel.extensionId}/`]
  };
  const manifestPaths = nativeMessagingManifestPaths(installRoot);
  const registryKey = platform() === "win32" ? `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${channel.nativeMessagingHostName}` : void 0;
  return {
    channel: channel.channel,
    hostName: channel.nativeMessagingHostName,
    extensionId: channel.extensionId,
    pluginRoot,
    sourceNativeHostBundle,
    bundleSha256,
    installationSha256,
    installRoot,
    version,
    versionDirectory,
    activeInstallationPath: join2(installRoot, "active-installation.json"),
    pendingInstallationPath: join2(installRoot, "pending-installation.json"),
    activationLockPath: join2(installRoot, ".activation-lock"),
    nativeHostBundle,
    launcherPath,
    manifestPaths,
    registryKey,
    manifest
  };
}
function launcherContent(nativeHostBundle, installationId, productVersion) {
  if (!/^[0-9a-f]{64}$/u.test(installationId)) {
    throw new PluginUserError("The Browser installation identity is invalid.");
  }
  validateVersion(productVersion);
  if (platform() === "win32") {
    return `@echo off\r
"${escapeBatchPath(process.execPath)}" "${escapeBatchPath(nativeHostBundle)}" --installation-id "${installationId}" --product-version "${productVersion}" %*\r
`;
  }
  return `#!/bin/sh
exec ${shellQuote(process.execPath)} ${shellQuote(nativeHostBundle)} --installation-id ${shellQuote(installationId)} --product-version ${shellQuote(productVersion)} "$@"
`;
}
async function launcherIsExecutable(path) {
  if (platform() === "win32") return true;
  try {
    return ((await stat(path)).mode & 64) !== 0;
  } catch (error) {
    if (isMissingFileError(error)) return false;
    throw error;
  }
}
async function readRequiredFile(path) {
  try {
    return await readFile2(path);
  } catch (error) {
    if (isMissingFileError(error)) {
      throw new PluginUserError(
        "Required Browser Use plugin files are missing. Reinstall the plugin."
      );
    }
    throw error;
  }
}
function pathsEqual(left, right) {
  const normalizedLeft = resolve(left);
  const normalizedRight = resolve(right);
  return platform() === "win32" ? normalizedLeft.toLowerCase() === normalizedRight.toLowerCase() : normalizedLeft === normalizedRight;
}
function chromiumConfigRoot(environment = process.env) {
  const configured = environment.XDG_CONFIG_HOME;
  return configured && isAbsolute2(configured) ? resolve(configured) : join2(homedir2(), ".config");
}
function manifestMatchesPlan(actual, plan) {
  return actual !== null && typeof actual === "object" && actual.name === plan.manifest.name && actual.description === plan.manifest.description && typeof actual.path === "string" && pathsEqual(actual.path, plan.launcherPath) && actual.type === plan.manifest.type && Array.isArray(actual.allowed_origins) && actual.allowed_origins.length === 1 && actual.allowed_origins[0] === plan.manifest.allowed_origins[0];
}
async function readRegistryDefaultValue(registryKey) {
  try {
    const { stdout } = await execFileAsync("reg.exe", ["query", registryKey, "/ve"], {
      windowsHide: true
    });
    return /^\s+.*?\s+REG_SZ\s+(.+)$/m.exec(stdout)?.[1]?.trim();
  } catch (error) {
    if (!isMissingRegistryKeyError(error)) throw error;
    return void 0;
  }
}
function isMissingFileError(error) {
  return isFileSystemError(error, "ENOENT");
}
function isFileSystemError(error, code) {
  return error !== null && typeof error === "object" && "code" in error && error.code === code;
}
function isMissingRegistryKeyError(error) {
  return error !== null && typeof error === "object" && "code" in error && (error.code === 1 || error.code === "1");
}
function pluginInstallRoot() {
  const override = process.env[installRootEnvironment];
  if (override !== void 0) {
    if (!isAbsolute2(override)) {
      throw new PluginUserError(`${installRootEnvironment} must be an absolute path.`);
    }
    return resolve(override);
  }
  if (platform() === "win32") {
    const localAppData = process.env.LOCALAPPDATA;
    const base2 = localAppData && isAbsolute2(localAppData) ? localAppData : join2(homedir2(), "AppData", "Local");
    return join2(base2, "GitHub", "Copilot Browser", channel.channel);
  }
  if (platform() === "darwin") {
    return join2(
      homedir2(),
      "Library",
      "Application Support",
      "GitHub",
      "Copilot Browser",
      channel.channel
    );
  }
  const xdgDataHome = process.env.XDG_DATA_HOME;
  const base = xdgDataHome && isAbsolute2(xdgDataHome) ? xdgDataHome : join2(homedir2(), ".local", "share");
  return join2(base, "github-copilot", "browser", channel.channel);
}
function nativeMessagingManifestPaths(installRoot) {
  const filename = `${channel.nativeMessagingHostName}.json`;
  if (platform() === "win32") return [join2(installRoot, filename)];
  if (platform() === "darwin") {
    return [
      join2(
        homedir2(),
        "Library",
        "Application Support",
        "Google",
        "Chrome",
        "NativeMessagingHosts",
        filename
      ),
      join2(
        homedir2(),
        "Library",
        "Application Support",
        "Microsoft Edge",
        "NativeMessagingHosts",
        filename
      )
    ];
  }
  const configRoot = chromiumConfigRoot();
  return [
    join2(configRoot, "google-chrome", "NativeMessagingHosts", filename),
    join2(configRoot, "microsoft-edge", "NativeMessagingHosts", filename)
  ];
}
function escapeBatchPath(value) {
  if (/["\r\n]/.test(value)) {
    throw new PluginUserError("The Node.js executable path is unsupported.");
  }
  return value.replaceAll("%", "%%");
}
function shellQuote(value) {
  return `'${value.replaceAll("'", `'"'"'`)}'`;
}
function validateVersion(version) {
  parsePluginVersion(version);
  return version;
}
function normalizePath(path) {
  return platform() === "win32" ? path.toLowerCase() : path;
}

// plugin/shared/scripts/browserPrerequisites.mjs
var execFileAsync2 = promisify2(execFile2);
var MINIMUM_BROWSER_MAJOR = 127;
var MAX_PROFILE_DIRECTORIES = 100;
var MAX_RPC_METADATA_BYTES = 4 * 1024;
async function diagnoseInstalledExtensions(extensionId, expectedExtensionVersion, extensionInstallUrls) {
  const installations = (await Promise.all(browserCandidates().map(detectBrowserInstallation))).filter((installation) => installation !== void 0);
  const supportedInstallations = installations.filter(
    ({ majorVersion }) => majorVersion >= MINIMUM_BROWSER_MAJOR
  );
  const browserCheck = classifyBrowserInstallations(installations);
  const extensionStates = (await Promise.all(
    supportedInstallations.map(
      ({ profileRoots }) => readExtensionStates(profileRoots, extensionId)
    )
  )).flat();
  return {
    checks: [
      browserCheck,
      ...classifyInstalledExtensionChecks(
        extensionStates,
        browserCheck.status,
        expectedExtensionVersion,
        extensionInstallUrls
      )
    ],
    states: extensionStates
  };
}
function classifyInstalledExtensionChecks(states, browserStatus, expectedExtensionVersion, extensionInstallUrls = {}) {
  return [
    classifyExtensionInstallations(states, browserStatus, extensionInstallUrls),
    classifyExtensionVersions(states, expectedExtensionVersion),
    classifyExtensionRpcVersions(states)
  ];
}
function classifyBrowserInstallations(installations) {
  if (installations.some(({ majorVersion }) => majorVersion >= MINIMUM_BROWSER_MAJOR)) {
    return prerequisiteCheck(
      "browser-prerequisite",
      "pass",
      `Chrome or Edge ${MINIMUM_BROWSER_MAJOR} or later is installed.`
    );
  }
  return prerequisiteCheck(
    "browser-prerequisite",
    "fail",
    installations.length === 0 ? `Install Chrome or Edge ${MINIMUM_BROWSER_MAJOR} or later.` : `Update Chrome or Edge to version ${MINIMUM_BROWSER_MAJOR} or later.`
  );
}
function classifyExtensionInstallations(states, browserStatus, extensionInstallUrls = {}) {
  if (states.some(({ state }) => state === "enabled")) {
    return prerequisiteCheck(
      "browser-extension",
      "pass",
      "The matching GitHub Copilot extension is enabled in a supported browser profile."
    );
  }
  if (states.some(({ state }) => state === "disabled")) {
    return prerequisiteCheck(
      "browser-extension",
      "warn",
      "Enable the matching GitHub Copilot extension in Chrome or Edge."
    );
  }
  if (states.some(({ state }) => state === "unknown")) {
    return prerequisiteCheck(
      "browser-extension",
      "warn",
      "The matching GitHub Copilot extension installation could not be verified because one or more browser profile files could not be read."
    );
  }
  const chromeWebStoreUrl = extensionInstallUrls.chromeWebStore;
  return prerequisiteCheck(
    "browser-extension",
    browserStatus === "fail" ? "warn" : "fail",
    chromeWebStoreUrl === void 0 ? "Load the matching GitHub Copilot extension in Chrome or Edge." : `Install the matching GitHub Copilot extension from the Chrome Web Store in Chrome or Edge: ${chromeWebStoreUrl}. In Edge, allow extensions from other stores if prompted. If it is already installed, enable it in Chrome or Edge.`
  );
}
function classifyExtensionVersions(states, expectedVersion) {
  const enabled = states.filter(({ state }) => state === "enabled");
  if (enabled.length === 0) {
    return prerequisiteCheck(
      "browser-extension-version",
      "warn",
      states.some(({ state }) => state === "unknown") ? "The Browser extension version could not be verified because its installation state could not be read." : states.some(({ state }) => state === "disabled") ? "Enable the matching GitHub Copilot extension before its version can be verified." : "Install and enable the matching GitHub Copilot extension before its version can be verified."
    );
  }
  const versions = [
    ...new Set(
      enabled.filter(({ version }) => version !== void 0).map(({ version }) => version)
    )
  ];
  if (versions.length === 0) {
    return prerequisiteCheck(
      "browser-extension-version",
      "warn",
      "The enabled Browser extension version could not be verified. Update the matching extension if Browser does not connect."
    );
  }
  const relation = versions.map((version) => compareVersions(version, expectedVersion));
  if (relation.every((comparison) => comparison === 0)) {
    return prerequisiteCheck(
      "browser-extension-version",
      "pass",
      `The enabled Browser extension matches plugin version ${expectedVersion}.`
    );
  }
  if (relation.every((comparison) => comparison < 0)) {
    return prerequisiteCheck(
      "browser-extension-version",
      "warn",
      `The enabled Browser extension is older than plugin version ${expectedVersion}. Update the matching extension.`
    );
  }
  if (relation.every((comparison) => comparison > 0)) {
    return prerequisiteCheck(
      "browser-extension-version",
      "warn",
      `The enabled Browser extension is newer than plugin version ${expectedVersion}. Update the Browser Use plugin.`
    );
  }
  return prerequisiteCheck(
    "browser-extension-version",
    "warn",
    `Enabled browser profiles use different Browser extension versions; not all match plugin version ${expectedVersion}. Update the older side.`
  );
}
function classifyExtensionRpcVersions(states) {
  const enabled = states.filter(({ state }) => state === "enabled");
  if (enabled.length === 0) {
    return prerequisiteCheck(
      "browser-extension-rpc-version",
      "warn",
      states.some(({ state }) => state === "unknown") ? "The Browser extension RPC version could not be verified because its installation state could not be read." : states.some(({ state }) => state === "disabled") ? "Enable the matching GitHub Copilot extension before its RPC version can be verified." : "Install and enable the matching GitHub Copilot extension before its RPC version can be verified."
    );
  }
  const allVersionsKnown = enabled.every(({ rpcVersion }) => rpcVersion !== void 0);
  const versions = [
    ...new Set(
      enabled.map(({ rpcVersion }) => rpcVersion).filter((version) => version !== void 0)
    )
  ];
  if (!allVersionsKnown) {
    return prerequisiteCheck(
      "browser-extension-rpc-version",
      "warn",
      "The enabled Browser extension RPC version could not be verified."
    );
  }
  if (versions.length === 1) {
    return prerequisiteCheck(
      "browser-extension-rpc-version",
      "pass",
      `The enabled Browser extension reports RPC version ${versions[0]}.`
    );
  }
  return prerequisiteCheck(
    "browser-extension-rpc-version",
    "warn",
    "Enabled browser profiles report different Browser RPC versions."
  );
}
function firstIncompatibleExtensionRpcVersion(states, expectedVersion) {
  return states.filter(({ state }) => state === "enabled").map(({ rpcVersion }) => rpcVersion).find((version) => version !== void 0 && version !== expectedVersion);
}
function compareVersions(left, right) {
  try {
    return comparePluginVersions(left, right);
  } catch {
    return left === right ? 0 : Number.NaN;
  }
}
function parseBrowserMajorVersion(value) {
  const match = /(?:(?:Chrome|Chromium|Edge)\/?\s*)?(\d+)(?:\.\d+){1,3}/iu.exec(value);
  return match ? Number.parseInt(match[1], 10) : void 0;
}
async function readExtensionStates(profileRoots, extensionId) {
  const states = [];
  for (const root of profileRoots) {
    let entries;
    try {
      entries = await readdir(root, { withFileTypes: true });
    } catch (error) {
      if (!isMissingFileError2(error)) states.push({ state: "unknown" });
      continue;
    }
    const profileDirectories = entries.filter(
      (entry) => entry.isDirectory() && (entry.name === "Default" || /^Profile \d+$/u.test(entry.name))
    ).slice(0, MAX_PROFILE_DIRECTORIES).map((entry) => join3(root, entry.name));
    for (const profileDirectory of profileDirectories) {
      let foundSettings = false;
      let unreadablePreferences = false;
      for (const filename of ["Secure Preferences", "Preferences"]) {
        try {
          const preferences = JSON.parse(
            await readFile3(join3(profileDirectory, filename), "utf8")
          );
          const settings = preferences?.extensions?.settings?.[extensionId];
          if (settings !== void 0) {
            foundSettings = true;
            const extensionRoot = await resolveInstalledExtensionRoot(
              settings,
              profileDirectory,
              extensionId
            );
            if (extensionRoot !== void 0) {
              const disabled = settings.state === 0 || Array.isArray(settings.disable_reasons) && settings.disable_reasons.length > 0 || typeof settings.disable_reasons === "number" && settings.disable_reasons !== 0;
              states.push({
                state: disabled ? "disabled" : "enabled",
                ...await readExtensionMetadata(settings, extensionRoot)
              });
            }
            break;
          }
        } catch (error) {
          if (!isMissingFileError2(error)) {
            unreadablePreferences = true;
            if (filename === "Secure Preferences") break;
          }
        }
      }
      if (!foundSettings && unreadablePreferences) states.push({ state: "unknown" });
    }
  }
  return states;
}
function isMissingFileError2(error) {
  return typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT";
}
async function resolveInstalledExtensionRoot(settings, profileDirectory, extensionId) {
  const extensionsDirectory = join3(profileDirectory, "Extensions");
  if (typeof settings?.path === "string" && settings.path.trim() !== "") {
    const configuredRoot = isAbsolute3(settings.path) ? resolve2(settings.path) : resolve2(extensionsDirectory, settings.path);
    return await isDirectory(configuredRoot) ? configuredRoot : void 0;
  }
  const packagedRoot = join3(extensionsDirectory, extensionId);
  let entries;
  try {
    entries = await readdir(packagedRoot, { withFileTypes: true });
  } catch {
    return void 0;
  }
  const versions = entries.filter((entry) => entry.isDirectory()).map((entry) => entry.name);
  const embeddedVersion = typeof settings?.manifest?.version === "string" && settings.manifest.version.trim() !== "" ? settings.manifest.version : void 0;
  const selectedVersion = (embeddedVersion === void 0 ? void 0 : versions.filter(
    (version) => version === embeddedVersion || version.startsWith(`${embeddedVersion}_`)
  ).sort(compareChromeExtensionVersionDirectories).at(-1)) ?? versions.sort(compareChromeExtensionVersionDirectories).at(-1);
  return selectedVersion === void 0 ? void 0 : join3(packagedRoot, selectedVersion);
}
function compareChromeExtensionVersionDirectories(left, right) {
  const leftVersion = parseChromeExtensionVersionDirectory(left);
  const rightVersion = parseChromeExtensionVersionDirectory(right);
  if (leftVersion === void 0)
    return rightVersion === void 0 ? left.localeCompare(right) : -1;
  if (rightVersion === void 0) return 1;
  for (let index = 0; index < leftVersion.length; index += 1) {
    const difference = leftVersion[index] - rightVersion[index];
    if (difference !== 0) return difference;
  }
  return 0;
}
function parseChromeExtensionVersionDirectory(value) {
  const match = /^(\d+(?:\.\d+){0,3})(?:_(\d+))?$/u.exec(value);
  if (!match) return void 0;
  const version = match[1].split(".").map(Number);
  while (version.length < 4) version.push(0);
  version.push(Number(match[2] ?? 0));
  return version;
}
async function isDirectory(path) {
  try {
    return (await lstat2(path)).isDirectory();
  } catch {
    return false;
  }
}
async function readExtensionMetadata(settings, extensionRoot) {
  const embeddedVersion = settings?.manifest?.version;
  const version = typeof embeddedVersion === "string" && embeddedVersion.trim() !== "" ? embeddedVersion : void 0;
  try {
    const manifest = JSON.parse(await readFile3(join3(extensionRoot, "manifest.json"), "utf8"));
    const manifestVersion = typeof manifest?.version === "string" && manifest.version.trim() !== "" ? manifest.version : version;
    return {
      version: manifestVersion,
      rpcVersion: await readRpcVersion(extensionRoot)
    };
  } catch {
    return { version };
  }
}
async function readRpcVersion(extensionRoot) {
  try {
    const path = join3(extensionRoot, "browser-rpc.json");
    const info = await lstat2(path);
    if (!info.isFile() || info.isSymbolicLink() || info.size > MAX_RPC_METADATA_BYTES) {
      return void 0;
    }
    const content = await readFile3(path, "utf8");
    if (Buffer.byteLength(content) > MAX_RPC_METADATA_BYTES) return void 0;
    const metadata = JSON.parse(content);
    return Object.keys(metadata).length === 1 && Number.isSafeInteger(metadata.version) && metadata.version > 0 ? metadata.version : void 0;
  } catch {
    return void 0;
  }
}
async function detectBrowserInstallation(candidate) {
  for (const executable of candidate.executables) {
    try {
      const majorVersion = parseBrowserMajorVersion(await readBrowserVersion(executable));
      if (majorVersion !== void 0) {
        return { majorVersion, profileRoots: candidate.profileRoots };
      }
    } catch {
    }
  }
  return void 0;
}
async function readBrowserVersion(executable) {
  if (platform2() === "win32") {
    const { stdout: stdout2 } = await execFileAsync2(
      "powershell.exe",
      [
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-Command",
        "(Get-Item -LiteralPath $env:COPILOT_BROWSER_EXECUTABLE).VersionInfo.ProductVersion"
      ],
      {
        env: { ...process.env, COPILOT_BROWSER_EXECUTABLE: executable },
        windowsHide: true,
        timeout: 5e3
      }
    );
    return stdout2;
  }
  const { stdout, stderr } = await execFileAsync2(executable, ["--version"], {
    windowsHide: true,
    timeout: 5e3
  });
  return `${stdout}
${stderr}`;
}
function browserCandidates() {
  const operatingSystem = platform2();
  const home = environmentHome();
  if (operatingSystem === "win32") {
    const localAppData = process.env.LOCALAPPDATA ?? join3(home, "AppData", "Local");
    const programRoots = [
      process.env.PROGRAMFILES,
      process.env["PROGRAMFILES(X86)"],
      localAppData
    ].filter((value) => value && isAbsolute3(value));
    return [
      {
        executables: programRoots.map(
          (root) => join3(root, "Google", "Chrome", "Application", "chrome.exe")
        ),
        profileRoots: [join3(localAppData, "Google", "Chrome", "User Data")]
      },
      {
        executables: programRoots.map(
          (root) => join3(root, "Microsoft", "Edge", "Application", "msedge.exe")
        ),
        profileRoots: [join3(localAppData, "Microsoft", "Edge", "User Data")]
      }
    ];
  }
  if (operatingSystem === "darwin") {
    return [
      {
        executables: [
          "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
          join3(
            home,
            "Applications",
            "Google Chrome.app",
            "Contents",
            "MacOS",
            "Google Chrome"
          )
        ],
        profileRoots: [join3(home, "Library", "Application Support", "Google", "Chrome")]
      },
      {
        executables: [
          "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
          join3(
            home,
            "Applications",
            "Microsoft Edge.app",
            "Contents",
            "MacOS",
            "Microsoft Edge"
          )
        ],
        profileRoots: [join3(home, "Library", "Application Support", "Microsoft Edge")]
      }
    ];
  }
  const configRoot = chromiumConfigRoot();
  const chromeConfigRoot = process.env.CHROME_CONFIG_HOME && isAbsolute3(process.env.CHROME_CONFIG_HOME) ? resolve2(process.env.CHROME_CONFIG_HOME) : configRoot;
  return [
    {
      executables: ["google-chrome", "google-chrome-stable"],
      profileRoots: [join3(chromeConfigRoot, "google-chrome")]
    },
    {
      executables: ["microsoft-edge", "microsoft-edge-stable"],
      profileRoots: [join3(configRoot, "microsoft-edge")]
    }
  ];
}
function environmentHome() {
  const configured = process.env.HOME ?? process.env.USERPROFILE;
  return configured && isAbsolute3(configured) ? configured : homedir3();
}
function prerequisiteCheck(id, status, message) {
  return { id, status, message };
}

// plugin/shared/scripts/nativeMessagingRegistration.mjs
init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
import { execFile as execFile3 } from "node:child_process";
import { mkdir, readFile as readFile4, readdir as readdir2, rename, rm, stat as stat2, writeFile } from "node:fs/promises";
import { dirname as dirname2, isAbsolute as isAbsolute4, join as join4, resolve as resolve3 } from "node:path";
import { promisify as promisify3 } from "node:util";
var execFileAsync3 = promisify3(execFile3);
async function readActiveInstallation(plan) {
  return readInstallationState(plan.activeInstallationPath, plan, "active");
}
async function readPendingInstallation(plan) {
  return readInstallationState(plan.pendingInstallationPath, plan, "pending");
}
async function readInstallationState(path, plan, label) {
  const content = await readFile4(path, "utf8").catch((error) => {
    if (isMissingFileError(error)) return void 0;
    throw error;
  });
  if (content === void 0) return void 0;
  try {
    const active = JSON.parse(content);
    if (!validActiveInstallation(active, plan)) throw new Error("invalid active installation");
    return active;
  } catch {
    throw new PluginUserError(
      `Browser ${label} activation state is invalid. Reinstall the plugin or remove the Browser setup.`
    );
  }
}
function validActiveInstallation(active, plan) {
  const versionsRoot = resolve3(plan.installRoot, "versions");
  const launcherPath = active && typeof active === "object" && typeof active.manifest?.path === "string" ? resolve3(active.manifest.path) : void 0;
  const expectedVersionDirectory = typeof active?.version === "string" && typeof active?.installationSha256 === "string" ? resolve3(versionsRoot, `${active.version}-${active.installationSha256}`) : void 0;
  const expectedLauncher = expectedVersionDirectory ? resolve3(
    expectedVersionDirectory,
    process.platform === "win32" ? "native-host.bat" : "native-host"
  ) : void 0;
  try {
    if (typeof active?.version === "string") parsePluginVersion(active.version);
    else return false;
  } catch {
    return false;
  }
  return typeof active?.version === "string" && typeof active.installationSha256 === "string" && /^[0-9a-f]{64}$/.test(active.installationSha256) && typeof active.bundleSha256 === "string" && /^[0-9a-f]{64}$/.test(active.bundleSha256) && typeof active.launcherSha256 === "string" && /^[0-9a-f]{64}$/.test(active.launcherSha256) && typeof active.pluginRoot === "string" && isAbsolute4(active.pluginRoot) && launcherPath !== void 0 && expectedLauncher !== void 0 && pathsEqual(launcherPath, expectedLauncher) && Object.keys(active).length === 6 && Object.keys(active.manifest).length === 5 && active.manifest.name === plan.hostName && active.manifest.description === plan.manifest.description && active.manifest.type === "stdio" && Array.isArray(active.manifest.allowed_origins) && active.manifest.allowed_origins.length === 1 && active.manifest.allowed_origins[0] === plan.manifest.allowed_origins[0];
}

// plugin/shared/scripts/doctor.mjs
var execFileAsync4 = promisify4(execFile4);
var MINIMUM_NODE_MAJOR = 22;
var BROWSER_RPC_VERSION = 26;
var MAX_ENDPOINT_DESCRIPTORS = 64;
var ENDPOINT_PROBE_TIMEOUT_MS = 250;
var MAX_ENDPOINT_PROBES = 4;
await runDoctorCli(process.argv.slice(2));
async function runDoctorCli(args) {
  let options;
  try {
    options = parseArguments(args);
  } catch {
    console.error("[copilot-browser] Usage: node doctor.mjs [--json]");
    process.exitCode = 1;
    return;
  }
  if (!options) return;
  let report;
  try {
    report = await createDoctorReport();
  } catch {
    report = doctorReport({
      setup: [
        doctorCheck(
          "diagnostics",
          "fail",
          "Diagnostics could not complete. Reinstall the plugin or run activation again."
        )
      ],
      installedExtension: [],
      liveRuntime: [],
      compatibility: []
    });
  }
  if (options.json) console.log(JSON.stringify(report, null, 2));
  else printDoctorReport(report);
  if (report.status === "fail") process.exitCode = 1;
}
async function createDoctorReport() {
  const setup = [diagnoseNodeRuntime(), await diagnosePluginFiles()];
  const installed = await diagnoseInstalledExtensions(
    channel.extensionId,
    plugin_default.version,
    channel.extensionInstallUrls
  );
  const liveDescriptors = await readLiveEndpointDescriptors();
  const liveRuntime = diagnoseLiveRuntime(liveDescriptors);
  const compatibility = diagnoseCompatibility(installed.states, liveDescriptors);
  if (hasUsableLiveRuntime(liveDescriptors)) {
    preferLiveRuntimeEvidence(installed.checks);
  }
  if (setup.some(({ status }) => status === "fail")) {
    return doctorReport({
      setup,
      installedExtension: installed.checks,
      liveRuntime,
      compatibility
    });
  }
  let plan;
  try {
    plan = await createRegistrationPlan();
  } catch {
    setup.push(
      doctorCheck(
        "plugin-configuration",
        "fail",
        "Browser installation configuration is invalid. Remove custom Browser installation overrides or reinstall this plugin."
      )
    );
    return doctorReport({
      setup,
      installedExtension: installed.checks,
      liveRuntime,
      compatibility
    });
  }
  setup.push(
    doctorCheck("plugin-configuration", "pass", "Browser installation configuration is valid.")
  );
  setup.push(await diagnoseActivationState(plan));
  const installedHost = await readOptionalFile(plan.nativeHostBundle);
  if (installedHost === void 0) {
    setup.push(
      doctorCheck(
        "native-host-installation",
        "warn",
        "Browser setup is incomplete. Run /browser-use:activate."
      )
    );
  } else {
    const installedSha256 = createHash2("sha256").update(installedHost).digest("hex");
    setup.push(
      installedSha256 === plan.bundleSha256 ? doctorCheck(
        "native-host-installation",
        "pass",
        "Browser setup matches this plugin installation."
      ) : doctorCheck(
        "native-host-installation",
        "fail",
        "Browser setup does not match this installation. Run /browser-use:activate."
      )
    );
  }
  const installedLauncher = await readOptionalFile(plan.launcherPath, "utf8");
  const launcherMatches = installedLauncher === launcherContent(plan.nativeHostBundle, plan.installationSha256, plan.version) && await launcherIsExecutable(plan.launcherPath);
  setup.push(
    installedLauncher === void 0 ? doctorCheck(
      "native-host-launcher",
      "warn",
      "Browser startup files are missing. Run /browser-use:activate."
    ) : launcherMatches ? doctorCheck(
      "native-host-launcher",
      "pass",
      "Browser startup files match this installation."
    ) : doctorCheck(
      "native-host-launcher",
      "fail",
      "Browser startup files do not match this installation. Run /browser-use:activate."
    )
  );
  setup.push(await diagnoseManifests(plan));
  setup.push(...await diagnoseProcessUsage(plan));
  if (plan.registryKey) setup.push(await diagnoseWindowsRegistration(plan));
  return doctorReport({
    setup,
    installedExtension: installed.checks,
    liveRuntime,
    compatibility
  });
}
function preferLiveRuntimeEvidence(checks) {
  for (const check of checks) {
    if (check.id === "browser-prerequisite" && check.status === "fail") {
      check.status = "warn";
      check.message = "A Browser runtime is connected, but the offline Chrome or Edge installation could not be verified.";
    } else if (check.id === "browser-extension" && check.status === "fail") {
      check.status = "warn";
      check.message = "A Browser runtime is connected, but the matching offline extension installation could not be verified.";
    }
  }
}
async function readLiveEndpointDescriptors() {
  const records = (await discoverLocalEndpointDescriptorRecords()).filter(
    ({ processState }) => processState !== "missing"
  );
  const descriptors = [];
  let next = 0;
  await Promise.all(
    Array.from({ length: Math.min(MAX_ENDPOINT_PROBES, records.length) }, async () => {
      while (next < records.length && descriptors.length < MAX_ENDPOINT_DESCRIPTORS) {
        const record = records[next++];
        if (record && await endpointIsReachable(record.descriptor.address)) {
          descriptors.push(record.descriptor);
        }
      }
    })
  );
  return descriptors.sort((left, right) => right.createdAt - left.createdAt).slice(0, MAX_ENDPOINT_DESCRIPTORS);
}
async function endpointIsReachable(address) {
  const socket = connect(address);
  try {
    await once(socket, "connect", { signal: AbortSignal.timeout(ENDPOINT_PROBE_TIMEOUT_MS) });
    return true;
  } catch {
    return false;
  } finally {
    socket.destroy();
  }
}
function diagnoseLiveRuntime(descriptors) {
  const relevant = descriptors.filter(
    ({ diagnostics }) => diagnostics === void 0 || diagnostics.extensionId === channel.extensionId
  );
  if (relevant.length === 0) {
    return [doctorCheck("live-runtime", "warn", "No Browser runtime is currently connected.")];
  }
  const identityCounts = /* @__PURE__ */ new Map();
  for (const { diagnostics } of relevant) {
    if (diagnostics?.browserRpcVersion !== BROWSER_RPC_VERSION) continue;
    const identity = diagnostics?.extensionInstanceId;
    if (identity) identityCounts.set(identity, (identityCounts.get(identity) ?? 0) + 1);
  }
  const hasUsableRuntime = relevant.some(
    ({ diagnostics }) => diagnostics?.browserRpcVersion === BROWSER_RPC_VERSION && diagnostics.extensionInstanceId && identityCounts.get(diagnostics.extensionInstanceId) === 1
  );
  return relevant.map(({ diagnostics }, index) => {
    if (!diagnostics) {
      return doctorCheck(
        `live-runtime-${index + 1}`,
        "warn",
        "A connected Browser runtime uses legacy diagnostic metadata."
      );
    }
    const duplicate = diagnostics.extensionInstanceId && identityCounts.get(diagnostics.extensionInstanceId) > 1;
    const missingIdentity = !diagnostics.extensionInstanceId;
    const rpcMatches = diagnostics.browserRpcVersion === BROWSER_RPC_VERSION;
    const identity = diagnostics.installationId.slice(0, 12);
    return doctorCheck(
      `live-runtime-${index + 1}`,
      duplicate || missingIdentity || !rpcMatches ? hasUsableRuntime ? "warn" : "fail" : "pass",
      `Browser runtime ${identity} uses RPC ${diagnostics.browserRpcVersion}, Extension ${diagnostics.extensionVersion ?? "unknown"}, and Host ${diagnostics.nativeHostVersion}${duplicate ? "; duplicate Extension identity detected" : ""}${missingIdentity ? "; Extension identity is unavailable" : ""}.`
    );
  });
}
function hasUsableLiveRuntime(descriptors) {
  const relevant = descriptors.filter(
    ({ diagnostics }) => diagnostics?.extensionId === channel.extensionId && diagnostics.browserRpcVersion === BROWSER_RPC_VERSION
  );
  const identityCounts = /* @__PURE__ */ new Map();
  for (const { diagnostics } of relevant) {
    const identity = diagnostics.extensionInstanceId;
    if (identity) identityCounts.set(identity, (identityCounts.get(identity) ?? 0) + 1);
  }
  return relevant.some(
    ({ diagnostics }) => diagnostics.browserRpcVersion === BROWSER_RPC_VERSION && diagnostics.extensionInstanceId && identityCounts.get(diagnostics.extensionInstanceId) === 1
  );
}
function diagnoseCompatibility(extensionStates, descriptors) {
  const live = descriptors.map(({ diagnostics }) => diagnostics).filter((diagnostics) => diagnostics?.extensionId === channel.extensionId);
  const compatible = live.some(
    ({ browserRpcVersion }) => browserRpcVersion === BROWSER_RPC_VERSION
  );
  const incompatible = live.filter(
    ({ browserRpcVersion }) => browserRpcVersion !== BROWSER_RPC_VERSION
  );
  const incompatibleEnabledRpcVersion = firstIncompatibleExtensionRpcVersion(
    extensionStates,
    BROWSER_RPC_VERSION
  );
  let rpcCheck;
  if (!compatible && incompatible.length > 0) {
    rpcCheck = doctorCheck(
      "rpc-compatibility",
      "fail",
      rpcDirectionMessage(incompatible[0].browserRpcVersion)
    );
  } else if (!compatible && incompatibleEnabledRpcVersion !== void 0) {
    rpcCheck = doctorCheck(
      "rpc-compatibility",
      "fail",
      rpcDirectionMessage(incompatibleEnabledRpcVersion)
    );
  } else if (incompatible.length > 0) {
    rpcCheck = doctorCheck(
      "rpc-compatibility",
      "warn",
      "A compatible Browser runtime is available, but another runtime uses an incompatible RPC version."
    );
  } else {
    rpcCheck = doctorCheck(
      "rpc-compatibility",
      compatible ? "pass" : "warn",
      compatible ? `A connected Browser runtime matches RPC version ${BROWSER_RPC_VERSION}.` : "Browser RPC compatibility could not be verified while no runtime is connected."
    );
  }
  const compatibleRuntimes = live.filter(
    ({ browserRpcVersion }) => browserRpcVersion === BROWSER_RPC_VERSION
  );
  if (compatibleRuntimes.length === 0) return [rpcCheck];
  const productVersionDifferences = [
    ...new Set(
      compatibleRuntimes.flatMap(
        ({ extensionVersion, nativeHostVersion }) => [
          describeProductVersionDifference("Extension", extensionVersion),
          describeProductVersionDifference("Host", nativeHostVersion)
        ].filter((difference) => difference !== void 0)
      )
    )
  ];
  return [
    rpcCheck,
    doctorCheck(
      "product-version-compatibility",
      productVersionDifferences.length === 0 ? "pass" : "warn",
      productVersionDifferences.length === 0 ? `Connected Browser components match plugin version ${plugin_default.version}.` : `Connected Browser product versions differ from Plugin ${plugin_default.version}: ${productVersionDifferences.join("; ")}. Update the older side; if versions cannot be ordered, update the Plugin and Extension together.`
    )
  ];
}
function describeProductVersionDifference(component, version) {
  if (typeof version !== "string") return `${component} version is unknown`;
  try {
    const comparison = comparePluginVersions(version, plugin_default.version);
    if (comparison === 0) return void 0;
    return `${component} ${version} is ${comparison < 0 ? "older" : "newer"}`;
  } catch {
    return `${component} ${version} cannot be ordered`;
  }
}
function rpcDirectionMessage(otherVersion) {
  if (!Number.isSafeInteger(otherVersion)) {
    return "Browser RPC is incompatible; update direction is unknown. Update the Plugin and Extension.";
  }
  return otherVersion < BROWSER_RPC_VERSION ? `Browser RPC ${otherVersion} is older than Plugin RPC ${BROWSER_RPC_VERSION}. Update the Extension.` : `Browser RPC ${otherVersion} is newer than Plugin RPC ${BROWSER_RPC_VERSION}. Update the Plugin.`;
}
async function diagnoseActivationState(plan) {
  let active;
  let pending;
  try {
    [active, pending] = await Promise.all([
      readActiveInstallation(plan),
      readPendingInstallation(plan)
    ]);
  } catch {
    return doctorCheck(
      "active-installation",
      "fail",
      "The Browser activation record is invalid. Run /browser-use:activate."
    );
  }
  if (pending) {
    return doctorCheck(
      "active-installation",
      "fail",
      `Browser activation for version ${pending.version} was interrupted. Run /browser-use:activate to complete setup for this plugin version ${plan.version}.`
    );
  }
  if (!active) {
    return doctorCheck(
      "active-installation",
      "warn",
      "Browser has not been activated for this channel. Run /browser-use:activate."
    );
  }
  if (active.installationSha256 === plan.installationSha256 && pathsEqual(active.pluginRoot, plan.pluginRoot) && active.version === plan.version) {
    return doctorCheck(
      "active-installation",
      "pass",
      `This plugin installation owns the active Browser setup for version ${plan.version}.`
    );
  }
  const comparison = comparePluginVersions(active.version, plan.version);
  if (comparison > 0) {
    return doctorCheck(
      "active-installation",
      "fail",
      `The active Browser setup is version ${active.version}, but this plugin session is version ${plan.version}. Upgrade or restart the plugin session, or run /browser-use:activate to replace the active setup intentionally.`
    );
  }
  if (comparison < 0) {
    return doctorCheck(
      "active-installation",
      "fail",
      `The active Browser setup is version ${active.version}, older than this plugin version ${plan.version}. Run /browser-use:activate.`
    );
  }
  return doctorCheck(
    "active-installation",
    "warn",
    `Another plugin installation owns the active Browser setup for version ${active.version}. Run /browser-use:activate to use this installation.`
  );
}
async function diagnosePluginFiles() {
  const [metadataContent, mcpConfigContent, hooksContent, ...requiredContents] = await Promise.all([
    readOptionalFile(join5(pluginRoot, ".plugin", "plugin.json"), "utf8"),
    readOptionalFile(join5(pluginRoot, ".mcp.json"), "utf8"),
    readOptionalFile(join5(pluginRoot, "hooks", "hooks.json"), "utf8"),
    ...[
      ["dist", "browser-mcp.cjs"],
      ["dist", "browser-run-worker.cjs"],
      ["dist", "native-host.cjs"],
      ["scripts", "activate.mjs"],
      ["scripts", "deactivate.mjs"],
      ["scripts", "doctor.mjs"],
      ["scripts", "nativeMessagingRegistration.mjs"],
      ["skills", "activate", "SKILL.md"],
      ["skills", "browser-use", "SKILL.md"],
      ["skills", "deactivate", "SKILL.md"],
      ["skills", "doctor", "SKILL.md"]
    ].map((segments) => readOptionalFile(join5(pluginRoot, ...segments)))
  ]);
  if (metadataContent === void 0 || mcpConfigContent === void 0 || hooksContent === void 0 || requiredContents.some((content) => content === void 0)) {
    return doctorCheck(
      "plugin-files",
      "fail",
      "Required plugin files are missing. Reinstall this plugin."
    );
  }
  try {
    const metadata = JSON.parse(metadataContent);
    const mcpConfig = JSON.parse(mcpConfigContent);
    const hooksConfig = JSON.parse(hooksContent);
    const mcpServer = mcpConfig?.mcpServers?.["browser-use"];
    const sessionStart = hooksConfig?.hooks?.sessionStart;
    const activationHook = Array.isArray(sessionStart) ? sessionStart[0] : void 0;
    if (metadata.name !== plugin_default.name || metadata.version !== plugin_default.version || metadata.mcpServers !== ".mcp.json" || metadata.commands !== void 0 || metadata.skills !== "skills" || hooksConfig?.version !== 1 || Object.keys(hooksConfig?.hooks ?? {}).length !== 1 || sessionStart?.length !== 1 || activationHook?.type !== "command" || activationHook?.bash !== 'node "$COPILOT_BROWSER_PLUGIN_ROOT/scripts/activate.mjs" --session-start' || activationHook?.powershell !== "$ErrorActionPreference = 'Stop'; node (Join-Path $env:COPILOT_BROWSER_PLUGIN_ROOT 'scripts/activate.mjs') --session-start; exit $LASTEXITCODE" || activationHook?.env?.COPILOT_BROWSER_PLUGIN_ROOT !== "${PLUGIN_ROOT}" || Object.keys(activationHook.env).length !== 1 || activationHook.exec !== void 0 || activationHook.args !== void 0 || activationHook?.timeoutSec !== 30 || Object.keys(mcpConfig?.mcpServers ?? {}).length !== 1 || mcpServer?.type !== "stdio" || mcpServer?.command !== "node" || !Array.isArray(mcpServer?.args) || mcpServer.args.length !== 1 || mcpServer.args[0] !== "${PLUGIN_ROOT}/dist/browser-mcp.cjs") {
      throw new Error("Plugin metadata mismatch.");
    }
  } catch {
    return doctorCheck(
      "plugin-files",
      "fail",
      "Plugin files do not match this plugin version. Reinstall this plugin."
    );
  }
  return doctorCheck(
    "plugin-files",
    "pass",
    `Plugin files match version ${plugin_default.version}.`
  );
}
function diagnoseNodeRuntime() {
  const major = Number.parseInt(process.versions.node.split(".")[0] ?? "", 10);
  return major >= MINIMUM_NODE_MAJOR ? doctorCheck(
    "node-runtime",
    "pass",
    `Node.js ${MINIMUM_NODE_MAJOR} or later is available for the plugin.`
  ) : doctorCheck(
    "node-runtime",
    "fail",
    `Node.js ${MINIMUM_NODE_MAJOR} or later is required to use this plugin.`
  );
}
async function diagnoseManifests(plan) {
  let missing = 0;
  for (const manifestPath of plan.manifestPaths) {
    const content = await readOptionalFile(manifestPath, "utf8");
    if (content === void 0) {
      missing += 1;
      continue;
    }
    try {
      if (!manifestMatchesPlan(JSON.parse(content), plan)) {
        return doctorCheck(
          "native-messaging-manifests",
          "fail",
          "Browser setup belongs to another installation. Run /browser-use:activate."
        );
      }
    } catch {
      return doctorCheck(
        "native-messaging-manifests",
        "fail",
        "Browser setup is invalid. Run /browser-use:activate."
      );
    }
  }
  return missing > 0 ? doctorCheck(
    "native-messaging-manifests",
    "warn",
    "Browser setup is incomplete. Run /browser-use:activate."
  ) : doctorCheck(
    "native-messaging-manifests",
    "pass",
    "Browser setup is complete for this installation."
  );
}
async function diagnoseWindowsRegistration(plan) {
  const registeredManifest = await readRegistryDefaultValue(plan.registryKey);
  if (!registeredManifest) {
    return doctorCheck(
      "windows-registration",
      "warn",
      "Browser setup is incomplete. Run /browser-use:activate."
    );
  }
  if (!pathsEqual(registeredManifest, plan.manifestPaths[0])) {
    return doctorCheck(
      "windows-registration",
      "fail",
      "Browser setup belongs to another installation. Run /browser-use:activate."
    );
  }
  const content = await readOptionalFile(registeredManifest, "utf8");
  if (content === void 0) {
    return doctorCheck(
      "windows-registration",
      "warn",
      "Browser setup is incomplete. Run /browser-use:activate."
    );
  }
  try {
    if (manifestMatchesPlan(JSON.parse(content), plan)) {
      return doctorCheck(
        "windows-registration",
        "pass",
        "Browser setup is active for this installation."
      );
    }
  } catch {
  }
  return doctorCheck(
    "windows-registration",
    "fail",
    "Browser setup belongs to another installation. Run /browser-use:activate."
  );
}
async function diagnoseProcessUsage(plan) {
  let processes;
  try {
    processes = await listProcesses();
  } catch {
    return [
      doctorCheck(
        "plugin-processes",
        "warn",
        "Running plugin processes could not be inspected. Close Copilot sessions before uninstalling or replacing this installation."
      ),
      doctorCheck(
        "browser-runtime-processes",
        "warn",
        "Running Browser runtime processes could not be inspected. Restart Chrome or Edge if it remains connected to an older version."
      )
    ];
  }
  const pluginExecutable = normalizeCommandLine(join5(pluginRoot, "dist", "browser-mcp.cjs"));
  const processesUsingPlugin = processes.filter(
    ({ processId, commandLine }) => processId !== process.pid && normalizeCommandLine(commandLine).includes(pluginExecutable)
  );
  let active;
  try {
    active = await readActiveInstallation(plan);
  } catch {
    active = void 0;
  }
  const versionsRoot = `${normalizeCommandLine(join5(plan.installRoot, "versions"))}/`;
  const activeRoot = active ? `${normalizeCommandLine(join5(active.manifest.path, ".."))}/` : void 0;
  const runtimeProcesses = processes.filter(({ processId, commandLine }) => {
    if (processId === process.pid) return false;
    const normalized = normalizeCommandLine(commandLine);
    return normalized.includes(versionsRoot) && normalized.includes("native-host.cjs");
  });
  const inactiveRuntimeRunning = runtimeProcesses.some(({ commandLine }) => {
    const normalized = normalizeCommandLine(commandLine);
    return activeRoot === void 0 || !normalized.includes(activeRoot);
  });
  return [
    processesUsingPlugin.length === 0 ? doctorCheck(
      "plugin-processes",
      "pass",
      "No running agent process is using this plugin installation."
    ) : doctorCheck(
      "plugin-processes",
      "warn",
      "One or more active Copilot sessions are using this installation. Close Copilot CLI, VS Code, IntelliJ, and other agent sessions before uninstalling or replacing it."
    ),
    inactiveRuntimeRunning ? doctorCheck(
      "browser-runtime-processes",
      "warn",
      "A Browser runtime process is still using an inactive installed version. Restart Chrome or Edge to use the active version."
    ) : doctorCheck(
      "browser-runtime-processes",
      "pass",
      runtimeProcesses.length === 0 ? "No Browser runtime process is currently running." : `Running Browser runtime processes use the active version ${active.version}.`
    )
  ];
}
async function listProcesses() {
  if (platform3() === "win32") {
    const command = "Get-CimInstance Win32_Process | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress";
    const { stdout: stdout2 } = await execFileAsync4(
      "powershell.exe",
      ["-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command],
      { windowsHide: true, maxBuffer: 4 * 1024 * 1024 }
    );
    const parsed = JSON.parse(stdout2 || "[]");
    const values = Array.isArray(parsed) ? parsed : [parsed];
    return values.filter(
      (value) => value !== null && typeof value === "object" && Number.isSafeInteger(value.ProcessId) && typeof value.CommandLine === "string"
    ).map((value) => ({ processId: value.ProcessId, commandLine: value.CommandLine }));
  }
  const { stdout } = await execFileAsync4("ps", ["-axo", "pid=,command="], {
    maxBuffer: 4 * 1024 * 1024
  });
  return stdout.split(/\r?\n/u).map((line) => /^\s*(\d+)\s+(.+)$/u.exec(line)).filter((match) => match !== null).map((match) => ({ processId: Number(match[1]), commandLine: match[2] }));
}
async function readOptionalFile(path, encoding) {
  try {
    return await readFile5(path, encoding);
  } catch (error) {
    if (isMissingFileError(error)) return void 0;
    throw error;
  }
}
function doctorCheck(id, status, message) {
  return { id, status, message };
}
function doctorReport(groups) {
  const checks = Object.values(groups).flat();
  const status = checks.some(({ status: status2 }) => status2 === "fail") ? "fail" : checks.some(({ status: status2 }) => status2 === "warn") ? "warn" : "pass";
  return {
    status,
    groups,
    summary: {
      passed: checks.filter(({ status: status2 }) => status2 === "pass").length,
      warnings: checks.filter(({ status: status2 }) => status2 === "warn").length,
      failures: checks.filter(({ status: status2 }) => status2 === "fail").length
    }
  };
}
function printDoctorReport(report) {
  console.log("Copilot Browser diagnostics");
  console.log("");
  for (const [groupName, checks] of Object.entries(report.groups)) {
    console.log(groupName.replace(/[A-Z]/gu, (letter) => ` ${letter}`).toUpperCase());
    for (const check of checks) {
      console.log(`${check.status.toUpperCase().padEnd(4)}  ${check.message}`);
    }
    console.log("");
  }
  console.log(
    `Summary: ${report.summary.passed} passed, ${report.summary.warnings} warnings, ${report.summary.failures} failures.`
  );
}
function parseArguments(args) {
  if (args.length === 1 && (args[0] === "--help" || args[0] === "-h")) {
    console.log("Usage: node doctor.mjs [--json]");
    return void 0;
  }
  const unexpected = args.filter((arg) => arg !== "--json");
  if (unexpected.length > 0 || args.filter((arg) => arg === "--json").length > 1) {
    throw new Error("Usage: node doctor.mjs [--json]");
  }
  return { json: args.includes("--json") };
}
function normalizeCommandLine(value) {
  const normalized = value.replaceAll("\\", "/");
  return platform3() === "win32" ? normalized.toLowerCase() : normalized;
}
export {
  preferLiveRuntimeEvidence,
  runDoctorCli
};
