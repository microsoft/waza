import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require2() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// <define:__COPILOT_BROWSER_PLUGIN_CHANNEL__>
var define_COPILOT_BROWSER_PLUGIN_CHANNEL_default;
var init_define_COPILOT_BROWSER_PLUGIN_CHANNEL = __esm({
  "<define:__COPILOT_BROWSER_PLUGIN_CHANNEL__>"() {
    define_COPILOT_BROWSER_PLUGIN_CHANNEL_default = { channel: "production", productId: "github-copilot-browser", nativeMessagingHostName: "com.github.copilot.browser", extensionId: "hblomdgalaelcilcdepgohfcogjiijhe", extensionName: "GitHub Copilot", extensionInstallUrls: { chromeWebStore: "https://chromewebstore.google.com/detail/github-copilot/hblomdgalaelcilcdepgohfcogjiijhe" }, advancedPageSurfaces: true, extensionPublicKey: "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA08x5MXlp8uHflF+U7A/JPom4nno762WERnUs48S0+BqvlJTgGtyz1MaSVu4na61vaPelmBBAq40MAp2gzH4i4jK5AQBjHIkBm8sTe1ClAvJu9BiA4zxAm/lbyTPZjJTE2IbRIKVSiZs83UP31qwMJpwi3XmkgH4prWXH+IvNRSy985+hcZb25goCLk93WtbQDJDjYnLXzSZR3qyc/+KqZlcQ03lSGPjuKsyCZmG4e5Au7KNMG8PJuQPTAE+eO7BL3of6oJiLqyARj6KEDOWctREeLxqVhq9fp3MbuLBj9RxhvfJuUhYwIl+FpPuHc5wUzPOiJUDTtTVvHDZde2SigwIDAQAB" };
  }
});

// shared/browser-rpc/browser-rpc-version.json
var browser_rpc_version_default;
var init_browser_rpc_version = __esm({
  "shared/browser-rpc/browser-rpc-version.json"() {
    browser_rpc_version_default = {
      version: 26
    };
  }
});

// shared/browser-rpc/src/protocol/version.ts
var BROWSER_RPC_VERSION;
var init_version = __esm({
  "shared/browser-rpc/src/protocol/version.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browser_rpc_version();
    BROWSER_RPC_VERSION = browser_rpc_version_default.version;
  }
});

// shared/browser-rpc/src/errors.ts
function isBrowserRpcErrorCode(value) {
  return typeof value === "number" && BROWSER_RPC_ERROR_CODES.has(value);
}
function shouldReportBrowserRpcError(error) {
  return !(error instanceof BrowserRpcError) || error.reportable;
}
var BrowserRpcErrorCode, BROWSER_RPC_ERROR_CODES, BrowserRpcError, BrowserRpcResponseError, BrowserRpcRemoteError, BrowserRpcProtocolError, BrowserRpcClosedError, BrowserRpcCancelledError, BrowserRpcTimeoutError;
var init_errors = __esm({
  "shared/browser-rpc/src/errors.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    BrowserRpcErrorCode = {
      InvalidParams: -32602,
      BrowserUnavailable: -33001,
      ApprovalDenied: -33002,
      SessionNotFound: -33003,
      SessionLimitExceeded: -33004,
      RequestCancelled: -33005,
      TabNotFound: -33006,
      TabAlreadyClaimed: -33007,
      TabLimitExceeded: -33008,
      RequestLimitExceeded: -33009,
      SessionFinalizing: -33010,
      StaleElementReference: -33011,
      ElementNotActionable: -33012,
      BrowserActionFailed: -33013,
      PageChanged: -33014,
      ApprovalUnavailable: -33016,
      ResourceLimitExceeded: -33017,
      DebuggerUnavailable: -33019,
      NavigationFailed: -33020,
      RequestTimedOut: -33021,
      ActionOutcomeUnknown: -33022,
      RunInProgress: -33023,
      AdvancedSurfacesDisabled: -33024,
      DomainBlocked: -33025,
      UnsupportedFrameOrigin: -33026
    };
    BROWSER_RPC_ERROR_CODES = new Set(Object.values(BrowserRpcErrorCode));
    BrowserRpcError = class extends Error {
      reportable = true;
    };
    BrowserRpcResponseError = class extends BrowserRpcError {
      constructor(code, message, data) {
        super(message);
        this.code = code;
        this.data = data;
        this.name = "BrowserRpcResponseError";
      }
      code;
      data;
    };
    BrowserRpcRemoteError = class extends BrowserRpcError {
      constructor(code, message, data) {
        super(message);
        this.code = code;
        this.data = data;
        this.name = "BrowserRpcRemoteError";
      }
      code;
      data;
    };
    BrowserRpcProtocolError = class extends BrowserRpcError {
      constructor(message, options) {
        super(message, options);
        this.name = "BrowserRpcProtocolError";
      }
    };
    BrowserRpcClosedError = class extends BrowserRpcError {
      reportable = false;
      constructor(message = "Browser RPC transport closed.") {
        super(message);
        this.name = "BrowserRpcClosedError";
      }
    };
    BrowserRpcCancelledError = class extends BrowserRpcError {
      constructor(method) {
        super(`Browser RPC request '${method}' was cancelled.`);
        this.method = method;
        this.name = "BrowserRpcCancelledError";
      }
      method;
      reportable = false;
    };
    BrowserRpcTimeoutError = class extends BrowserRpcError {
      method;
      timeoutMs;
      constructor(method, timeoutMs) {
        super(`Browser RPC request '${method}' timed out after ${timeoutMs}ms.`);
        this.name = "BrowserRpcTimeoutError";
        this.method = method;
        this.timeoutMs = timeoutMs;
      }
    };
  }
});

// shared/browser-rpc/src/protocol/validation.ts
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function requireString(value, field) {
  if (typeof value !== "string" || value.trim() === "") {
    throw new BrowserRpcProtocolError(`${field} must be a non-empty string.`);
  }
  return value;
}
function requireVersion(value, field) {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new BrowserRpcProtocolError(`${field} must be a positive integer.`);
  }
  return value;
}
function requirePositiveInteger(value, field) {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new BrowserRpcProtocolError(`${field} must be a positive integer.`);
  }
  return value;
}
function parseEmptyParams(value) {
  if (value === void 0) {
    return {};
  }
  if (!isRecord(value) || Object.keys(value).length !== 0) {
    throw new BrowserRpcProtocolError("params must be an empty object.");
  }
  return {};
}
var init_validation = __esm({
  "shared/browser-rpc/src/protocol/validation.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
  }
});

// shared/browser-rpc/src/protocol/extensionInfo.ts
function parseBrowserIdentity(value) {
  if (!isRecord(value) || value.family !== "chromium") {
    throw new BrowserRpcProtocolError("browser.family must be 'chromium'.");
  }
  const product = value.product === "chrome" || value.product === "edge" ? value.product : "unknown";
  return { family: "chromium", product };
}
function parseExtensionInfo(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Extension info must be an object.");
  }
  const extensionId = requireString(value.extensionId, "extensionId");
  if (!/^[a-p]{32}$/.test(extensionId)) {
    throw new BrowserRpcProtocolError("extensionId must be a Chromium extension ID.");
  }
  return {
    protocolVersion: requireVersion(value.protocolVersion, "protocolVersion"),
    extensionId,
    extensionInstanceId: requireString(value.extensionInstanceId, "extensionInstanceId"),
    extensionVersion: requireString(value.extensionVersion, "extensionVersion"),
    browser: parseBrowserIdentity(value.browser)
  };
}
var init_extensionInfo = __esm({
  "shared/browser-rpc/src/protocol/extensionInfo.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_validation();
  }
});

// node_modules/vscode-jsonrpc/lib/common/is.js
var require_is = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/is.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.boolean = boolean;
    exports.string = string;
    exports.number = number;
    exports.error = error;
    exports.func = func;
    exports.array = array;
    exports.stringArray = stringArray;
    function boolean(value) {
      return value === true || value === false;
    }
    function string(value) {
      return typeof value === "string" || value instanceof String;
    }
    function number(value) {
      return typeof value === "number" || value instanceof Number;
    }
    function error(value) {
      return value instanceof Error;
    }
    function func(value) {
      return typeof value === "function";
    }
    function array(value) {
      return Array.isArray(value);
    }
    function stringArray(value) {
      return array(value) && value.every((elem) => string(elem));
    }
  }
});

// node_modules/vscode-jsonrpc/lib/common/messages.js
var require_messages = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/messages.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Message = exports.NotificationType9 = exports.NotificationType8 = exports.NotificationType7 = exports.NotificationType6 = exports.NotificationType5 = exports.NotificationType4 = exports.NotificationType3 = exports.NotificationType2 = exports.NotificationType1 = exports.NotificationType0 = exports.NotificationType = exports.RequestType9 = exports.RequestType8 = exports.RequestType7 = exports.RequestType6 = exports.RequestType5 = exports.RequestType4 = exports.RequestType3 = exports.RequestType2 = exports.RequestType1 = exports.RequestType = exports.RequestType0 = exports.AbstractMessageSignature = exports.ParameterStructures = exports.ResponseError = exports.ErrorCodes = void 0;
    var is = __importStar(require_is());
    var ErrorCodes;
    (function(ErrorCodes2) {
      ErrorCodes2.ParseError = -32700;
      ErrorCodes2.InvalidRequest = -32600;
      ErrorCodes2.MethodNotFound = -32601;
      ErrorCodes2.InvalidParams = -32602;
      ErrorCodes2.InternalError = -32603;
      ErrorCodes2.jsonrpcReservedErrorRangeStart = -32099;
      ErrorCodes2.serverErrorStart = -32099;
      ErrorCodes2.MessageWriteError = -32099;
      ErrorCodes2.MessageReadError = -32098;
      ErrorCodes2.PendingResponseRejected = -32097;
      ErrorCodes2.ConnectionInactive = -32096;
      ErrorCodes2.ServerNotInitialized = -32002;
      ErrorCodes2.UnknownErrorCode = -32001;
      ErrorCodes2.jsonrpcReservedErrorRangeEnd = -32e3;
      ErrorCodes2.serverErrorEnd = -32e3;
    })(ErrorCodes || (exports.ErrorCodes = ErrorCodes = {}));
    var ResponseError = class _ResponseError extends Error {
      code;
      data;
      constructor(code, message, data) {
        super(message);
        this.code = is.number(code) ? code : ErrorCodes.UnknownErrorCode;
        this.data = data;
        Object.setPrototypeOf(this, _ResponseError.prototype);
      }
      toJson() {
        const result = {
          code: this.code,
          message: this.message
        };
        if (this.data !== void 0) {
          result.data = this.data;
        }
        return result;
      }
    };
    exports.ResponseError = ResponseError;
    var ParameterStructures2 = class _ParameterStructures {
      kind;
      /**
       * The parameter structure is automatically inferred on the number of parameters
       * and the parameter type in case of a single param.
       */
      static auto = new _ParameterStructures("auto");
      /**
       * Forces `byPosition` parameter structure. This is useful if you have a single
       * parameter which has a literal type.
       */
      static byPosition = new _ParameterStructures("byPosition");
      /**
       * Forces `byName` parameter structure. This is only useful when having a single
       * parameter. The library will report errors if used with a different number of
       * parameters.
       */
      static byName = new _ParameterStructures("byName");
      constructor(kind) {
        this.kind = kind;
      }
      static is(value) {
        return value === _ParameterStructures.auto || value === _ParameterStructures.byName || value === _ParameterStructures.byPosition;
      }
      toString() {
        return this.kind;
      }
    };
    exports.ParameterStructures = ParameterStructures2;
    var AbstractMessageSignature = class {
      method;
      numberOfParams;
      constructor(method, numberOfParams) {
        this.method = method;
        this.numberOfParams = numberOfParams;
      }
      get parameterStructures() {
        return ParameterStructures2.auto;
      }
    };
    exports.AbstractMessageSignature = AbstractMessageSignature;
    var RequestType0 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 0);
      }
    };
    exports.RequestType0 = RequestType0;
    var RequestType2 = class extends AbstractMessageSignature {
      _parameterStructures;
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method, _parameterStructures = ParameterStructures2.auto) {
        super(method, 1);
        this._parameterStructures = _parameterStructures;
      }
      get parameterStructures() {
        return this._parameterStructures;
      }
    };
    exports.RequestType = RequestType2;
    var RequestType1 = class extends AbstractMessageSignature {
      _parameterStructures;
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method, _parameterStructures = ParameterStructures2.auto) {
        super(method, 1);
        this._parameterStructures = _parameterStructures;
      }
      get parameterStructures() {
        return this._parameterStructures;
      }
    };
    exports.RequestType1 = RequestType1;
    var RequestType22 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 2);
      }
    };
    exports.RequestType2 = RequestType22;
    var RequestType3 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 3);
      }
    };
    exports.RequestType3 = RequestType3;
    var RequestType4 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 4);
      }
    };
    exports.RequestType4 = RequestType4;
    var RequestType5 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 5);
      }
    };
    exports.RequestType5 = RequestType5;
    var RequestType6 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 6);
      }
    };
    exports.RequestType6 = RequestType6;
    var RequestType7 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 7);
      }
    };
    exports.RequestType7 = RequestType7;
    var RequestType8 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 8);
      }
    };
    exports.RequestType8 = RequestType8;
    var RequestType9 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 9);
      }
    };
    exports.RequestType9 = RequestType9;
    var NotificationType2 = class extends AbstractMessageSignature {
      _parameterStructures;
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method, _parameterStructures = ParameterStructures2.auto) {
        super(method, 1);
        this._parameterStructures = _parameterStructures;
      }
      get parameterStructures() {
        return this._parameterStructures;
      }
    };
    exports.NotificationType = NotificationType2;
    var NotificationType0 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 0);
      }
    };
    exports.NotificationType0 = NotificationType0;
    var NotificationType1 = class extends AbstractMessageSignature {
      _parameterStructures;
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method, _parameterStructures = ParameterStructures2.auto) {
        super(method, 1);
        this._parameterStructures = _parameterStructures;
      }
      get parameterStructures() {
        return this._parameterStructures;
      }
    };
    exports.NotificationType1 = NotificationType1;
    var NotificationType22 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 2);
      }
    };
    exports.NotificationType2 = NotificationType22;
    var NotificationType3 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 3);
      }
    };
    exports.NotificationType3 = NotificationType3;
    var NotificationType4 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 4);
      }
    };
    exports.NotificationType4 = NotificationType4;
    var NotificationType5 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 5);
      }
    };
    exports.NotificationType5 = NotificationType5;
    var NotificationType6 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 6);
      }
    };
    exports.NotificationType6 = NotificationType6;
    var NotificationType7 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 7);
      }
    };
    exports.NotificationType7 = NotificationType7;
    var NotificationType8 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 8);
      }
    };
    exports.NotificationType8 = NotificationType8;
    var NotificationType9 = class extends AbstractMessageSignature {
      /**
       * Clients must not use this property. It is here to ensure correct typing.
       */
      _;
      constructor(method) {
        super(method, 9);
      }
    };
    exports.NotificationType9 = NotificationType9;
    var Message4;
    (function(Message5) {
      function isRequest(message) {
        const candidate = message;
        return candidate && is.string(candidate.method) && (is.string(candidate.id) || is.number(candidate.id));
      }
      Message5.isRequest = isRequest;
      function isNotification(message) {
        const candidate = message;
        return candidate && is.string(candidate.method) && message.id === void 0;
      }
      Message5.isNotification = isNotification;
      function isResponse(message) {
        const candidate = message;
        return candidate && (candidate.result !== void 0 || !!candidate.error) && (is.string(candidate.id) || is.number(candidate.id) || candidate.id === null);
      }
      Message5.isResponse = isResponse;
    })(Message4 || (exports.Message = Message4 = {}));
  }
});

// node_modules/vscode-jsonrpc/lib/common/linkedMap.js
var require_linkedMap = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/linkedMap.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.LRUCache = exports.LinkedMap = exports.Touch = void 0;
    var Touch;
    (function(Touch2) {
      Touch2.None = 0;
      Touch2.First = 1;
      Touch2.AsOld = Touch2.First;
      Touch2.Last = 2;
      Touch2.AsNew = Touch2.Last;
    })(Touch || (exports.Touch = Touch = {}));
    var LinkedMap = class {
      [Symbol.toStringTag] = "LinkedMap";
      _map;
      _head;
      _tail;
      _size;
      _state;
      constructor() {
        this._map = /* @__PURE__ */ new Map();
        this._head = void 0;
        this._tail = void 0;
        this._size = 0;
        this._state = 0;
      }
      clear() {
        this._map.clear();
        this._head = void 0;
        this._tail = void 0;
        this._size = 0;
        this._state++;
      }
      isEmpty() {
        return !this._head && !this._tail;
      }
      get size() {
        return this._size;
      }
      get first() {
        return this._head?.value;
      }
      get last() {
        return this._tail?.value;
      }
      before(key) {
        const item = this._map.get(key);
        return item ? item.previous?.value : void 0;
      }
      after(key) {
        const item = this._map.get(key);
        return item ? item.next?.value : void 0;
      }
      has(key) {
        return this._map.has(key);
      }
      get(key, touch = Touch.None) {
        const item = this._map.get(key);
        if (!item) {
          return void 0;
        }
        if (touch !== Touch.None) {
          this.touch(item, touch);
        }
        return item.value;
      }
      set(key, value, touch = Touch.None) {
        let item = this._map.get(key);
        if (item) {
          item.value = value;
          if (touch !== Touch.None) {
            this.touch(item, touch);
          }
        } else {
          item = { key, value, next: void 0, previous: void 0 };
          switch (touch) {
            case Touch.None:
              this.addItemLast(item);
              break;
            case Touch.First:
              this.addItemFirst(item);
              break;
            case Touch.Last:
              this.addItemLast(item);
              break;
            default:
              this.addItemLast(item);
              break;
          }
          this._map.set(key, item);
          this._size++;
        }
        return this;
      }
      delete(key) {
        return !!this.remove(key);
      }
      remove(key) {
        const item = this._map.get(key);
        if (!item) {
          return void 0;
        }
        this._map.delete(key);
        this.removeItem(item);
        this._size--;
        return item.value;
      }
      shift() {
        if (!this._head && !this._tail) {
          return void 0;
        }
        if (!this._head || !this._tail) {
          throw new Error("Invalid list");
        }
        const item = this._head;
        this._map.delete(item.key);
        this.removeItem(item);
        this._size--;
        return item.value;
      }
      forEach(callbackfn, thisArg) {
        const state = this._state;
        let current = this._head;
        while (current) {
          if (thisArg) {
            callbackfn.bind(thisArg)(current.value, current.key, this);
          } else {
            callbackfn(current.value, current.key, this);
          }
          if (this._state !== state) {
            throw new Error(`LinkedMap got modified during iteration.`);
          }
          current = current.next;
        }
      }
      keys() {
        const state = this._state;
        let current = this._head;
        const iterator = {
          [Symbol.iterator]: () => {
            return iterator;
          },
          next: () => {
            if (this._state !== state) {
              throw new Error(`LinkedMap got modified during iteration.`);
            }
            if (current) {
              const result = { value: current.key, done: false };
              current = current.next;
              return result;
            } else {
              return { value: void 0, done: true };
            }
          }
        };
        return iterator;
      }
      values() {
        const state = this._state;
        let current = this._head;
        const iterator = {
          [Symbol.iterator]: () => {
            return iterator;
          },
          next: () => {
            if (this._state !== state) {
              throw new Error(`LinkedMap got modified during iteration.`);
            }
            if (current) {
              const result = { value: current.value, done: false };
              current = current.next;
              return result;
            } else {
              return { value: void 0, done: true };
            }
          }
        };
        return iterator;
      }
      entries() {
        const state = this._state;
        let current = this._head;
        const iterator = {
          [Symbol.iterator]: () => {
            return iterator;
          },
          next: () => {
            if (this._state !== state) {
              throw new Error(`LinkedMap got modified during iteration.`);
            }
            if (current) {
              const result = { value: [current.key, current.value], done: false };
              current = current.next;
              return result;
            } else {
              return { value: void 0, done: true };
            }
          }
        };
        return iterator;
      }
      [Symbol.iterator]() {
        return this.entries();
      }
      trimOld(newSize) {
        if (newSize >= this.size) {
          return;
        }
        if (newSize === 0) {
          this.clear();
          return;
        }
        let current = this._head;
        let currentSize = this.size;
        while (current && currentSize > newSize) {
          this._map.delete(current.key);
          current = current.next;
          currentSize--;
        }
        this._head = current;
        this._size = currentSize;
        if (current) {
          current.previous = void 0;
        }
        this._state++;
      }
      addItemFirst(item) {
        if (!this._head && !this._tail) {
          this._tail = item;
        } else if (!this._head) {
          throw new Error("Invalid list");
        } else {
          item.next = this._head;
          this._head.previous = item;
        }
        this._head = item;
        this._state++;
      }
      addItemLast(item) {
        if (!this._head && !this._tail) {
          this._head = item;
        } else if (!this._tail) {
          throw new Error("Invalid list");
        } else {
          item.previous = this._tail;
          this._tail.next = item;
        }
        this._tail = item;
        this._state++;
      }
      removeItem(item) {
        if (item === this._head && item === this._tail) {
          this._head = void 0;
          this._tail = void 0;
        } else if (item === this._head) {
          if (!item.next) {
            throw new Error("Invalid list");
          }
          item.next.previous = void 0;
          this._head = item.next;
        } else if (item === this._tail) {
          if (!item.previous) {
            throw new Error("Invalid list");
          }
          item.previous.next = void 0;
          this._tail = item.previous;
        } else {
          const next = item.next;
          const previous = item.previous;
          if (!next || !previous) {
            throw new Error("Invalid list");
          }
          next.previous = previous;
          previous.next = next;
        }
        item.next = void 0;
        item.previous = void 0;
        this._state++;
      }
      touch(item, touch) {
        if (!this._head || !this._tail) {
          throw new Error("Invalid list");
        }
        if (touch !== Touch.First && touch !== Touch.Last) {
          return;
        }
        if (touch === Touch.First) {
          if (item === this._head) {
            return;
          }
          const next = item.next;
          const previous = item.previous;
          if (item === this._tail) {
            previous.next = void 0;
            this._tail = previous;
          } else {
            next.previous = previous;
            previous.next = next;
          }
          item.previous = void 0;
          item.next = this._head;
          this._head.previous = item;
          this._head = item;
          this._state++;
        } else if (touch === Touch.Last) {
          if (item === this._tail) {
            return;
          }
          const next = item.next;
          const previous = item.previous;
          if (item === this._head) {
            next.previous = void 0;
            this._head = next;
          } else {
            next.previous = previous;
            previous.next = next;
          }
          item.next = void 0;
          item.previous = this._tail;
          this._tail.next = item;
          this._tail = item;
          this._state++;
        }
      }
      toJSON() {
        const data = [];
        this.forEach((value, key) => {
          data.push([key, value]);
        });
        return data;
      }
      fromJSON(data) {
        this.clear();
        for (const [key, value] of data) {
          this.set(key, value);
        }
      }
    };
    exports.LinkedMap = LinkedMap;
    var LRUCache = class extends LinkedMap {
      _limit;
      _ratio;
      constructor(limit, ratio = 1) {
        super();
        this._limit = limit;
        this._ratio = Math.min(Math.max(0, ratio), 1);
      }
      get limit() {
        return this._limit;
      }
      set limit(limit) {
        this._limit = limit;
        this.checkTrim();
      }
      get ratio() {
        return this._ratio;
      }
      set ratio(ratio) {
        this._ratio = Math.min(Math.max(0, ratio), 1);
        this.checkTrim();
      }
      get(key, touch = Touch.AsNew) {
        return super.get(key, touch);
      }
      peek(key) {
        return super.get(key, Touch.None);
      }
      set(key, value) {
        super.set(key, value, Touch.Last);
        this.checkTrim();
        return this;
      }
      checkTrim() {
        if (this.size > this._limit) {
          this.trimOld(Math.round(this._limit * this._ratio));
        }
      }
    };
    exports.LRUCache = LRUCache;
  }
});

// node_modules/vscode-jsonrpc/lib/common/disposable.js
var require_disposable = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/disposable.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Disposable = void 0;
    var Disposable3;
    (function(Disposable4) {
      function create(func) {
        return {
          dispose: func
        };
      }
      Disposable4.create = create;
    })(Disposable3 || (exports.Disposable = Disposable3 = {}));
  }
});

// node_modules/vscode-jsonrpc/lib/common/ral.js
var require_ral = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/ral.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    Object.defineProperty(exports, "__esModule", { value: true });
    var _ral;
    function RAL() {
      if (_ral === void 0) {
        throw new Error(`No runtime abstraction layer installed`);
      }
      return _ral;
    }
    (function(RAL2) {
      function install(ral) {
        if (ral === void 0) {
          throw new Error(`No runtime abstraction layer provided`);
        }
        _ral = ral;
      }
      RAL2.install = install;
    })(RAL || (RAL = {}));
    exports.default = RAL;
  }
});

// node_modules/vscode-jsonrpc/lib/common/events.js
var require_events = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/events.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Emitter = exports.Event = void 0;
    var ral_1 = __importDefault(require_ral());
    var Event;
    (function(Event2) {
      const _disposable = { dispose() {
      } };
      Event2.None = function() {
        return _disposable;
      };
    })(Event || (exports.Event = Event = {}));
    var CallbackList = class {
      _callbacks;
      _contexts;
      add(callback, context = null, bucket) {
        if (!this._callbacks) {
          this._callbacks = [];
          this._contexts = [];
        }
        this._callbacks.push(callback);
        this._contexts.push(context);
        if (Array.isArray(bucket)) {
          bucket.push({ dispose: () => this.remove(callback, context) });
        }
      }
      remove(callback, context = null) {
        if (!this._callbacks) {
          return;
        }
        let foundCallbackWithDifferentContext = false;
        for (let i = 0, len = this._callbacks.length; i < len; i++) {
          if (this._callbacks[i] === callback) {
            if (this._contexts[i] === context) {
              this._callbacks.splice(i, 1);
              this._contexts.splice(i, 1);
              return;
            } else {
              foundCallbackWithDifferentContext = true;
            }
          }
        }
        if (foundCallbackWithDifferentContext) {
          throw new Error("When adding a listener with a context, you should remove it with the same context");
        }
      }
      invoke(...args) {
        if (!this._callbacks) {
          return [];
        }
        const ret = [], callbacks = this._callbacks.slice(0), contexts = this._contexts.slice(0);
        for (let i = 0, len = callbacks.length; i < len; i++) {
          try {
            ret.push(callbacks[i].apply(contexts[i], args));
          } catch (e) {
            (0, ral_1.default)().console.error(e);
          }
        }
        return ret;
      }
      isEmpty() {
        return !this._callbacks || this._callbacks.length === 0;
      }
      dispose() {
        this._callbacks = void 0;
        this._contexts = void 0;
      }
    };
    var Emitter = class _Emitter {
      _options;
      static _noop = function() {
      };
      _event;
      _callbacks;
      constructor(_options) {
        this._options = _options;
      }
      /**
       * For the public to allow to subscribe
       * to events from this Emitter
       */
      get event() {
        if (!this._event) {
          this._event = (listener, thisArgs, disposables) => {
            if (!this._callbacks) {
              this._callbacks = new CallbackList();
            }
            if (this._options && this._options.onFirstListenerAdd && this._callbacks.isEmpty()) {
              this._options.onFirstListenerAdd(this);
            }
            this._callbacks.add(listener, thisArgs);
            const result = {
              dispose: () => {
                if (!this._callbacks) {
                  return;
                }
                this._callbacks.remove(listener, thisArgs);
                result.dispose = _Emitter._noop;
                if (this._options && this._options.onLastListenerRemove && this._callbacks.isEmpty()) {
                  this._options.onLastListenerRemove(this);
                }
              }
            };
            if (Array.isArray(disposables)) {
              disposables.push(result);
            }
            return result;
          };
        }
        return this._event;
      }
      /**
       * To be kept private to fire an event to
       * subscribers
       */
      fire(event) {
        if (this._callbacks) {
          this._callbacks.invoke.call(this._callbacks, event);
        }
      }
      dispose() {
        if (this._callbacks) {
          this._callbacks.dispose();
          this._callbacks = void 0;
        }
      }
    };
    exports.Emitter = Emitter;
  }
});

// node_modules/vscode-jsonrpc/lib/common/cancellation.js
var require_cancellation = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/cancellation.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.CancellationTokenSource = exports.CancellationToken = void 0;
    var ral_1 = __importDefault(require_ral());
    var Is = __importStar(require_is());
    var events_1 = require_events();
    var CancellationToken;
    (function(CancellationToken2) {
      CancellationToken2.None = Object.freeze({
        isCancellationRequested: false,
        onCancellationRequested: events_1.Event.None
      });
      CancellationToken2.Cancelled = Object.freeze({
        isCancellationRequested: true,
        onCancellationRequested: events_1.Event.None
      });
      function is(value) {
        const candidate = value;
        return candidate && (candidate === CancellationToken2.None || candidate === CancellationToken2.Cancelled || Is.boolean(candidate.isCancellationRequested) && !!candidate.onCancellationRequested);
      }
      CancellationToken2.is = is;
    })(CancellationToken || (exports.CancellationToken = CancellationToken = {}));
    var shortcutEvent = Object.freeze(function(callback, context) {
      const handle = (0, ral_1.default)().timer.setTimeout(callback.bind(context), 0);
      return { dispose() {
        handle.dispose();
      } };
    });
    var MutableToken = class {
      _isCancelled = false;
      _emitter;
      cancel() {
        if (!this._isCancelled) {
          this._isCancelled = true;
          if (this._emitter) {
            this._emitter.fire(void 0);
            this.dispose();
          }
        }
      }
      get isCancellationRequested() {
        return this._isCancelled;
      }
      get onCancellationRequested() {
        if (this._isCancelled) {
          return shortcutEvent;
        }
        if (!this._emitter) {
          this._emitter = new events_1.Emitter();
        }
        return this._emitter.event;
      }
      dispose() {
        if (this._emitter) {
          this._emitter.dispose();
          this._emitter = void 0;
        }
      }
    };
    var CancellationTokenSource2 = class {
      _token;
      get token() {
        if (!this._token) {
          this._token = new MutableToken();
        }
        return this._token;
      }
      cancel() {
        if (!this._token) {
          this._token = CancellationToken.Cancelled;
        } else {
          this._token.cancel();
        }
      }
      dispose() {
        if (!this._token) {
          this._token = CancellationToken.None;
        } else if (this._token instanceof MutableToken) {
          this._token.dispose();
        }
      }
    };
    exports.CancellationTokenSource = CancellationTokenSource2;
  }
});

// node_modules/vscode-jsonrpc/lib/common/sharedArrayCancellation.js
var require_sharedArrayCancellation = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/sharedArrayCancellation.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.SharedArrayReceiverStrategy = exports.SharedArraySenderStrategy = void 0;
    var cancellation_1 = require_cancellation();
    var CancellationState;
    (function(CancellationState2) {
      CancellationState2.Continue = 0;
      CancellationState2.Cancelled = 1;
    })(CancellationState || (CancellationState = {}));
    var SharedArraySenderStrategy = class {
      buffers;
      constructor() {
        this.buffers = /* @__PURE__ */ new Map();
      }
      enableCancellation(request) {
        if (request.id === null) {
          return;
        }
        const buffer = new SharedArrayBuffer(4);
        const data = new Int32Array(buffer, 0, 1);
        data[0] = CancellationState.Continue;
        this.buffers.set(request.id, buffer);
        request.$cancellationData = buffer;
      }
      async sendCancellation(_conn, id) {
        const buffer = this.buffers.get(id);
        if (buffer === void 0) {
          return;
        }
        const data = new Int32Array(buffer, 0, 1);
        Atomics.store(data, 0, CancellationState.Cancelled);
      }
      cleanup(id) {
        this.buffers.delete(id);
      }
      dispose() {
        this.buffers.clear();
      }
    };
    exports.SharedArraySenderStrategy = SharedArraySenderStrategy;
    var SharedArrayBufferCancellationToken = class {
      data;
      constructor(buffer) {
        this.data = new Int32Array(buffer, 0, 1);
      }
      get isCancellationRequested() {
        return Atomics.load(this.data, 0) === CancellationState.Cancelled;
      }
      get onCancellationRequested() {
        throw new Error(`Cancellation over SharedArrayBuffer doesn't support cancellation events`);
      }
    };
    var SharedArrayBufferCancellationTokenSource = class {
      token;
      constructor(buffer) {
        this.token = new SharedArrayBufferCancellationToken(buffer);
      }
      cancel() {
      }
      dispose() {
      }
    };
    var SharedArrayReceiverStrategy = class {
      kind = "request";
      createCancellationTokenSource(request) {
        const buffer = request.$cancellationData;
        if (buffer === void 0) {
          return new cancellation_1.CancellationTokenSource();
        }
        return new SharedArrayBufferCancellationTokenSource(buffer);
      }
    };
    exports.SharedArrayReceiverStrategy = SharedArrayReceiverStrategy;
  }
});

// node_modules/vscode-jsonrpc/lib/common/semaphore.js
var require_semaphore = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/semaphore.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Semaphore = void 0;
    var ral_1 = __importDefault(require_ral());
    var Semaphore = class {
      _capacity;
      _active;
      _waiting;
      constructor(capacity = 1) {
        if (capacity <= 0) {
          throw new Error("Capacity must be greater than 0");
        }
        this._capacity = capacity;
        this._active = 0;
        this._waiting = [];
      }
      lock(thunk) {
        return new Promise((resolve3, reject) => {
          this._waiting.push({ thunk, resolve: resolve3, reject });
          this.runNext();
        });
      }
      get active() {
        return this._active;
      }
      runNext() {
        if (this._waiting.length === 0 || this._active === this._capacity) {
          return;
        }
        (0, ral_1.default)().timer.setImmediate(() => this.doRunNext());
      }
      doRunNext() {
        if (this._waiting.length === 0 || this._active === this._capacity) {
          return;
        }
        const next = this._waiting.shift();
        this._active++;
        if (this._active > this._capacity) {
          throw new Error(`Too many thunks active`);
        }
        try {
          const result = next.thunk();
          if (result instanceof Promise) {
            result.then((value) => {
              this._active--;
              next.resolve(value);
              this.runNext();
            }, (err) => {
              this._active--;
              next.reject(err);
              this.runNext();
            });
          } else {
            this._active--;
            next.resolve(result);
            this.runNext();
          }
        } catch (err) {
          this._active--;
          next.reject(err);
          this.runNext();
        }
      }
    };
    exports.Semaphore = Semaphore;
  }
});

// node_modules/vscode-jsonrpc/lib/common/messageReader.js
var require_messageReader = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/messageReader.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ReadableStreamMessageReader = exports.AbstractMessageReader = exports.MessageReader = void 0;
    var ral_1 = __importDefault(require_ral());
    var Is = __importStar(require_is());
    var events_1 = require_events();
    var semaphore_1 = require_semaphore();
    var MessageReader;
    (function(MessageReader2) {
      function is(value) {
        const candidate = value;
        return candidate && Is.func(candidate.listen) && Is.func(candidate.dispose) && Is.func(candidate.onError) && Is.func(candidate.onClose) && Is.func(candidate.onPartialMessage);
      }
      MessageReader2.is = is;
    })(MessageReader || (exports.MessageReader = MessageReader = {}));
    var AbstractMessageReader2 = class {
      errorEmitter;
      closeEmitter;
      partialMessageEmitter;
      constructor() {
        this.errorEmitter = new events_1.Emitter();
        this.closeEmitter = new events_1.Emitter();
        this.partialMessageEmitter = new events_1.Emitter();
      }
      dispose() {
        this.errorEmitter.dispose();
        this.closeEmitter.dispose();
        this.partialMessageEmitter.dispose();
      }
      get onError() {
        return this.errorEmitter.event;
      }
      fireError(error) {
        this.errorEmitter.fire(this.asError(error));
      }
      get onClose() {
        return this.closeEmitter.event;
      }
      fireClose() {
        this.closeEmitter.fire(void 0);
      }
      get onPartialMessage() {
        return this.partialMessageEmitter.event;
      }
      firePartialMessage(info) {
        this.partialMessageEmitter.fire(info);
      }
      asError(error) {
        if (error instanceof Error) {
          return error;
        } else {
          return new Error(`Reader received error. Reason: ${Is.string(error.message) ? error.message : "unknown"}`);
        }
      }
    };
    exports.AbstractMessageReader = AbstractMessageReader2;
    var ResolvedMessageReaderOptions;
    (function(ResolvedMessageReaderOptions2) {
      function fromOptions(options) {
        let charset;
        let result;
        let contentDecoder;
        const contentDecoders = /* @__PURE__ */ new Map();
        let contentTypeDecoder;
        const contentTypeDecoders = /* @__PURE__ */ new Map();
        if (options === void 0 || typeof options === "string") {
          charset = options ?? "utf-8";
        } else {
          charset = options.charset ?? "utf-8";
          if (options.contentDecoder !== void 0) {
            contentDecoder = options.contentDecoder;
            contentDecoders.set(contentDecoder.name, contentDecoder);
          }
          if (options.contentDecoders !== void 0) {
            for (const decoder of options.contentDecoders) {
              contentDecoders.set(decoder.name, decoder);
            }
          }
          if (options.contentTypeDecoder !== void 0) {
            contentTypeDecoder = options.contentTypeDecoder;
            contentTypeDecoders.set(contentTypeDecoder.name, contentTypeDecoder);
          }
          if (options.contentTypeDecoders !== void 0) {
            for (const decoder of options.contentTypeDecoders) {
              contentTypeDecoders.set(decoder.name, decoder);
            }
          }
        }
        if (contentTypeDecoder === void 0) {
          contentTypeDecoder = (0, ral_1.default)().applicationJson.decoder;
          contentTypeDecoders.set(contentTypeDecoder.name, contentTypeDecoder);
        }
        return { charset, contentDecoder, contentDecoders, contentTypeDecoder, contentTypeDecoders };
      }
      ResolvedMessageReaderOptions2.fromOptions = fromOptions;
    })(ResolvedMessageReaderOptions || (ResolvedMessageReaderOptions = {}));
    var ReadableStreamMessageReader = class extends AbstractMessageReader2 {
      readable;
      options;
      callback;
      nextMessageLength;
      messageToken;
      buffer;
      partialMessageTimer;
      _partialMessageTimeout;
      readSemaphore;
      constructor(readable, options) {
        super();
        this.readable = readable;
        this.options = ResolvedMessageReaderOptions.fromOptions(options);
        this.buffer = (0, ral_1.default)().messageBuffer.create(this.options.charset);
        this._partialMessageTimeout = 1e4;
        this.nextMessageLength = -1;
        this.messageToken = 0;
        this.readSemaphore = new semaphore_1.Semaphore(1);
      }
      set partialMessageTimeout(timeout) {
        this._partialMessageTimeout = timeout;
      }
      get partialMessageTimeout() {
        return this._partialMessageTimeout;
      }
      listen(callback) {
        this.nextMessageLength = -1;
        this.messageToken = 0;
        this.partialMessageTimer = void 0;
        this.callback = callback;
        const result = this.readable.onData((data) => {
          this.onData(data);
        });
        this.readable.onError((error) => this.fireError(error));
        this.readable.onClose(() => this.fireClose());
        return result;
      }
      onData(data) {
        try {
          this.buffer.append(data);
          while (true) {
            if (this.nextMessageLength === -1) {
              const headers = this.buffer.tryReadHeaders(true);
              if (!headers) {
                return;
              }
              const contentLength = headers.get("content-length");
              if (!contentLength) {
                this.fireError(new Error(`Header must provide a Content-Length property.
${JSON.stringify(Object.fromEntries(headers))}`));
                return;
              }
              const length = parseInt(contentLength);
              if (isNaN(length)) {
                this.fireError(new Error(`Content-Length value must be a number. Got ${contentLength}`));
                return;
              }
              this.nextMessageLength = length;
            }
            const body = this.buffer.tryReadBody(this.nextMessageLength);
            if (body === void 0) {
              this.setPartialMessageTimer();
              return;
            }
            this.clearPartialMessageTimer();
            this.nextMessageLength = -1;
            this.readSemaphore.lock(async () => {
              const bytes = this.options.contentDecoder !== void 0 ? await this.options.contentDecoder.decode(body) : body;
              const message = await this.options.contentTypeDecoder.decode(bytes, this.options);
              this.callback(message);
            }).catch((error) => {
              this.fireError(error);
            });
          }
        } catch (error) {
          this.fireError(error);
        }
      }
      clearPartialMessageTimer() {
        if (this.partialMessageTimer) {
          this.partialMessageTimer.dispose();
          this.partialMessageTimer = void 0;
        }
      }
      setPartialMessageTimer() {
        this.clearPartialMessageTimer();
        if (this._partialMessageTimeout <= 0) {
          return;
        }
        this.partialMessageTimer = (0, ral_1.default)().timer.setTimeout((token, timeout) => {
          this.partialMessageTimer = void 0;
          if (token === this.messageToken) {
            this.firePartialMessage({ messageToken: token, waitingTime: timeout });
            this.setPartialMessageTimer();
          }
        }, this._partialMessageTimeout, this.messageToken, this._partialMessageTimeout);
      }
    };
    exports.ReadableStreamMessageReader = ReadableStreamMessageReader;
  }
});

// node_modules/vscode-jsonrpc/lib/common/messageWriter.js
var require_messageWriter = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/messageWriter.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.WriteableStreamMessageWriter = exports.AbstractMessageWriter = exports.MessageWriter = void 0;
    var ral_1 = __importDefault(require_ral());
    var Is = __importStar(require_is());
    var semaphore_1 = require_semaphore();
    var events_1 = require_events();
    var ContentLength = "Content-Length: ";
    var CRLF = "\r\n";
    var MessageWriter;
    (function(MessageWriter2) {
      function is(value) {
        const candidate = value;
        return candidate && Is.func(candidate.dispose) && Is.func(candidate.onClose) && Is.func(candidate.onError) && Is.func(candidate.write);
      }
      MessageWriter2.is = is;
    })(MessageWriter || (exports.MessageWriter = MessageWriter = {}));
    var AbstractMessageWriter2 = class {
      errorEmitter;
      closeEmitter;
      constructor() {
        this.errorEmitter = new events_1.Emitter();
        this.closeEmitter = new events_1.Emitter();
      }
      dispose() {
        this.errorEmitter.dispose();
        this.closeEmitter.dispose();
      }
      get onError() {
        return this.errorEmitter.event;
      }
      fireError(error, message, count) {
        this.errorEmitter.fire([this.asError(error), message, count]);
      }
      get onClose() {
        return this.closeEmitter.event;
      }
      fireClose() {
        this.closeEmitter.fire(void 0);
      }
      asError(error) {
        if (error instanceof Error) {
          return error;
        } else {
          return new Error(`Writer received error. Reason: ${Is.string(error.message) ? error.message : "unknown"}`);
        }
      }
    };
    exports.AbstractMessageWriter = AbstractMessageWriter2;
    var ResolvedMessageWriterOptions;
    (function(ResolvedMessageWriterOptions2) {
      function fromOptions(options) {
        if (options === void 0 || typeof options === "string") {
          return { charset: options ?? "utf-8", contentTypeEncoder: (0, ral_1.default)().applicationJson.encoder };
        } else {
          return { charset: options.charset ?? "utf-8", contentEncoder: options.contentEncoder, contentTypeEncoder: options.contentTypeEncoder ?? (0, ral_1.default)().applicationJson.encoder };
        }
      }
      ResolvedMessageWriterOptions2.fromOptions = fromOptions;
    })(ResolvedMessageWriterOptions || (ResolvedMessageWriterOptions = {}));
    var WriteableStreamMessageWriter = class extends AbstractMessageWriter2 {
      writable;
      options;
      errorCount;
      writeSemaphore;
      constructor(writable, options) {
        super();
        this.writable = writable;
        this.options = ResolvedMessageWriterOptions.fromOptions(options);
        this.errorCount = 0;
        this.writeSemaphore = new semaphore_1.Semaphore(1);
        this.writable.onError((error) => this.fireError(error));
        this.writable.onClose(() => this.fireClose());
      }
      async write(msg) {
        return this.writeSemaphore.lock(async () => {
          const payload = this.options.contentTypeEncoder.encode(msg, this.options).then((buffer) => {
            if (this.options.contentEncoder !== void 0) {
              return this.options.contentEncoder.encode(buffer);
            } else {
              return buffer;
            }
          });
          return payload.then((buffer) => {
            const headers = [];
            headers.push(ContentLength, buffer.byteLength.toString(), CRLF);
            headers.push(CRLF);
            return this.doWrite(msg, headers, buffer);
          }, (error) => {
            this.fireError(error);
            throw error;
          });
        });
      }
      async doWrite(msg, headers, data) {
        try {
          await this.writable.write(headers.join(""), "ascii");
          return this.writable.write(data);
        } catch (error) {
          this.handleError(error, msg);
          return Promise.reject(error);
        }
      }
      handleError(error, msg) {
        this.errorCount++;
        this.fireError(error, msg, this.errorCount);
      }
      end() {
        this.writable.end();
      }
    };
    exports.WriteableStreamMessageWriter = WriteableStreamMessageWriter;
  }
});

// node_modules/vscode-jsonrpc/lib/common/messageBuffer.js
var require_messageBuffer = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/messageBuffer.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.AbstractMessageBuffer = void 0;
    var CR = 13;
    var LF = 10;
    var CRLF = "\r\n";
    var AbstractMessageBuffer = class {
      _encoding;
      _chunks;
      _totalLength;
      constructor(encoding = "utf-8") {
        this._encoding = encoding;
        this._chunks = [];
        this._totalLength = 0;
      }
      get encoding() {
        return this._encoding;
      }
      append(chunk) {
        const toAppend = typeof chunk === "string" ? this.fromString(chunk, this._encoding) : chunk;
        this._chunks.push(toAppend);
        this._totalLength += toAppend.byteLength;
      }
      tryReadHeaders(lowerCaseKeys = false) {
        if (this._chunks.length === 0) {
          return void 0;
        }
        let state = 0;
        let chunkIndex = 0;
        let offset = 0;
        let chunkBytesRead = 0;
        row: while (chunkIndex < this._chunks.length) {
          const chunk = this._chunks[chunkIndex];
          offset = 0;
          while (offset < chunk.length) {
            const value = chunk[offset];
            switch (value) {
              case CR:
                switch (state) {
                  case 0:
                    state = 1;
                    break;
                  case 2:
                    state = 3;
                    break;
                  default:
                    state = 0;
                }
                break;
              case LF:
                switch (state) {
                  case 1:
                    state = 2;
                    break;
                  case 3:
                    state = 4;
                    offset++;
                    break row;
                  default:
                    state = 0;
                }
                break;
              default:
                state = 0;
            }
            offset++;
          }
          chunkBytesRead += chunk.byteLength;
          chunkIndex++;
        }
        if (state !== 4) {
          return void 0;
        }
        const buffer = this._read(chunkBytesRead + offset);
        const result = /* @__PURE__ */ new Map();
        const headers = this.toString(buffer, "ascii").split(CRLF);
        if (headers.length < 2) {
          return result;
        }
        for (let i = 0; i < headers.length - 2; i++) {
          const header = headers[i];
          const index = header.indexOf(":");
          if (index === -1) {
            throw new Error(`Message header must separate key and value using ':'
${header}`);
          }
          const key = header.substr(0, index);
          const value = header.substr(index + 1).trim();
          result.set(lowerCaseKeys ? key.toLowerCase() : key, value);
        }
        return result;
      }
      tryReadBody(length) {
        if (this._totalLength < length) {
          return void 0;
        }
        return this._read(length);
      }
      get numberOfBytes() {
        return this._totalLength;
      }
      _read(byteCount) {
        if (byteCount === 0) {
          return this.emptyBuffer();
        }
        if (byteCount > this._totalLength) {
          throw new Error(`Cannot read so many bytes!`);
        }
        if (this._chunks[0].byteLength === byteCount) {
          const chunk = this._chunks[0];
          this._chunks.shift();
          this._totalLength -= byteCount;
          return this.asNative(chunk);
        }
        if (this._chunks[0].byteLength > byteCount) {
          const chunk = this._chunks[0];
          const result2 = this.asNative(chunk, byteCount);
          this._chunks[0] = chunk.slice(byteCount);
          this._totalLength -= byteCount;
          return result2;
        }
        const result = this.allocNative(byteCount);
        let resultOffset = 0;
        const chunkIndex = 0;
        while (byteCount > 0) {
          const chunk = this._chunks[chunkIndex];
          if (chunk.byteLength > byteCount) {
            const chunkPart = chunk.slice(0, byteCount);
            result.set(chunkPart, resultOffset);
            resultOffset += byteCount;
            this._chunks[chunkIndex] = chunk.slice(byteCount);
            this._totalLength -= byteCount;
            byteCount -= byteCount;
          } else {
            result.set(chunk, resultOffset);
            resultOffset += chunk.byteLength;
            this._chunks.shift();
            this._totalLength -= chunk.byteLength;
            byteCount -= chunk.byteLength;
          }
        }
        return result;
      }
    };
    exports.AbstractMessageBuffer = AbstractMessageBuffer;
  }
});

// node_modules/vscode-jsonrpc/lib/common/connection.js
var require_connection = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/connection.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ConnectionOptions = exports.MessageStrategy = exports.CancellationStrategy = exports.CancellationSenderStrategy = exports.CancellationReceiverStrategy = exports.RequestCancellationReceiverStrategy = exports.IdCancellationReceiverStrategy = exports.ConnectionStrategy = exports.ConnectionError = exports.ConnectionErrors = exports.LogTraceNotification = exports.SetTraceNotification = exports.TraceFormat = exports.TraceValues = exports.TraceValue = exports.Trace = exports.NullLogger = exports.ProgressType = exports.ProgressToken = void 0;
    exports.createMessageConnection = createMessageConnection2;
    var ral_1 = __importDefault(require_ral());
    var Is = __importStar(require_is());
    var messages_1 = require_messages();
    var linkedMap_1 = require_linkedMap();
    var events_1 = require_events();
    var cancellation_1 = require_cancellation();
    var CancelNotification;
    (function(CancelNotification2) {
      CancelNotification2.type = new messages_1.NotificationType("$/cancelRequest");
    })(CancelNotification || (CancelNotification = {}));
    var ProgressToken;
    (function(ProgressToken2) {
      function is(value) {
        return typeof value === "string" || typeof value === "number";
      }
      ProgressToken2.is = is;
    })(ProgressToken || (exports.ProgressToken = ProgressToken = {}));
    var ProgressNotification;
    (function(ProgressNotification2) {
      ProgressNotification2.type = new messages_1.NotificationType("$/progress");
    })(ProgressNotification || (ProgressNotification = {}));
    var ProgressType = class {
      /**
       * Clients must not use these properties. They are here to ensure correct typing.
       * in TypeScript
       */
      __;
      _pr;
      constructor() {
      }
    };
    exports.ProgressType = ProgressType;
    var StarRequestHandler;
    (function(StarRequestHandler2) {
      function is(value) {
        return Is.func(value);
      }
      StarRequestHandler2.is = is;
    })(StarRequestHandler || (StarRequestHandler = {}));
    exports.NullLogger = Object.freeze({
      error: () => {
      },
      warn: () => {
      },
      info: () => {
      },
      log: () => {
      }
    });
    var Trace;
    (function(Trace2) {
      Trace2[Trace2["Off"] = 0] = "Off";
      Trace2[Trace2["Messages"] = 1] = "Messages";
      Trace2[Trace2["Compact"] = 2] = "Compact";
      Trace2[Trace2["Verbose"] = 3] = "Verbose";
    })(Trace || (exports.Trace = Trace = {}));
    var TraceValue;
    (function(TraceValue2) {
      TraceValue2.Off = "off";
      TraceValue2.Messages = "messages";
      TraceValue2.Compact = "compact";
      TraceValue2.Verbose = "verbose";
    })(TraceValue || (exports.TraceValue = TraceValue = {}));
    exports.TraceValues = TraceValue;
    (function(Trace2) {
      function fromString(value) {
        if (!Is.string(value)) {
          return Trace2.Off;
        }
        value = value.toLowerCase();
        switch (value) {
          case "off":
            return Trace2.Off;
          case "messages":
            return Trace2.Messages;
          case "compact":
            return Trace2.Compact;
          case "verbose":
            return Trace2.Verbose;
          default:
            return Trace2.Off;
        }
      }
      Trace2.fromString = fromString;
      function toString(value) {
        switch (value) {
          case Trace2.Off:
            return "off";
          case Trace2.Messages:
            return "messages";
          case Trace2.Compact:
            return "compact";
          case Trace2.Verbose:
            return "verbose";
          default:
            return "off";
        }
      }
      Trace2.toString = toString;
    })(Trace || (exports.Trace = Trace = {}));
    var TraceFormat;
    (function(TraceFormat2) {
      TraceFormat2["Text"] = "text";
      TraceFormat2["JSON"] = "json";
    })(TraceFormat || (exports.TraceFormat = TraceFormat = {}));
    (function(TraceFormat2) {
      function fromString(value) {
        if (!Is.string(value)) {
          return TraceFormat2.Text;
        }
        value = value.toLowerCase();
        if (value === "json") {
          return TraceFormat2.JSON;
        } else {
          return TraceFormat2.Text;
        }
      }
      TraceFormat2.fromString = fromString;
    })(TraceFormat || (exports.TraceFormat = TraceFormat = {}));
    var SetTraceNotification;
    (function(SetTraceNotification2) {
      SetTraceNotification2.type = new messages_1.NotificationType("$/setTrace");
    })(SetTraceNotification || (exports.SetTraceNotification = SetTraceNotification = {}));
    var LogTraceNotification;
    (function(LogTraceNotification2) {
      LogTraceNotification2.type = new messages_1.NotificationType("$/logTrace");
    })(LogTraceNotification || (exports.LogTraceNotification = LogTraceNotification = {}));
    var ConnectionErrors;
    (function(ConnectionErrors2) {
      ConnectionErrors2[ConnectionErrors2["Closed"] = 1] = "Closed";
      ConnectionErrors2[ConnectionErrors2["Disposed"] = 2] = "Disposed";
      ConnectionErrors2[ConnectionErrors2["AlreadyListening"] = 3] = "AlreadyListening";
    })(ConnectionErrors || (exports.ConnectionErrors = ConnectionErrors = {}));
    var ConnectionError = class _ConnectionError extends Error {
      code;
      constructor(code, message) {
        super(message);
        this.code = code;
        Object.setPrototypeOf(this, _ConnectionError.prototype);
      }
    };
    exports.ConnectionError = ConnectionError;
    var ConnectionStrategy;
    (function(ConnectionStrategy2) {
      function is(value) {
        const candidate = value;
        return candidate && Is.func(candidate.cancelUndispatched);
      }
      ConnectionStrategy2.is = is;
    })(ConnectionStrategy || (exports.ConnectionStrategy = ConnectionStrategy = {}));
    var IdCancellationReceiverStrategy;
    (function(IdCancellationReceiverStrategy2) {
      function is(value) {
        const candidate = value;
        return candidate && (candidate.kind === void 0 || candidate.kind === "id") && Is.func(candidate.createCancellationTokenSource) && (candidate.dispose === void 0 || Is.func(candidate.dispose));
      }
      IdCancellationReceiverStrategy2.is = is;
    })(IdCancellationReceiverStrategy || (exports.IdCancellationReceiverStrategy = IdCancellationReceiverStrategy = {}));
    var RequestCancellationReceiverStrategy;
    (function(RequestCancellationReceiverStrategy2) {
      function is(value) {
        const candidate = value;
        return candidate && candidate.kind === "request" && Is.func(candidate.createCancellationTokenSource) && (candidate.dispose === void 0 || Is.func(candidate.dispose));
      }
      RequestCancellationReceiverStrategy2.is = is;
    })(RequestCancellationReceiverStrategy || (exports.RequestCancellationReceiverStrategy = RequestCancellationReceiverStrategy = {}));
    var CancellationReceiverStrategy;
    (function(CancellationReceiverStrategy2) {
      CancellationReceiverStrategy2.Message = Object.freeze({
        createCancellationTokenSource(_) {
          return new cancellation_1.CancellationTokenSource();
        }
      });
      function is(value) {
        return IdCancellationReceiverStrategy.is(value) || RequestCancellationReceiverStrategy.is(value);
      }
      CancellationReceiverStrategy2.is = is;
    })(CancellationReceiverStrategy || (exports.CancellationReceiverStrategy = CancellationReceiverStrategy = {}));
    var CancellationSenderStrategy;
    (function(CancellationSenderStrategy2) {
      CancellationSenderStrategy2.Message = Object.freeze({
        sendCancellation(conn, id) {
          return conn.sendNotification(CancelNotification.type, { id });
        },
        cleanup(_) {
        }
      });
      function is(value) {
        const candidate = value;
        return candidate && Is.func(candidate.sendCancellation) && Is.func(candidate.cleanup);
      }
      CancellationSenderStrategy2.is = is;
    })(CancellationSenderStrategy || (exports.CancellationSenderStrategy = CancellationSenderStrategy = {}));
    var CancellationStrategy;
    (function(CancellationStrategy2) {
      CancellationStrategy2.Message = Object.freeze({
        receiver: CancellationReceiverStrategy.Message,
        sender: CancellationSenderStrategy.Message
      });
      function is(value) {
        const candidate = value;
        return candidate && CancellationReceiverStrategy.is(candidate.receiver) && CancellationSenderStrategy.is(candidate.sender);
      }
      CancellationStrategy2.is = is;
    })(CancellationStrategy || (exports.CancellationStrategy = CancellationStrategy = {}));
    var MessageStrategy;
    (function(MessageStrategy2) {
      function is(value) {
        const candidate = value;
        return candidate && Is.func(candidate.handleMessage);
      }
      MessageStrategy2.is = is;
    })(MessageStrategy || (exports.MessageStrategy = MessageStrategy = {}));
    var ConnectionOptions;
    (function(ConnectionOptions2) {
      function is(value) {
        const candidate = value;
        return candidate && (CancellationStrategy.is(candidate.cancellationStrategy) || ConnectionStrategy.is(candidate.connectionStrategy) || MessageStrategy.is(candidate.messageStrategy) || Is.number(candidate.maxParallelism));
      }
      ConnectionOptions2.is = is;
    })(ConnectionOptions || (exports.ConnectionOptions = ConnectionOptions = {}));
    var ConnectionState;
    (function(ConnectionState2) {
      ConnectionState2[ConnectionState2["New"] = 1] = "New";
      ConnectionState2[ConnectionState2["Listening"] = 2] = "Listening";
      ConnectionState2[ConnectionState2["Closed"] = 3] = "Closed";
      ConnectionState2[ConnectionState2["Disposed"] = 4] = "Disposed";
    })(ConnectionState || (ConnectionState = {}));
    function createMessageConnection2(messageReader, messageWriter, _logger, options) {
      const logger = _logger !== void 0 ? _logger : exports.NullLogger;
      let sequenceNumber = 0;
      let notificationSequenceNumber = 0;
      let unknownResponseSequenceNumber = 0;
      const version = "2.0";
      const maxParallelism = options?.maxParallelism ?? -1;
      let inFlight = 0;
      let starRequestHandler = void 0;
      const requestHandlers = /* @__PURE__ */ new Map();
      let starNotificationHandler = void 0;
      const notificationHandlers = /* @__PURE__ */ new Map();
      const progressHandlers = /* @__PURE__ */ new Map();
      let timer;
      let messageQueue = new linkedMap_1.LinkedMap();
      let responsePromises = /* @__PURE__ */ new Map();
      let knownCanceledRequests = /* @__PURE__ */ new Set();
      let requestTokens = /* @__PURE__ */ new Map();
      let trace = Trace.Off;
      let traceFormat = TraceFormat.Text;
      let tracer;
      let state = ConnectionState.New;
      const errorEmitter = new events_1.Emitter();
      const closeEmitter = new events_1.Emitter();
      const unhandledNotificationEmitter = new events_1.Emitter();
      const unhandledProgressEmitter = new events_1.Emitter();
      const disposeEmitter = new events_1.Emitter();
      const cancellationStrategy = options && options.cancellationStrategy ? options.cancellationStrategy : CancellationStrategy.Message;
      function cancelUndispatched(_message) {
        return void 0;
      }
      function isListening() {
        return state === ConnectionState.Listening;
      }
      function isClosed() {
        return state === ConnectionState.Closed;
      }
      function isDisposed() {
        return state === ConnectionState.Disposed;
      }
      function closeHandler() {
        if (state === ConnectionState.New || state === ConnectionState.Listening) {
          state = ConnectionState.Closed;
          closeEmitter.fire(void 0);
        }
      }
      function readErrorHandler(error) {
        errorEmitter.fire([error, void 0, void 0]);
      }
      function writeErrorHandler(data) {
        errorEmitter.fire(data);
      }
      messageReader.onClose(closeHandler);
      messageReader.onError(readErrorHandler);
      messageWriter.onClose(closeHandler);
      messageWriter.onError(writeErrorHandler);
      function createRequestQueueKey(id) {
        if (id === null) {
          throw new Error(`Can't send requests with id null since the response can't be correlated.`);
        }
        return "req-" + id.toString();
      }
      function createResponseQueueKey(id) {
        if (id === null) {
          return "res-unknown-" + (++unknownResponseSequenceNumber).toString();
        } else {
          return "res-" + id.toString();
        }
      }
      function createNotificationQueueKey() {
        return "not-" + (++notificationSequenceNumber).toString();
      }
      function addMessageToQueue(queue, message) {
        if (messages_1.Message.isRequest(message)) {
          queue.set(createRequestQueueKey(message.id), message);
        } else if (messages_1.Message.isResponse(message)) {
          if (maxParallelism === -1) {
            queue.set(createResponseQueueKey(message.id), message);
          } else {
            handleResponse(message);
          }
        } else {
          queue.set(createNotificationQueueKey(), message);
        }
      }
      function triggerMessageQueue() {
        if (timer || messageQueue.size === 0) {
          return;
        }
        if (maxParallelism !== -1 && inFlight >= maxParallelism) {
          return;
        }
        timer = (0, ral_1.default)().timer.setImmediate(async () => {
          timer = void 0;
          if (messageQueue.size === 0) {
            return;
          }
          if (maxParallelism !== -1 && inFlight >= maxParallelism) {
            return;
          }
          const message = messageQueue.shift();
          let result;
          try {
            inFlight++;
            const messageStrategy = options?.messageStrategy;
            if (MessageStrategy.is(messageStrategy)) {
              result = messageStrategy.handleMessage(message, handleMessage);
            } else {
              result = handleMessage(message);
            }
          } catch (error) {
            logger.error(`Processing message queue failed: ${error.toString()}`);
          } finally {
            if (result instanceof Promise) {
              result.then(() => {
                inFlight--;
                triggerMessageQueue();
              }).catch((error) => {
                logger.error(`Processing message queue failed: ${error.toString()}`);
              });
            } else {
              inFlight--;
            }
            triggerMessageQueue();
          }
        });
      }
      async function handleMessage(message) {
        if (messages_1.Message.isRequest(message)) {
          return handleRequest(message);
        } else if (messages_1.Message.isNotification(message)) {
          return handleNotification(message);
        } else if (messages_1.Message.isResponse(message)) {
          return handleResponse(message);
        } else {
          return handleInvalidMessage(message);
        }
      }
      const callback = (message) => {
        try {
          if (messages_1.Message.isNotification(message) && message.method === CancelNotification.type.method) {
            const cancelId = message.params.id;
            const key = createRequestQueueKey(cancelId);
            const toCancel = messageQueue.get(key);
            if (messages_1.Message.isRequest(toCancel)) {
              const strategy = options?.connectionStrategy;
              const response = strategy && strategy.cancelUndispatched ? strategy.cancelUndispatched(toCancel, cancelUndispatched) : cancelUndispatched(toCancel);
              if (response && (response.error !== void 0 || response.result !== void 0)) {
                messageQueue.delete(key);
                requestTokens.delete(cancelId);
                response.id = toCancel.id;
                traceSendingResponse(response, message.method, Date.now());
                messageWriter.write(response).catch(() => logger.error(`Sending response for canceled message failed.`));
                return;
              }
            }
            const cancellationToken = requestTokens.get(cancelId);
            if (cancellationToken !== void 0) {
              cancellationToken.cancel();
              traceReceivedNotification(message);
              return;
            } else {
              knownCanceledRequests.add(cancelId);
            }
          }
          addMessageToQueue(messageQueue, message);
        } finally {
          triggerMessageQueue();
        }
      };
      async function handleRequest(requestMessage) {
        if (isDisposed()) {
          return Promise.resolve();
        }
        function reply(resultOrError, method, startTime2) {
          const message = {
            jsonrpc: version,
            id: requestMessage.id
          };
          if (resultOrError instanceof messages_1.ResponseError) {
            message.error = resultOrError.toJson();
          } else {
            message.result = resultOrError === void 0 ? null : resultOrError;
          }
          traceSendingResponse(message, method, startTime2);
          return messageWriter.write(message);
        }
        function replyError(error, method, startTime2) {
          const message = {
            jsonrpc: version,
            id: requestMessage.id,
            error: error.toJson()
          };
          traceSendingResponse(message, method, startTime2);
          return messageWriter.write(message);
        }
        traceReceivedRequest(requestMessage);
        const element = requestHandlers.get(requestMessage.method);
        let type;
        let requestHandler;
        if (element) {
          type = element.type;
          requestHandler = element.handler;
        }
        const startTime = Date.now();
        if (requestHandler || starRequestHandler) {
          const tokenKey = requestMessage.id ?? String(Date.now());
          const cancellationSource = IdCancellationReceiverStrategy.is(cancellationStrategy.receiver) ? cancellationStrategy.receiver.createCancellationTokenSource(tokenKey) : cancellationStrategy.receiver.createCancellationTokenSource(requestMessage);
          if (requestMessage.id !== null && knownCanceledRequests.has(requestMessage.id)) {
            cancellationSource.cancel();
          }
          if (requestMessage.id !== null) {
            requestTokens.set(tokenKey, cancellationSource);
          }
          try {
            let handlerResult;
            if (requestHandler) {
              if (requestMessage.params === void 0) {
                if (type !== void 0 && type.numberOfParams !== 0) {
                  return replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines ${type.numberOfParams} params but received none.`), requestMessage.method, startTime);
                }
                handlerResult = requestHandler(cancellationSource.token);
              } else if (Array.isArray(requestMessage.params)) {
                if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byName) {
                  return replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines parameters by name but received parameters by position`), requestMessage.method, startTime);
                }
                handlerResult = requestHandler(...requestMessage.params, cancellationSource.token);
              } else {
                if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byPosition) {
                  return replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines parameters by position but received parameters by name`), requestMessage.method, startTime);
                }
                handlerResult = requestHandler(requestMessage.params, cancellationSource.token);
              }
            } else if (starRequestHandler) {
              handlerResult = starRequestHandler(requestMessage.method, requestMessage.params, cancellationSource.token);
            }
            const resultOrError = await handlerResult;
            await reply(resultOrError, requestMessage.method, startTime);
          } catch (error) {
            if (error instanceof messages_1.ResponseError) {
              await reply(error, requestMessage.method, startTime);
            } else if (error && Is.string(error.message)) {
              await replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed with message: ${error.message}`), requestMessage.method, startTime);
            } else {
              await replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed unexpectedly without providing any details.`), requestMessage.method, startTime);
            }
          } finally {
            requestTokens.delete(tokenKey);
          }
        } else {
          await replyError(new messages_1.ResponseError(messages_1.ErrorCodes.MethodNotFound, `Unhandled method ${requestMessage.method}`), requestMessage.method, startTime);
        }
      }
      function handleResponse(responseMessage) {
        if (isDisposed()) {
          return;
        }
        if (responseMessage.id === null) {
          if (responseMessage.error) {
            logger.error(`Received response message without id: Error is: 
${JSON.stringify(responseMessage.error, void 0, 4)}`);
          } else {
            logger.error(`Received response message without id. No further error information provided.`);
          }
        } else {
          const key = responseMessage.id;
          const responsePromise = responsePromises.get(key);
          traceReceivedResponse(responseMessage, responsePromise);
          if (responsePromise !== void 0) {
            responsePromises.delete(key);
            try {
              if (responseMessage.error) {
                const error = responseMessage.error;
                responsePromise.reject(new messages_1.ResponseError(error.code, error.message, error.data));
              } else if (responseMessage.result !== void 0) {
                responsePromise.resolve(responseMessage.result);
              } else {
                throw new Error("Should never happen.");
              }
            } catch (error) {
              if (error.message) {
                logger.error(`Response handler '${responsePromise.method}' failed with message: ${error.message}`);
              } else {
                logger.error(`Response handler '${responsePromise.method}' failed unexpectedly.`);
              }
            }
          }
        }
      }
      async function handleNotification(message) {
        if (isDisposed()) {
          return;
        }
        let type = void 0;
        let notificationHandler;
        if (message.method === CancelNotification.type.method) {
          const cancelId = message.params.id;
          knownCanceledRequests.delete(cancelId);
          traceReceivedNotification(message);
          return;
        } else {
          const element = notificationHandlers.get(message.method);
          if (element) {
            notificationHandler = element.handler;
            type = element.type;
          }
        }
        if (notificationHandler || starNotificationHandler) {
          try {
            traceReceivedNotification(message);
            if (notificationHandler) {
              if (message.params === void 0) {
                if (type !== void 0) {
                  if (type.numberOfParams !== 0 && type.parameterStructures !== messages_1.ParameterStructures.byName) {
                    logger.error(`Notification ${message.method} defines ${type.numberOfParams} params but received none.`);
                  }
                }
                await notificationHandler();
              } else if (Array.isArray(message.params)) {
                const params = message.params;
                if (message.method === ProgressNotification.type.method && params.length === 2 && ProgressToken.is(params[0])) {
                  await notificationHandler({ token: params[0], value: params[1] });
                } else {
                  if (type !== void 0) {
                    if (type.parameterStructures === messages_1.ParameterStructures.byName) {
                      logger.error(`Notification ${message.method} defines parameters by name but received parameters by position`);
                    }
                    if (type.numberOfParams !== message.params.length) {
                      logger.error(`Notification ${message.method} defines ${type.numberOfParams} params but received ${params.length} arguments`);
                    }
                  }
                  await notificationHandler(...params);
                }
              } else {
                if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byPosition) {
                  logger.error(`Notification ${message.method} defines parameters by position but received parameters by name`);
                }
                await notificationHandler(message.params);
              }
            } else if (starNotificationHandler) {
              await starNotificationHandler(message.method, message.params);
            }
          } catch (error) {
            if (error.message) {
              logger.error(`Notification handler '${message.method}' failed with message: ${error.message}`);
            } else {
              logger.error(`Notification handler '${message.method}' failed unexpectedly.`);
            }
          }
        } else {
          unhandledNotificationEmitter.fire(message);
        }
      }
      function handleInvalidMessage(message) {
        if (!message) {
          logger.error("Received empty message.");
          return;
        }
        logger.error(`Received message which is neither a response nor a notification message:
${JSON.stringify(message, null, 4)}`);
        const responseMessage = message;
        if (Is.string(responseMessage.id) || Is.number(responseMessage.id)) {
          const key = responseMessage.id;
          const responseHandler = responsePromises.get(key);
          if (responseHandler) {
            responseHandler.reject(new Error("The received response has neither a result nor an error property."));
          }
        }
      }
      function stringifyTrace(params) {
        if (params === void 0 || params === null) {
          return void 0;
        }
        switch (trace) {
          case Trace.Verbose:
            return JSON.stringify(params, null, 4);
          case Trace.Compact:
            return JSON.stringify(params);
          default:
            return void 0;
        }
      }
      function traceSendingRequest(message) {
        if (trace === Trace.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if ((trace === Trace.Verbose || trace === Trace.Compact) && message.params) {
            data = `Params: ${stringifyTrace(message.params)}`;
          }
          tracer.log(`Sending request '${message.method} - (${message.id})'.`, data);
        } else {
          logLSPMessage("send-request", message);
        }
      }
      function traceSendingNotification(message) {
        if (trace === Trace.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace.Verbose || trace === Trace.Compact) {
            if (message.params) {
              data = `Params: ${stringifyTrace(message.params)}`;
            } else {
              data = "No parameters provided.";
            }
          }
          tracer.log(`Sending notification '${message.method}'.`, data);
        } else {
          logLSPMessage("send-notification", message);
        }
      }
      function traceSendingResponse(message, method, startTime) {
        if (trace === Trace.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace.Verbose || trace === Trace.Compact) {
            if (message.error && message.error.data) {
              data = `Error data: ${stringifyTrace(message.error.data)}`;
            } else {
              if (message.result) {
                data = `Result: ${stringifyTrace(message.result)}`;
              } else if (message.error === void 0) {
                data = "No result returned.";
              }
            }
          }
          tracer.log(`Sending response '${method} - (${message.id})'. Processing request took ${Date.now() - startTime}ms`, data);
        } else {
          logLSPMessage("send-response", message);
        }
      }
      function traceReceivedRequest(message) {
        if (trace === Trace.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if ((trace === Trace.Verbose || trace === Trace.Compact) && message.params) {
            data = `Params: ${stringifyTrace(message.params)}`;
          }
          tracer.log(`Received request '${message.method} - (${message.id})'.`, data);
        } else {
          logLSPMessage("receive-request", message);
        }
      }
      function traceReceivedNotification(message) {
        if (trace === Trace.Off || !tracer || message.method === LogTraceNotification.type.method) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace.Verbose || trace === Trace.Compact) {
            if (message.params) {
              data = `Params: ${stringifyTrace(message.params)}`;
            } else {
              data = "No parameters provided.";
            }
          }
          tracer.log(`Received notification '${message.method}'.`, data);
        } else {
          logLSPMessage("receive-notification", message);
        }
      }
      function traceReceivedResponse(message, responsePromise) {
        if (trace === Trace.Off || !tracer) {
          return;
        }
        if (traceFormat === TraceFormat.Text) {
          let data = void 0;
          if (trace === Trace.Verbose || trace === Trace.Compact) {
            if (message.error && message.error.data) {
              data = `Error data: ${stringifyTrace(message.error.data)}`;
            } else {
              if (message.result) {
                data = `Result: ${stringifyTrace(message.result)}`;
              } else if (message.error === void 0) {
                data = "No result returned.";
              }
            }
          }
          if (responsePromise) {
            const error = message.error ? ` Request failed: ${message.error.message} (${message.error.code}).` : "";
            tracer.log(`Received response '${responsePromise.method} - (${message.id})' in ${Date.now() - responsePromise.timerStart}ms.${error}`, data);
          } else {
            tracer.log(`Received response ${message.id} without active response promise.`, data);
          }
        } else {
          logLSPMessage("receive-response", message);
        }
      }
      function logLSPMessage(type, message) {
        if (!tracer || trace === Trace.Off) {
          return;
        }
        const lspMessage = {
          isLSPMessage: true,
          type,
          message,
          timestamp: Date.now()
        };
        tracer.log(lspMessage);
      }
      function throwIfClosedOrDisposed() {
        if (isClosed()) {
          throw new ConnectionError(ConnectionErrors.Closed, "Connection is closed.");
        }
        if (isDisposed()) {
          throw new ConnectionError(ConnectionErrors.Disposed, "Connection is disposed.");
        }
      }
      function throwIfListening() {
        if (isListening()) {
          throw new ConnectionError(ConnectionErrors.AlreadyListening, "Connection is already listening");
        }
      }
      function throwIfNotListening() {
        if (!isListening()) {
          throw new Error("Call listen() first.");
        }
      }
      function undefinedToNull(param) {
        if (param === void 0) {
          return null;
        } else {
          return param;
        }
      }
      function nullToUndefined(param) {
        if (param === null) {
          return void 0;
        } else {
          return param;
        }
      }
      function isNamedParam(param) {
        return param !== void 0 && param !== null && !Array.isArray(param) && typeof param === "object";
      }
      function computeSingleParam(parameterStructures, param) {
        switch (parameterStructures) {
          case messages_1.ParameterStructures.auto:
            if (isNamedParam(param)) {
              return nullToUndefined(param);
            } else {
              return [undefinedToNull(param)];
            }
          case messages_1.ParameterStructures.byName:
            if (!isNamedParam(param)) {
              throw new Error(`Received parameters by name but param is not an object literal.`);
            }
            return nullToUndefined(param);
          case messages_1.ParameterStructures.byPosition:
            return [undefinedToNull(param)];
          default:
            throw new Error(`Unknown parameter structure ${parameterStructures.toString()}`);
        }
      }
      function computeMessageParams(type, params) {
        let result;
        const numberOfParams = type.numberOfParams;
        switch (numberOfParams) {
          case 0:
            result = void 0;
            break;
          case 1:
            result = computeSingleParam(type.parameterStructures, params[0]);
            break;
          default:
            result = [];
            for (let i = 0; i < params.length && i < numberOfParams; i++) {
              result.push(undefinedToNull(params[i]));
            }
            if (params.length < numberOfParams) {
              for (let i = params.length; i < numberOfParams; i++) {
                result.push(null);
              }
            }
            break;
        }
        return result;
      }
      const connection = {
        sendNotification: (type, ...args) => {
          throwIfClosedOrDisposed();
          let method;
          let messageParams;
          if (Is.string(type)) {
            method = type;
            const first = args[0];
            let paramStart = 0;
            let parameterStructures = messages_1.ParameterStructures.auto;
            if (messages_1.ParameterStructures.is(first)) {
              paramStart = 1;
              parameterStructures = first;
            }
            const paramEnd = args.length;
            const numberOfParams = paramEnd - paramStart;
            switch (numberOfParams) {
              case 0:
                messageParams = void 0;
                break;
              case 1:
                messageParams = computeSingleParam(parameterStructures, args[paramStart]);
                break;
              default:
                if (parameterStructures === messages_1.ParameterStructures.byName) {
                  throw new Error(`Received ${numberOfParams} parameters for 'by Name' notification parameter structure.`);
                }
                messageParams = args.slice(paramStart, paramEnd).map((value) => undefinedToNull(value));
                break;
            }
          } else {
            const params = args;
            method = type.method;
            messageParams = computeMessageParams(type, params);
          }
          const notificationMessage = {
            jsonrpc: version,
            method,
            params: messageParams
          };
          traceSendingNotification(notificationMessage);
          return messageWriter.write(notificationMessage).catch((error) => {
            logger.error(`Sending notification failed.`);
            throw error;
          });
        },
        onNotification: (type, handler) => {
          throwIfClosedOrDisposed();
          let method;
          if (Is.func(type)) {
            starNotificationHandler = type;
          } else if (handler) {
            if (Is.string(type)) {
              method = type;
              notificationHandlers.set(type, { type: void 0, handler });
            } else {
              method = type.method;
              notificationHandlers.set(type.method, { type, handler });
            }
          }
          return {
            dispose: () => {
              if (method !== void 0) {
                if (notificationHandlers.get(method)?.handler === handler) {
                  notificationHandlers.delete(method);
                }
              } else if (starNotificationHandler === type) {
                starNotificationHandler = void 0;
              }
            }
          };
        },
        onProgress: (_type, token, handler) => {
          if (progressHandlers.has(token)) {
            throw new Error(`Progress handler for token ${token} already registered`);
          }
          progressHandlers.set(token, handler);
          return {
            dispose: () => {
              if (progressHandlers.get(token) === handler) {
                progressHandlers.delete(token);
              }
            }
          };
        },
        sendProgress: (_type, token, value) => {
          return connection.sendNotification(ProgressNotification.type, { token, value });
        },
        onUnhandledProgress: unhandledProgressEmitter.event,
        sendRequest: (type, ...args) => {
          throwIfClosedOrDisposed();
          throwIfNotListening();
          function sendCancellation(connection2, id2) {
            const p = cancellationStrategy.sender.sendCancellation(connection2, id2);
            if (p === void 0) {
              logger.log(`Received no promise from cancellation strategy when cancelling id ${id2}`);
            } else {
              p.catch(() => {
                logger.log(`Sending cancellation messages for id ${id2} failed.`);
              });
            }
          }
          let method;
          let messageParams;
          let token = void 0;
          if (Is.string(type)) {
            method = type;
            const first = args[0];
            const last = args[args.length - 1];
            let paramStart = 0;
            let parameterStructures = messages_1.ParameterStructures.auto;
            if (messages_1.ParameterStructures.is(first)) {
              paramStart = 1;
              parameterStructures = first;
            }
            let paramEnd = args.length;
            if (cancellation_1.CancellationToken.is(last)) {
              paramEnd = paramEnd - 1;
              token = last;
            }
            const numberOfParams = paramEnd - paramStart;
            switch (numberOfParams) {
              case 0:
                messageParams = void 0;
                break;
              case 1:
                messageParams = computeSingleParam(parameterStructures, args[paramStart]);
                break;
              default:
                if (parameterStructures === messages_1.ParameterStructures.byName) {
                  throw new Error(`Received ${numberOfParams} parameters for 'by Name' request parameter structure.`);
                }
                messageParams = args.slice(paramStart, paramEnd).map((value) => undefinedToNull(value));
                break;
            }
          } else {
            const params = args;
            method = type.method;
            messageParams = computeMessageParams(type, params);
            const numberOfParams = type.numberOfParams;
            token = cancellation_1.CancellationToken.is(params[numberOfParams]) ? params[numberOfParams] : void 0;
          }
          const id = sequenceNumber++;
          let disposable;
          let tokenWasCancelled = false;
          if (token !== void 0) {
            if (token.isCancellationRequested) {
              tokenWasCancelled = true;
            } else {
              disposable = token.onCancellationRequested(() => {
                sendCancellation(connection, id);
              });
            }
          }
          const requestMessage = {
            jsonrpc: version,
            id,
            method,
            params: messageParams
          };
          traceSendingRequest(requestMessage);
          if (typeof cancellationStrategy.sender.enableCancellation === "function") {
            cancellationStrategy.sender.enableCancellation(requestMessage);
          }
          return new Promise(async (resolve3, reject) => {
            const resolveWithCleanup = (r) => {
              resolve3(r);
              cancellationStrategy.sender.cleanup(id);
              disposable?.dispose();
            };
            const rejectWithCleanup = (r) => {
              reject(r);
              cancellationStrategy.sender.cleanup(id);
              disposable?.dispose();
            };
            const responsePromise = { method, timerStart: Date.now(), resolve: resolveWithCleanup, reject: rejectWithCleanup };
            try {
              responsePromises.set(id, responsePromise);
              await messageWriter.write(requestMessage);
              if (tokenWasCancelled) {
                sendCancellation(connection, id);
              }
            } catch (error) {
              responsePromises.delete(id);
              responsePromise.reject(new messages_1.ResponseError(messages_1.ErrorCodes.MessageWriteError, error.message ? error.message : "Unknown reason"));
              logger.error(`Sending request failed.`);
              throw error;
            }
          });
        },
        onRequest: (type, handler) => {
          throwIfClosedOrDisposed();
          let method = null;
          if (StarRequestHandler.is(type)) {
            method = void 0;
            starRequestHandler = type;
          } else if (Is.string(type)) {
            method = null;
            if (handler !== void 0) {
              method = type;
              requestHandlers.set(type, { handler, type: void 0 });
            }
          } else {
            if (handler !== void 0) {
              method = type.method;
              requestHandlers.set(type.method, { type, handler });
            }
          }
          return {
            dispose: () => {
              if (method === null) {
                return;
              }
              if (method !== void 0) {
                if (requestHandlers.get(method)?.handler === handler) {
                  requestHandlers.delete(method);
                }
              } else if (starRequestHandler === type) {
                starRequestHandler = void 0;
              }
            }
          };
        },
        hasPendingResponse: () => {
          return responsePromises.size > 0;
        },
        trace: async (_value, _tracer, sendNotificationOrTraceOptions) => {
          let _sendNotification = false;
          let _traceFormat = TraceFormat.Text;
          if (sendNotificationOrTraceOptions !== void 0) {
            if (Is.boolean(sendNotificationOrTraceOptions)) {
              _sendNotification = sendNotificationOrTraceOptions;
            } else {
              _sendNotification = sendNotificationOrTraceOptions.sendNotification || false;
              _traceFormat = sendNotificationOrTraceOptions.traceFormat || TraceFormat.Text;
            }
          }
          trace = _value;
          traceFormat = _traceFormat;
          if (trace === Trace.Off) {
            tracer = void 0;
          } else {
            tracer = _tracer;
          }
          if (_sendNotification && !isClosed() && !isDisposed()) {
            await connection.sendNotification(SetTraceNotification.type, { value: Trace.toString(_value) });
          }
        },
        onError: errorEmitter.event,
        onClose: closeEmitter.event,
        onUnhandledNotification: unhandledNotificationEmitter.event,
        onDispose: disposeEmitter.event,
        end: () => {
          messageWriter.end();
        },
        dispose: () => {
          if (isDisposed()) {
            return;
          }
          state = ConnectionState.Disposed;
          disposeEmitter.fire(void 0);
          const error = new messages_1.ResponseError(messages_1.ErrorCodes.PendingResponseRejected, "Pending response rejected since connection got disposed");
          for (const promise of responsePromises.values()) {
            promise.reject(error);
          }
          responsePromises = /* @__PURE__ */ new Map();
          requestTokens = /* @__PURE__ */ new Map();
          knownCanceledRequests = /* @__PURE__ */ new Set();
          messageQueue = new linkedMap_1.LinkedMap();
          if (Is.func(messageWriter.dispose)) {
            messageWriter.dispose();
          }
          if (Is.func(messageReader.dispose)) {
            messageReader.dispose();
          }
        },
        listen: () => {
          throwIfClosedOrDisposed();
          throwIfListening();
          state = ConnectionState.Listening;
          messageReader.listen(callback);
        },
        inspect: () => {
          (0, ral_1.default)().console.log("inspect");
        }
      };
      connection.onNotification(LogTraceNotification.type, (params) => {
        if (trace === Trace.Off || !tracer) {
          return;
        }
        const verbose = trace === Trace.Verbose || trace === Trace.Compact;
        tracer.log(params.message, verbose ? params.verbose : void 0);
      });
      connection.onNotification(ProgressNotification.type, async (params) => {
        const handler = progressHandlers.get(params.token);
        if (handler) {
          await handler(params.value);
        } else {
          unhandledProgressEmitter.fire(params);
        }
      });
      return connection;
    }
  }
});

// node_modules/vscode-jsonrpc/lib/common/api.js
var require_api = __commonJS({
  "node_modules/vscode-jsonrpc/lib/common/api.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ProgressType = exports.ProgressToken = exports.createMessageConnection = exports.NullLogger = exports.ConnectionOptions = exports.ConnectionStrategy = exports.AbstractMessageBuffer = exports.WriteableStreamMessageWriter = exports.AbstractMessageWriter = exports.MessageWriter = exports.ReadableStreamMessageReader = exports.AbstractMessageReader = exports.MessageReader = exports.SharedArrayReceiverStrategy = exports.SharedArraySenderStrategy = exports.CancellationToken = exports.CancellationTokenSource = exports.Emitter = exports.Event = exports.Disposable = exports.LRUCache = exports.Touch = exports.LinkedMap = exports.ParameterStructures = exports.NotificationType9 = exports.NotificationType8 = exports.NotificationType7 = exports.NotificationType6 = exports.NotificationType5 = exports.NotificationType4 = exports.NotificationType3 = exports.NotificationType2 = exports.NotificationType1 = exports.NotificationType0 = exports.NotificationType = exports.ErrorCodes = exports.ResponseError = exports.RequestType9 = exports.RequestType8 = exports.RequestType7 = exports.RequestType6 = exports.RequestType5 = exports.RequestType4 = exports.RequestType3 = exports.RequestType2 = exports.RequestType1 = exports.RequestType0 = exports.RequestType = exports.Message = exports.RAL = void 0;
    exports.MessageStrategy = exports.CancellationStrategy = exports.CancellationSenderStrategy = exports.RequestCancellationReceiverStrategy = exports.IdCancellationReceiverStrategy = exports.CancellationReceiverStrategy = exports.ConnectionError = exports.ConnectionErrors = exports.LogTraceNotification = exports.SetTraceNotification = exports.TraceFormat = exports.TraceValues = exports.TraceValue = exports.Trace = void 0;
    var messages_1 = require_messages();
    Object.defineProperty(exports, "Message", { enumerable: true, get: function() {
      return messages_1.Message;
    } });
    Object.defineProperty(exports, "RequestType", { enumerable: true, get: function() {
      return messages_1.RequestType;
    } });
    Object.defineProperty(exports, "RequestType0", { enumerable: true, get: function() {
      return messages_1.RequestType0;
    } });
    Object.defineProperty(exports, "RequestType1", { enumerable: true, get: function() {
      return messages_1.RequestType1;
    } });
    Object.defineProperty(exports, "RequestType2", { enumerable: true, get: function() {
      return messages_1.RequestType2;
    } });
    Object.defineProperty(exports, "RequestType3", { enumerable: true, get: function() {
      return messages_1.RequestType3;
    } });
    Object.defineProperty(exports, "RequestType4", { enumerable: true, get: function() {
      return messages_1.RequestType4;
    } });
    Object.defineProperty(exports, "RequestType5", { enumerable: true, get: function() {
      return messages_1.RequestType5;
    } });
    Object.defineProperty(exports, "RequestType6", { enumerable: true, get: function() {
      return messages_1.RequestType6;
    } });
    Object.defineProperty(exports, "RequestType7", { enumerable: true, get: function() {
      return messages_1.RequestType7;
    } });
    Object.defineProperty(exports, "RequestType8", { enumerable: true, get: function() {
      return messages_1.RequestType8;
    } });
    Object.defineProperty(exports, "RequestType9", { enumerable: true, get: function() {
      return messages_1.RequestType9;
    } });
    Object.defineProperty(exports, "ResponseError", { enumerable: true, get: function() {
      return messages_1.ResponseError;
    } });
    Object.defineProperty(exports, "ErrorCodes", { enumerable: true, get: function() {
      return messages_1.ErrorCodes;
    } });
    Object.defineProperty(exports, "NotificationType", { enumerable: true, get: function() {
      return messages_1.NotificationType;
    } });
    Object.defineProperty(exports, "NotificationType0", { enumerable: true, get: function() {
      return messages_1.NotificationType0;
    } });
    Object.defineProperty(exports, "NotificationType1", { enumerable: true, get: function() {
      return messages_1.NotificationType1;
    } });
    Object.defineProperty(exports, "NotificationType2", { enumerable: true, get: function() {
      return messages_1.NotificationType2;
    } });
    Object.defineProperty(exports, "NotificationType3", { enumerable: true, get: function() {
      return messages_1.NotificationType3;
    } });
    Object.defineProperty(exports, "NotificationType4", { enumerable: true, get: function() {
      return messages_1.NotificationType4;
    } });
    Object.defineProperty(exports, "NotificationType5", { enumerable: true, get: function() {
      return messages_1.NotificationType5;
    } });
    Object.defineProperty(exports, "NotificationType6", { enumerable: true, get: function() {
      return messages_1.NotificationType6;
    } });
    Object.defineProperty(exports, "NotificationType7", { enumerable: true, get: function() {
      return messages_1.NotificationType7;
    } });
    Object.defineProperty(exports, "NotificationType8", { enumerable: true, get: function() {
      return messages_1.NotificationType8;
    } });
    Object.defineProperty(exports, "NotificationType9", { enumerable: true, get: function() {
      return messages_1.NotificationType9;
    } });
    Object.defineProperty(exports, "ParameterStructures", { enumerable: true, get: function() {
      return messages_1.ParameterStructures;
    } });
    var linkedMap_1 = require_linkedMap();
    Object.defineProperty(exports, "LinkedMap", { enumerable: true, get: function() {
      return linkedMap_1.LinkedMap;
    } });
    Object.defineProperty(exports, "LRUCache", { enumerable: true, get: function() {
      return linkedMap_1.LRUCache;
    } });
    Object.defineProperty(exports, "Touch", { enumerable: true, get: function() {
      return linkedMap_1.Touch;
    } });
    var disposable_1 = require_disposable();
    Object.defineProperty(exports, "Disposable", { enumerable: true, get: function() {
      return disposable_1.Disposable;
    } });
    var events_1 = require_events();
    Object.defineProperty(exports, "Event", { enumerable: true, get: function() {
      return events_1.Event;
    } });
    Object.defineProperty(exports, "Emitter", { enumerable: true, get: function() {
      return events_1.Emitter;
    } });
    var cancellation_1 = require_cancellation();
    Object.defineProperty(exports, "CancellationTokenSource", { enumerable: true, get: function() {
      return cancellation_1.CancellationTokenSource;
    } });
    Object.defineProperty(exports, "CancellationToken", { enumerable: true, get: function() {
      return cancellation_1.CancellationToken;
    } });
    var sharedArrayCancellation_1 = require_sharedArrayCancellation();
    Object.defineProperty(exports, "SharedArraySenderStrategy", { enumerable: true, get: function() {
      return sharedArrayCancellation_1.SharedArraySenderStrategy;
    } });
    Object.defineProperty(exports, "SharedArrayReceiverStrategy", { enumerable: true, get: function() {
      return sharedArrayCancellation_1.SharedArrayReceiverStrategy;
    } });
    var messageReader_1 = require_messageReader();
    Object.defineProperty(exports, "MessageReader", { enumerable: true, get: function() {
      return messageReader_1.MessageReader;
    } });
    Object.defineProperty(exports, "AbstractMessageReader", { enumerable: true, get: function() {
      return messageReader_1.AbstractMessageReader;
    } });
    Object.defineProperty(exports, "ReadableStreamMessageReader", { enumerable: true, get: function() {
      return messageReader_1.ReadableStreamMessageReader;
    } });
    var messageWriter_1 = require_messageWriter();
    Object.defineProperty(exports, "MessageWriter", { enumerable: true, get: function() {
      return messageWriter_1.MessageWriter;
    } });
    Object.defineProperty(exports, "AbstractMessageWriter", { enumerable: true, get: function() {
      return messageWriter_1.AbstractMessageWriter;
    } });
    Object.defineProperty(exports, "WriteableStreamMessageWriter", { enumerable: true, get: function() {
      return messageWriter_1.WriteableStreamMessageWriter;
    } });
    var messageBuffer_1 = require_messageBuffer();
    Object.defineProperty(exports, "AbstractMessageBuffer", { enumerable: true, get: function() {
      return messageBuffer_1.AbstractMessageBuffer;
    } });
    var connection_1 = require_connection();
    Object.defineProperty(exports, "ConnectionStrategy", { enumerable: true, get: function() {
      return connection_1.ConnectionStrategy;
    } });
    Object.defineProperty(exports, "ConnectionOptions", { enumerable: true, get: function() {
      return connection_1.ConnectionOptions;
    } });
    Object.defineProperty(exports, "NullLogger", { enumerable: true, get: function() {
      return connection_1.NullLogger;
    } });
    Object.defineProperty(exports, "createMessageConnection", { enumerable: true, get: function() {
      return connection_1.createMessageConnection;
    } });
    Object.defineProperty(exports, "ProgressToken", { enumerable: true, get: function() {
      return connection_1.ProgressToken;
    } });
    Object.defineProperty(exports, "ProgressType", { enumerable: true, get: function() {
      return connection_1.ProgressType;
    } });
    Object.defineProperty(exports, "Trace", { enumerable: true, get: function() {
      return connection_1.Trace;
    } });
    Object.defineProperty(exports, "TraceValue", { enumerable: true, get: function() {
      return connection_1.TraceValue;
    } });
    Object.defineProperty(exports, "TraceFormat", { enumerable: true, get: function() {
      return connection_1.TraceFormat;
    } });
    Object.defineProperty(exports, "SetTraceNotification", { enumerable: true, get: function() {
      return connection_1.SetTraceNotification;
    } });
    Object.defineProperty(exports, "LogTraceNotification", { enumerable: true, get: function() {
      return connection_1.LogTraceNotification;
    } });
    Object.defineProperty(exports, "ConnectionErrors", { enumerable: true, get: function() {
      return connection_1.ConnectionErrors;
    } });
    Object.defineProperty(exports, "ConnectionError", { enumerable: true, get: function() {
      return connection_1.ConnectionError;
    } });
    Object.defineProperty(exports, "CancellationReceiverStrategy", { enumerable: true, get: function() {
      return connection_1.CancellationReceiverStrategy;
    } });
    Object.defineProperty(exports, "IdCancellationReceiverStrategy", { enumerable: true, get: function() {
      return connection_1.IdCancellationReceiverStrategy;
    } });
    Object.defineProperty(exports, "RequestCancellationReceiverStrategy", { enumerable: true, get: function() {
      return connection_1.RequestCancellationReceiverStrategy;
    } });
    Object.defineProperty(exports, "CancellationSenderStrategy", { enumerable: true, get: function() {
      return connection_1.CancellationSenderStrategy;
    } });
    Object.defineProperty(exports, "CancellationStrategy", { enumerable: true, get: function() {
      return connection_1.CancellationStrategy;
    } });
    Object.defineProperty(exports, "MessageStrategy", { enumerable: true, get: function() {
      return connection_1.MessageStrategy;
    } });
    Object.defineProperty(exports, "TraceValues", { enumerable: true, get: function() {
      return connection_1.TraceValues;
    } });
    var ral_1 = __importDefault(require_ral());
    exports.RAL = ral_1.default;
  }
});

// node_modules/vscode-jsonrpc/lib/node/ril.js
var require_ril = __commonJS({
  "node_modules/vscode-jsonrpc/lib/node/ril.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    Object.defineProperty(exports, "__esModule", { value: true });
    var util_1 = __require("util");
    var api_1 = require_api();
    var MessageBuffer = class _MessageBuffer extends api_1.AbstractMessageBuffer {
      static emptyBuffer = Buffer.allocUnsafe(0);
      constructor(encoding = "utf-8") {
        super(encoding);
      }
      emptyBuffer() {
        return _MessageBuffer.emptyBuffer;
      }
      fromString(value, encoding) {
        return Buffer.from(value, encoding);
      }
      toString(value, encoding) {
        if (value instanceof Buffer) {
          return value.toString(encoding);
        } else {
          return new util_1.TextDecoder(encoding).decode(value);
        }
      }
      asNative(buffer, length) {
        if (length === void 0) {
          return buffer instanceof Buffer ? buffer : Buffer.from(buffer);
        } else {
          return buffer instanceof Buffer ? buffer.slice(0, length) : Buffer.from(buffer, 0, length);
        }
      }
      allocNative(length) {
        return Buffer.allocUnsafe(length);
      }
    };
    var ReadableStreamWrapper = class {
      stream;
      constructor(stream) {
        this.stream = stream;
      }
      onClose(listener) {
        this.stream.on("close", listener);
        return api_1.Disposable.create(() => this.stream.off("close", listener));
      }
      onError(listener) {
        this.stream.on("error", listener);
        return api_1.Disposable.create(() => this.stream.off("error", listener));
      }
      onEnd(listener) {
        this.stream.on("end", listener);
        return api_1.Disposable.create(() => this.stream.off("end", listener));
      }
      onData(listener) {
        this.stream.on("data", listener);
        return api_1.Disposable.create(() => this.stream.off("data", listener));
      }
    };
    var WritableStreamWrapper = class {
      stream;
      constructor(stream) {
        this.stream = stream;
      }
      onClose(listener) {
        this.stream.on("close", listener);
        return api_1.Disposable.create(() => this.stream.off("close", listener));
      }
      onError(listener) {
        this.stream.on("error", listener);
        return api_1.Disposable.create(() => this.stream.off("error", listener));
      }
      onEnd(listener) {
        this.stream.on("end", listener);
        return api_1.Disposable.create(() => this.stream.off("end", listener));
      }
      write(data, encoding) {
        return new Promise((resolve3, reject) => {
          const callback = (error) => {
            if (error === void 0 || error === null) {
              resolve3();
            } else {
              reject(error);
            }
          };
          if (typeof data === "string") {
            this.stream.write(data, encoding, callback);
          } else {
            this.stream.write(data, callback);
          }
        });
      }
      end() {
        this.stream.end();
      }
    };
    var _ril = Object.freeze({
      messageBuffer: Object.freeze({
        create: (encoding) => new MessageBuffer(encoding)
      }),
      applicationJson: Object.freeze({
        encoder: Object.freeze({
          name: "application/json",
          encode: (msg, options) => {
            try {
              return Promise.resolve(Buffer.from(JSON.stringify(msg, void 0, 0), options.charset));
            } catch (err) {
              return Promise.reject(err);
            }
          }
        }),
        decoder: Object.freeze({
          name: "application/json",
          decode: (buffer, options) => {
            try {
              if (buffer instanceof Buffer) {
                return Promise.resolve(JSON.parse(buffer.toString(options.charset)));
              } else {
                return Promise.resolve(JSON.parse(new util_1.TextDecoder(options.charset).decode(buffer)));
              }
            } catch (err) {
              return Promise.reject(err);
            }
          }
        })
      }),
      stream: Object.freeze({
        asReadableStream: (stream) => new ReadableStreamWrapper(stream),
        asWritableStream: (stream) => new WritableStreamWrapper(stream)
      }),
      console,
      timer: Object.freeze({
        setTimeout(callback, ms, ...args) {
          const handle = setTimeout(callback, ms, ...args);
          return { dispose: () => clearTimeout(handle) };
        },
        setImmediate(callback, ...args) {
          const handle = setImmediate(callback, ...args);
          return { dispose: () => clearImmediate(handle) };
        },
        setInterval(callback, ms, ...args) {
          const handle = setInterval(callback, ms, ...args);
          return { dispose: () => clearInterval(handle) };
        }
      })
    });
    function RIL() {
      return _ril;
    }
    (function(RIL2) {
      function install() {
        api_1.RAL.install(_ril);
      }
      RIL2.install = install;
    })(RIL || (RIL = {}));
    exports.default = RIL;
  }
});

// node_modules/vscode-jsonrpc/lib/node/main.js
var require_main = __commonJS({
  "node_modules/vscode-jsonrpc/lib/node/main.js"(exports) {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports && exports.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    var __exportStar = exports && exports.__exportStar || function(m, exports2) {
      for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports2, p)) __createBinding(exports2, m, p);
    };
    var __importDefault = exports && exports.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.StreamMessageWriter = exports.StreamMessageReader = exports.SocketMessageWriter = exports.SocketMessageReader = exports.PortMessageWriter = exports.PortMessageReader = exports.IPCMessageWriter = exports.IPCMessageReader = void 0;
    exports.generateRandomPipeName = generateRandomPipeName;
    exports.createClientPipeTransport = createClientPipeTransport;
    exports.createServerPipeTransport = createServerPipeTransport;
    exports.createClientSocketTransport = createClientSocketTransport;
    exports.createServerSocketTransport = createServerSocketTransport;
    exports.createMessageConnection = createMessageConnection2;
    var ril_1 = __importDefault(require_ril());
    ril_1.default.install();
    var path = __importStar(__require("path"));
    var os = __importStar(__require("os"));
    var fs = __importStar(__require("fs"));
    var crypto_1 = __require("crypto");
    var net_1 = __require("net");
    var api_1 = require_api();
    __exportStar(require_api(), exports);
    var IPCMessageReader = class extends api_1.AbstractMessageReader {
      process;
      constructor(process2) {
        super();
        this.process = process2;
        const eventEmitter = this.process;
        eventEmitter.on("error", (error) => this.fireError(error));
        eventEmitter.on("close", () => this.fireClose());
      }
      listen(callback) {
        this.process.on("message", callback);
        return api_1.Disposable.create(() => this.process.off("message", callback));
      }
    };
    exports.IPCMessageReader = IPCMessageReader;
    var IPCMessageWriter = class extends api_1.AbstractMessageWriter {
      process;
      errorCount;
      constructor(process2) {
        super();
        this.process = process2;
        this.errorCount = 0;
        const eventEmitter = this.process;
        eventEmitter.on("error", (error) => this.fireError(error));
        eventEmitter.on("close", () => this.fireClose);
      }
      write(msg) {
        try {
          if (typeof this.process.send === "function") {
            this.process.send(msg, void 0, void 0, (error) => {
              if (error) {
                this.errorCount++;
                this.handleError(error, msg);
              } else {
                this.errorCount = 0;
              }
            });
          }
          return Promise.resolve();
        } catch (error) {
          this.handleError(error, msg);
          return Promise.reject(error);
        }
      }
      handleError(error, msg) {
        this.errorCount++;
        this.fireError(error, msg, this.errorCount);
      }
      end() {
      }
    };
    exports.IPCMessageWriter = IPCMessageWriter;
    var PortMessageReader = class extends api_1.AbstractMessageReader {
      onData;
      constructor(port) {
        super();
        this.onData = new api_1.Emitter();
        port.on("close", () => this.fireClose);
        port.on("error", (error) => this.fireError(error));
        port.on("message", (message) => {
          this.onData.fire(message);
        });
      }
      listen(callback) {
        return this.onData.event(callback);
      }
    };
    exports.PortMessageReader = PortMessageReader;
    var PortMessageWriter = class extends api_1.AbstractMessageWriter {
      port;
      errorCount;
      constructor(port) {
        super();
        this.port = port;
        this.errorCount = 0;
        port.on("close", () => this.fireClose());
        port.on("error", (error) => this.fireError(error));
      }
      write(msg) {
        try {
          this.port.postMessage(msg);
          return Promise.resolve();
        } catch (error) {
          this.handleError(error, msg);
          return Promise.reject(error);
        }
      }
      handleError(error, msg) {
        this.errorCount++;
        this.fireError(error, msg, this.errorCount);
      }
      end() {
      }
    };
    exports.PortMessageWriter = PortMessageWriter;
    var SocketMessageReader = class extends api_1.ReadableStreamMessageReader {
      constructor(socket, encoding = "utf-8") {
        super((0, ril_1.default)().stream.asReadableStream(socket), encoding);
      }
    };
    exports.SocketMessageReader = SocketMessageReader;
    var SocketMessageWriter = class extends api_1.WriteableStreamMessageWriter {
      socket;
      constructor(socket, options) {
        super((0, ril_1.default)().stream.asWritableStream(socket), options);
        this.socket = socket;
      }
      dispose() {
        super.dispose();
        this.socket.destroy();
      }
    };
    exports.SocketMessageWriter = SocketMessageWriter;
    var StreamMessageReader = class extends api_1.ReadableStreamMessageReader {
      constructor(readable, encoding) {
        super((0, ril_1.default)().stream.asReadableStream(readable), encoding);
      }
    };
    exports.StreamMessageReader = StreamMessageReader;
    var StreamMessageWriter = class extends api_1.WriteableStreamMessageWriter {
      constructor(writable, options) {
        super((0, ril_1.default)().stream.asWritableStream(writable), options);
      }
    };
    exports.StreamMessageWriter = StreamMessageWriter;
    var XDG_RUNTIME_DIR = process.env["XDG_RUNTIME_DIR"];
    var safeIpcPathLengths = /* @__PURE__ */ new Map([
      ["linux", 107],
      ["darwin", 102]
    ]);
    function generateRandomPipeName() {
      if (process.platform === "win32") {
        return `\\\\.\\pipe\\lsp-${(0, crypto_1.randomBytes)(16).toString("hex")}-sock`;
      }
      let randomLength = 32;
      const fixedLength = "/lsp-.sock".length;
      const tmpDir = fs.realpathSync(XDG_RUNTIME_DIR ?? os.tmpdir());
      const limit = safeIpcPathLengths.get(process.platform);
      if (limit !== void 0) {
        randomLength = Math.min(limit - tmpDir.length - fixedLength, randomLength);
      }
      if (randomLength < 16) {
        throw new Error(`Unable to generate a random pipe name with ${randomLength} characters.`);
      }
      const randomSuffix = (0, crypto_1.randomBytes)(Math.floor(randomLength / 2)).toString("hex");
      return path.join(tmpDir, `lsp-${randomSuffix}.sock`);
    }
    function createClientPipeTransport(pipeName, encoding = "utf-8") {
      let connectResolve;
      const connected = new Promise((resolve3, _reject) => {
        connectResolve = resolve3;
      });
      return new Promise((resolve3, reject) => {
        const server = (0, net_1.createServer)((socket) => {
          server.close();
          connectResolve([
            new SocketMessageReader(socket, encoding),
            new SocketMessageWriter(socket, encoding)
          ]);
        });
        server.on("error", reject);
        server.listen(pipeName, () => {
          server.removeListener("error", reject);
          resolve3({
            onConnected: () => {
              return connected;
            }
          });
        });
      });
    }
    function createServerPipeTransport(pipeName, encoding = "utf-8") {
      const socket = (0, net_1.createConnection)(pipeName);
      return [
        new SocketMessageReader(socket, encoding),
        new SocketMessageWriter(socket, encoding)
      ];
    }
    function createClientSocketTransport(port, encoding = "utf-8") {
      let connectResolve;
      const connected = new Promise((resolve3, _reject) => {
        connectResolve = resolve3;
      });
      return new Promise((resolve3, reject) => {
        const server = (0, net_1.createServer)((socket) => {
          server.close();
          connectResolve([
            new SocketMessageReader(socket, encoding),
            new SocketMessageWriter(socket, encoding)
          ]);
        });
        server.on("error", reject);
        server.listen(port, "127.0.0.1", () => {
          server.removeListener("error", reject);
          resolve3({
            onConnected: () => {
              return connected;
            }
          });
        });
      });
    }
    function createServerSocketTransport(port, encoding = "utf-8") {
      const socket = (0, net_1.createConnection)(port, "127.0.0.1");
      return [
        new SocketMessageReader(socket, encoding),
        new SocketMessageWriter(socket, encoding)
      ];
    }
    function isReadableStream(value) {
      const candidate = value;
      return candidate.read !== void 0 && candidate.addListener !== void 0;
    }
    function isWritableStream(value) {
      const candidate = value;
      return candidate.write !== void 0 && candidate.addListener !== void 0;
    }
    function createMessageConnection2(input, output, logger, options) {
      if (!logger) {
        logger = api_1.NullLogger;
      }
      const reader = isReadableStream(input) ? new StreamMessageReader(input) : input;
      const writer = isWritableStream(output) ? new StreamMessageWriter(output) : output;
      if (api_1.ConnectionStrategy.is(options)) {
        options = { connectionStrategy: options };
      }
      return (0, api_1.createMessageConnection)(reader, writer, logger, options);
    }
  }
});

// shared/browser-rpc/src/connection/browserRpcMethod.ts
function defineBrowserRpcMethod(name, parseParams, parseResult, options = {}) {
  const method = Object.freeze({
    name,
    cancellationMode: options.cancellationMode ?? "eager",
    parseParams,
    parseResult
  });
  requestTypes.set(
    method,
    new import_vscode_jsonrpc.RequestType(name, import_vscode_jsonrpc.ParameterStructures.byName)
  );
  return method;
}
function defineBrowserRpcNotification(name, parseParams) {
  const notification = Object.freeze({ name, parseParams });
  notificationTypes.set(
    notification,
    new import_vscode_jsonrpc.NotificationType(name, import_vscode_jsonrpc.ParameterStructures.byName)
  );
  return notification;
}
function getBrowserRpcNotificationType(notification) {
  const notificationType = notificationTypes.get(notification);
  if (!notificationType) {
    throw new TypeError(
      "Browser RPC notifications must be created with defineBrowserRpcNotification()."
    );
  }
  return notificationType;
}
function getBrowserRpcRequestType(method) {
  const requestType = requestTypes.get(method);
  if (!requestType) {
    throw new TypeError("Browser RPC methods must be created with defineBrowserRpcMethod().");
  }
  return requestType;
}
var import_vscode_jsonrpc, requestTypes, notificationTypes;
var init_browserRpcMethod = __esm({
  "shared/browser-rpc/src/connection/browserRpcMethod.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    import_vscode_jsonrpc = __toESM(require_main(), 1);
    requestTypes = /* @__PURE__ */ new WeakMap();
    notificationTypes = /* @__PURE__ */ new WeakMap();
  }
});

// shared/browser-rpc/src/protocol/extensionRpc.ts
function parseExtensionInitializeResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Extension initialize result must be an object.");
  }
  return {
    protocolVersion: requireVersion(value.protocolVersion, "protocolVersion"),
    nativeHostVersion: requireString(value.nativeHostVersion, "nativeHostVersion"),
    endpointId: requireString(value.endpointId, "endpointId")
  };
}
var ExtensionInitialize, ExtensionGetInfo;
var init_extensionRpc = __esm({
  "shared/browser-rpc/src/protocol/extensionRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_extensionInfo();
    init_browserRpcMethod();
    init_validation();
    ExtensionInitialize = defineBrowserRpcMethod(
      "extension.initialize",
      parseExtensionInfo,
      parseExtensionInitializeResult
    );
    ExtensionGetInfo = defineBrowserRpcMethod(
      "extension.getInfo",
      parseEmptyParams,
      parseExtensionInfo
    );
  }
});

// shared/browser-rpc/src/protocol/browserConnectionUrl.ts
function normalizeBrowserConnectionUrl(input) {
  if (input.length === 0 || input.length > BROWSER_CONNECTION_URL_CONSTRAINTS.maxLength) {
    return void 0;
  }
  try {
    const parsed = new URL(input);
    const supportedProtocol = parsed.protocol === "https:" || parsed.protocol === "http:" && LOOPBACK_HTTP_HOSTS.has(parsed.hostname);
    if (!supportedProtocol || parsed.username || parsed.password || parsed.href.length > BROWSER_CONNECTION_URL_CONSTRAINTS.maxLength) {
      return void 0;
    }
    return parsed.href;
  } catch {
    return void 0;
  }
}
var BROWSER_CONNECTION_URL_CONSTRAINTS, LOOPBACK_HTTP_HOSTS;
var init_browserConnectionUrl = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionUrl.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    BROWSER_CONNECTION_URL_CONSTRAINTS = { maxLength: 8192 };
    LOOPBACK_HTTP_HOSTS = /* @__PURE__ */ new Set(["localhost", "127.0.0.1", "[::1]"]);
  }
});

// shared/browser-rpc/src/protocol/browserAccessOrigin.ts
function normalizeBrowserAccessOrigin(input) {
  if (input.length === 0 || input.length > BROWSER_CONNECTION_URL_CONSTRAINTS.maxLength) {
    return void 0;
  }
  try {
    const url = new URL(input);
    if (url.protocol !== "https:" && url.protocol !== "http:" || url.username || url.password) {
      return void 0;
    }
    return url.origin;
  } catch {
    return void 0;
  }
}
function isCanonicalBrowserAccessOrigin(value) {
  return typeof value === "string" && normalizeBrowserAccessOrigin(value) === value;
}
var init_browserAccessOrigin = __esm({
  "shared/browser-rpc/src/protocol/browserAccessOrigin.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserConnectionUrl();
  }
});

// shared/browser-rpc/src/protocol/browserApproval.ts
function isCanonicalBrowserFrameAccessOrigin(value) {
  return isCanonicalBrowserAccessOrigin(value) && value.length <= MAX_BROWSER_FRAME_ACCESS_ORIGIN_LENGTH;
}
function isBrowserPageOperation(value) {
  return typeof value === "string" && BROWSER_PAGE_OPERATION_SET.has(value);
}
var MAX_BROWSER_FRAME_ACCESS_ORIGINS, MAX_BROWSER_FRAME_ACCESS_ORIGIN_LENGTH, MAX_BROWSER_FRAME_ACCESS_FRAMES, BROWSER_PAGE_OPERATIONS, BROWSER_PAGE_OPERATION_SET;
var init_browserApproval = __esm({
  "shared/browser-rpc/src/protocol/browserApproval.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserAccessOrigin();
    MAX_BROWSER_FRAME_ACCESS_ORIGINS = 32;
    MAX_BROWSER_FRAME_ACCESS_ORIGIN_LENGTH = 267;
    MAX_BROWSER_FRAME_ACCESS_FRAMES = 64;
    BROWSER_PAGE_OPERATIONS = [
      "snapshot",
      "screenshot",
      "click",
      "keyboard",
      "type",
      "hover",
      "run"
    ];
    BROWSER_PAGE_OPERATION_SET = new Set(BROWSER_PAGE_OPERATIONS);
  }
});

// shared/browser-rpc/src/protocol/browserToolCallPolicy.ts
function parseBrowserToolTimeoutMs(value) {
  if (value === void 0) return void 0;
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1 || value > MAX_EXECUTION_TIMEOUT_MS) {
    throw new BrowserRpcProtocolError(
      `timeoutMs must be an integer between 1 and ${MAX_EXECUTION_TIMEOUT_MS}.`
    );
  }
  return value;
}
function browserToolExecutionTimeoutMs({
  timeoutMs,
  sequentialText
} = {}) {
  const explicitTimeout = parseBrowserToolTimeoutMs(timeoutMs);
  if (explicitTimeout !== void 0) return explicitTimeout;
  const pacingMs = sequentialText === void 0 ? 0 : Math.max(0, Array.from(sequentialText).length - 1) * BROWSER_SEQUENTIAL_INPUT_DELAY_MS;
  return Math.min(EXECUTION_TIMEOUT_MS + pacingMs, MAX_EXECUTION_TIMEOUT_MS);
}
var APPROVAL_TIMEOUT_MS, EXECUTION_TIMEOUT_MS, MAX_EXECUTION_TIMEOUT_MS, RESPONSE_DELIVERY_GRACE_MS, APPROVAL_POPUP_RETRY_DELAY_MS, APPROVAL_QUEUE_CAPACITY, MAX_APPROVAL_QUEUE_WAIT_MS, BROWSER_TOOL_CALL_TIMING, BROWSER_SEQUENTIAL_INPUT_DELAY_MS;
var init_browserToolCallPolicy = __esm({
  "shared/browser-rpc/src/protocol/browserToolCallPolicy.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    APPROVAL_TIMEOUT_MS = 6e4;
    EXECUTION_TIMEOUT_MS = 3e4;
    MAX_EXECUTION_TIMEOUT_MS = 12e4;
    RESPONSE_DELIVERY_GRACE_MS = 5e3;
    APPROVAL_POPUP_RETRY_DELAY_MS = APPROVAL_TIMEOUT_MS / 4;
    APPROVAL_QUEUE_CAPACITY = 4;
    MAX_APPROVAL_QUEUE_WAIT_MS = (APPROVAL_QUEUE_CAPACITY - 1) * (APPROVAL_TIMEOUT_MS + RESPONSE_DELIVERY_GRACE_MS);
    BROWSER_TOOL_CALL_TIMING = Object.freeze({
      approvalQueueCapacity: APPROVAL_QUEUE_CAPACITY,
      maxApprovalQueueWaitMs: MAX_APPROVAL_QUEUE_WAIT_MS,
      approvalDecisionTimeoutMs: APPROVAL_TIMEOUT_MS,
      executionTimeoutMs: EXECUTION_TIMEOUT_MS,
      maxExecutionTimeoutMs: MAX_EXECUTION_TIMEOUT_MS,
      responseDeliveryGraceMs: RESPONSE_DELIVERY_GRACE_MS,
      approvalPopupRetryDelayMs: APPROVAL_POPUP_RETRY_DELAY_MS,
      extensionRequestTimeoutMs: MAX_APPROVAL_QUEUE_WAIT_MS + APPROVAL_TIMEOUT_MS + MAX_EXECUTION_TIMEOUT_MS + RESPONSE_DELIVERY_GRACE_MS,
      mcpRequestTimeoutMs: MAX_APPROVAL_QUEUE_WAIT_MS + APPROVAL_TIMEOUT_MS + MAX_EXECUTION_TIMEOUT_MS + 2 * RESPONSE_DELIVERY_GRACE_MS
    });
    BROWSER_SEQUENTIAL_INPUT_DELAY_MS = 50;
  }
});

// shared/browser-rpc/src/protocol/extensionApprovalDecisionRpc.ts
function parseApprovalDecisionParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Extension approval decision params must be an object.");
  }
  const allowed = /* @__PURE__ */ new Set([
    "requestKind",
    "operation",
    "outcome",
    "approvedScope",
    "durationMs",
    "popupDismissalCount",
    "popupAutoReopenCount",
    "lastDismissalToolbarPinned"
  ]);
  if (Object.keys(value).some((field) => !allowed.has(field))) {
    throw new BrowserRpcProtocolError(
      "Extension approval decision params contain an unsupported field."
    );
  }
  if (value.requestKind !== "connection" && value.requestKind !== "operation") {
    throw new BrowserRpcProtocolError("requestKind must be 'connection' or 'operation'.");
  }
  const operation = optionalEnum(value.operation, BROWSER_PAGE_OPERATIONS, "operation");
  if (value.requestKind === "connection" && operation !== void 0) {
    throw new BrowserRpcProtocolError("Connection approval decisions must omit operation.");
  }
  if (value.requestKind === "operation" && operation === void 0) {
    throw new BrowserRpcProtocolError("Operation approval decisions must include operation.");
  }
  const outcome = requiredEnum(value.outcome, BROWSER_APPROVAL_OUTCOMES, "outcome");
  const approvedScope = optionalEnum(
    value.approvedScope,
    ["once", "origin"],
    "approvedScope"
  );
  if (outcome === "approved" && approvedScope === void 0) {
    throw new BrowserRpcProtocolError("Approved decisions must include approvedScope.");
  }
  if (outcome !== "approved" && approvedScope !== void 0) {
    throw new BrowserRpcProtocolError("Only approved decisions may include approvedScope.");
  }
  if (!Number.isSafeInteger(value.durationMs) || value.durationMs < 0 || value.durationMs > EXTENSION_APPROVAL_DECISION_REPORTING_TIMING.maxDurationMs) {
    throw new BrowserRpcProtocolError("durationMs is outside the approval reporting budget.");
  }
  const popupDismissalCount = requirePopupObservationCount(
    value.popupDismissalCount,
    "popupDismissalCount"
  );
  const popupAutoReopenCount = requirePopupObservationCount(
    value.popupAutoReopenCount,
    "popupAutoReopenCount"
  );
  if (popupAutoReopenCount > popupDismissalCount) {
    throw new BrowserRpcProtocolError(
      "popupAutoReopenCount must not exceed popupDismissalCount."
    );
  }
  const lastDismissalToolbarPinned = value.lastDismissalToolbarPinned;
  if (lastDismissalToolbarPinned !== void 0 && (typeof lastDismissalToolbarPinned !== "boolean" || popupDismissalCount === 0)) {
    throw new BrowserRpcProtocolError(
      "lastDismissalToolbarPinned requires at least one popup dismissal."
    );
  }
  return {
    requestKind: value.requestKind,
    ...operation === void 0 ? {} : { operation },
    outcome,
    ...approvedScope === void 0 ? {} : { approvedScope },
    durationMs: value.durationMs,
    popupDismissalCount,
    popupAutoReopenCount,
    ...lastDismissalToolbarPinned === void 0 ? {} : { lastDismissalToolbarPinned }
  };
}
function requirePopupObservationCount(value, field) {
  if (!Number.isSafeInteger(value) || value < 0 || value > EXTENSION_APPROVAL_DECISION_MAX_POPUP_OBSERVATION_COUNT) {
    throw new BrowserRpcProtocolError(`${field} is outside the popup observation budget.`);
  }
  return value;
}
function requiredEnum(value, values, field) {
  const parsed = optionalEnum(value, values, field);
  if (parsed === void 0) {
    throw new BrowserRpcProtocolError(`${field} is required.`);
  }
  return parsed;
}
function optionalEnum(value, values, field) {
  if (value === void 0) return void 0;
  if (typeof value !== "string" || !values.includes(value)) {
    throw new BrowserRpcProtocolError(`${field} is unsupported.`);
  }
  return value;
}
var EXTENSION_APPROVAL_DECISION_REPORTING_TIMING, EXTENSION_APPROVAL_DECISION_MAX_POPUP_OBSERVATION_COUNT, BROWSER_APPROVAL_OUTCOMES, ExtensionReportApprovalDecision;
var init_extensionApprovalDecisionRpc = __esm({
  "shared/browser-rpc/src/protocol/extensionApprovalDecisionRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserApproval();
    init_browserToolCallPolicy();
    init_validation();
    EXTENSION_APPROVAL_DECISION_REPORTING_TIMING = Object.freeze({
      maxDurationMs: BROWSER_TOOL_CALL_TIMING.maxApprovalQueueWaitMs + BROWSER_TOOL_CALL_TIMING.approvalDecisionTimeoutMs + BROWSER_TOOL_CALL_TIMING.responseDeliveryGraceMs
    });
    EXTENSION_APPROVAL_DECISION_MAX_POPUP_OBSERVATION_COUNT = 255;
    BROWSER_APPROVAL_OUTCOMES = [
      "approved",
      "denied",
      "timeout",
      "cancelled",
      "unavailable"
    ];
    ExtensionReportApprovalDecision = defineBrowserRpcNotification(
      "extension.reportApprovalDecision",
      parseApprovalDecisionParams
    );
  }
});

// shared/browser-rpc/src/protocol/browserInstanceRpc.ts
function parseBrowserInstanceInfo(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser instance info must be an object.");
  }
  return {
    ...parseExtensionInfo(value),
    nativeHostVersion: requireString(value.nativeHostVersion, "nativeHostVersion"),
    endpointId: requireString(value.endpointId, "endpointId")
  };
}
var BrowserGetInfo;
var init_browserInstanceRpc = __esm({
  "shared/browser-rpc/src/protocol/browserInstanceRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_extensionInfo();
    init_browserRpcMethod();
    init_validation();
    BrowserGetInfo = defineBrowserRpcMethod(
      "browser.getInfo",
      parseEmptyParams,
      parseBrowserInstanceInfo
    );
  }
});

// shared/browser-rpc/src/protocol/browserSessionRpc.ts
function parseBrowserSessionCredentials(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser session credentials must be an object.");
  }
  return {
    sessionId: requireBoundedString(value.sessionId, "sessionId", MAX_SESSION_FIELD_LENGTH),
    capability: requireBoundedString(value.capability, "capability", MAX_CAPABILITY_LENGTH)
  };
}
function parseBrowserSessionOpenParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser session open params must be an object.");
  }
  return {
    clientId: requireBoundedString(value.clientId, "clientId", MAX_SESSION_FIELD_LENGTH),
    clientName: requireBoundedString(value.clientName, "clientName", MAX_SESSION_FIELD_LENGTH)
  };
}
function parseBrowserSessionOpenResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser session open result must be an object.");
  }
  return {
    ...parseBrowserSessionCredentials(value),
    expiresAt: requireExpiresAt(value.expiresAt)
  };
}
function parseBrowserSessionFinalizeResult(value) {
  if (!isRecord(value) || value.finalized !== true) {
    throw new BrowserRpcProtocolError("finalized must be true.");
  }
  return { finalized: true };
}
function requireBoundedString(value, field, maxLength) {
  const parsed = requireString(value, field);
  if (parsed.length > maxLength) {
    throw new BrowserRpcProtocolError(`${field} must not exceed ${maxLength} characters.`);
  }
  return parsed;
}
function requireExpiresAt(value) {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new BrowserRpcProtocolError("expiresAt must be a positive integer.");
  }
  return value;
}
var MAX_SESSION_FIELD_LENGTH, MAX_CAPABILITY_LENGTH, BrowserSessionOpen, BrowserSessionFinalize;
var init_browserSessionRpc = __esm({
  "shared/browser-rpc/src/protocol/browserSessionRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_browserRpcMethod();
    init_validation();
    MAX_SESSION_FIELD_LENGTH = 128;
    MAX_CAPABILITY_LENGTH = 256;
    BrowserSessionOpen = defineBrowserRpcMethod("browser.session.open", parseBrowserSessionOpenParams, parseBrowserSessionOpenResult);
    BrowserSessionFinalize = defineBrowserRpcMethod("browser.session.finalize", parseBrowserSessionCredentials, parseBrowserSessionFinalizeResult);
  }
});

// shared/browser-rpc/src/protocol/browserConnectionRpc.ts
function parseBrowserConnectionCredentials(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection credentials must be an object.");
  }
  return {
    connectionId: requireBoundedString2(
      value.connectionId,
      "connectionId",
      MAX_CONNECTION_FIELD_LENGTH
    ),
    capability: requireBoundedString2(value.capability, "capability", MAX_CAPABILITY_LENGTH2)
  };
}
function parseOpenParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection open params must be an object.");
  }
  const url = normalizeBrowserConnectionUrl(requireString(value.url, "url"));
  if (!url) {
    throw new BrowserRpcProtocolError(
      "url must be HTTPS or loopback HTTP without embedded credentials."
    );
  }
  const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
  return {
    clientId: requireBoundedString2(value.clientId, "clientId", MAX_CONNECTION_FIELD_LENGTH),
    clientName: requireBoundedString2(
      value.clientName,
      "clientName",
      MAX_CONNECTION_FIELD_LENGTH
    ),
    url,
    ...timeoutMs === void 0 ? {} : { timeoutMs },
    ...value.groupName === void 0 ? {} : {
      groupName: requireBoundedString2(
        value.groupName,
        "groupName",
        MAX_GROUP_NAME_LENGTH
      ).trim()
    }
  };
}
function parseOpenResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection open result must be an object.");
  }
  return {
    ...parseBrowserConnectionCredentials(value),
    expiresAt: requirePositiveInteger(value.expiresAt, "expiresAt")
  };
}
function parseFinalizeResult(value) {
  if (!isRecord(value) || value.finalized !== true) {
    throw new BrowserRpcProtocolError("finalized must be true.");
  }
  return { finalized: true };
}
function requireBoundedString2(value, field, maxLength) {
  const parsed = requireString(value, field);
  if (parsed.length > maxLength) {
    throw new BrowserRpcProtocolError(`${field} must not exceed ${maxLength} characters.`);
  }
  return parsed;
}
var MAX_CONNECTION_FIELD_LENGTH, MAX_CAPABILITY_LENGTH2, MAX_GROUP_NAME_LENGTH, BROWSER_CONNECTION_OPEN_TIMING, BROWSER_CONNECTION_FINALIZE_TIMING, BrowserConnectionOpen, BrowserConnectionFinalize;
var init_browserConnectionRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserConnectionUrl();
    init_browserToolCallPolicy();
    init_validation();
    MAX_CONNECTION_FIELD_LENGTH = 128;
    MAX_CAPABILITY_LENGTH2 = 256;
    MAX_GROUP_NAME_LENGTH = 128;
    BROWSER_CONNECTION_OPEN_TIMING = Object.freeze({
      approvalQueueCapacity: BROWSER_TOOL_CALL_TIMING.approvalQueueCapacity,
      maxApprovalQueueWaitMs: BROWSER_TOOL_CALL_TIMING.maxApprovalQueueWaitMs,
      approvalDecisionTimeoutMs: BROWSER_TOOL_CALL_TIMING.approvalDecisionTimeoutMs,
      navigationLoadTimeoutMs: BROWSER_TOOL_CALL_TIMING.executionTimeoutMs,
      responseDeliveryGraceMs: BROWSER_TOOL_CALL_TIMING.responseDeliveryGraceMs,
      extensionRequestTimeoutMs: BROWSER_TOOL_CALL_TIMING.extensionRequestTimeoutMs,
      mcpRequestTimeoutMs: BROWSER_TOOL_CALL_TIMING.mcpRequestTimeoutMs
    });
    BROWSER_CONNECTION_FINALIZE_TIMING = Object.freeze({
      cleanupTimeoutMs: BROWSER_TOOL_CALL_TIMING.executionTimeoutMs,
      responseDeliveryGraceMs: BROWSER_TOOL_CALL_TIMING.responseDeliveryGraceMs,
      extensionRequestTimeoutMs: BROWSER_TOOL_CALL_TIMING.executionTimeoutMs + BROWSER_TOOL_CALL_TIMING.responseDeliveryGraceMs,
      mcpRequestTimeoutMs: BROWSER_TOOL_CALL_TIMING.executionTimeoutMs + 2 * BROWSER_TOOL_CALL_TIMING.responseDeliveryGraceMs
    });
    BrowserConnectionOpen = defineBrowserRpcMethod("browser.connection.open", parseOpenParams, parseOpenResult);
    BrowserConnectionFinalize = defineBrowserRpcMethod("browser.connection.finalize", parseBrowserConnectionCredentials, parseFinalizeResult);
  }
});

// shared/browser-rpc/src/protocol/browserElementRef.ts
function requireBrowserElementRef(value, field) {
  return requireElementRef(
    value,
    field,
    BROWSER_ELEMENT_REF_CONSTRAINTS.internalPattern,
    `${field} is invalid.`
  );
}
function requirePublicBrowserElementRef(value, field) {
  return requireElementRef(
    value,
    field,
    BROWSER_ELEMENT_REF_CONSTRAINTS.publicPattern,
    `${field} must be a valid public browser element reference.`
  );
}
function requireElementRef(value, field, pattern, invalidMessage) {
  const ref = requireString(value, field);
  if (ref.length > BROWSER_ELEMENT_REF_CONSTRAINTS.maxLength || !pattern.test(ref)) {
    throw new BrowserRpcProtocolError(invalidMessage);
  }
  return ref;
}
var BROWSER_ELEMENT_REF_CONSTRAINTS;
var init_browserElementRef = __esm({
  "shared/browser-rpc/src/protocol/browserElementRef.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_validation();
    BROWSER_ELEMENT_REF_CONSTRAINTS = Object.freeze({
      maxLength: 128,
      maxLivePerSnapshot: 1e4,
      publicPattern: /^e[1-9]\d*$/u,
      internalPattern: /^[A-Za-z0-9_-]+$/u
    });
  }
});

// shared/browser-rpc/src/protocol/browserConnectionClickRpc.ts
function parseBrowserConnectionClickOptions(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Click options must be an object.");
  }
  const unsupported = Object.keys(value).find(
    (key) => !["button", "force", "modifiers", "timeoutMs"].includes(key)
  );
  if (unsupported !== void 0) {
    throw new BrowserRpcProtocolError(
      `Click options contain unsupported field '${unsupported}'.`
    );
  }
  if (value.button !== void 0 && !BROWSER_CONNECTION_CLICK_BUTTONS.includes(value.button)) {
    throw new BrowserRpcProtocolError("button must be 'left', 'right', or 'middle'.");
  }
  if (value.force !== void 0 && typeof value.force !== "boolean") {
    throw new BrowserRpcProtocolError("force must be a boolean.");
  }
  if (value.modifiers !== void 0 && (!Array.isArray(value.modifiers) || value.modifiers.length > BROWSER_CONNECTION_CLICK_MAX_MODIFIERS || Array.from(value.modifiers).some(
    (modifier) => !BROWSER_CONNECTION_CLICK_MODIFIERS.includes(
      modifier
    )
  ))) {
    throw new BrowserRpcProtocolError(
      `modifiers must be an array of at most ${BROWSER_CONNECTION_CLICK_MAX_MODIFIERS} entries containing only Alt, Control, ControlOrMeta, Meta, or Shift.`
    );
  }
  const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
  return {
    ...value.button === void 0 ? {} : { button: value.button },
    ...value.force === void 0 ? {} : { force: value.force },
    ...value.modifiers === void 0 ? {} : { modifiers: [...value.modifiers] },
    ...timeoutMs === void 0 ? {} : { timeoutMs }
  };
}
function parseClickParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection click params must be an object.");
  }
  const ref = requirePublicBrowserElementRef(value.ref, "ref");
  if (value.doubleClick !== void 0 && typeof value.doubleClick !== "boolean") {
    throw new BrowserRpcProtocolError("doubleClick must be a boolean.");
  }
  const options = { ...value };
  for (const key of ["connectionId", "capability", "ref", "doubleClick"]) delete options[key];
  return {
    ...parseBrowserConnectionCredentials(value),
    ref,
    ...value.doubleClick === void 0 ? {} : { doubleClick: value.doubleClick },
    ...parseBrowserConnectionClickOptions(options)
  };
}
function parseClickResult(value) {
  if (!isRecord(value) || value.outcome !== "dispatched" && value.outcome !== "navigation-observed") {
    throw new BrowserRpcProtocolError("outcome must be 'dispatched' or 'navigation-observed'.");
  }
  return {
    outcome: value.outcome,
    connectionExpiresAt: requirePositiveInteger(
      value.connectionExpiresAt,
      "connectionExpiresAt"
    )
  };
}
var BROWSER_CONNECTION_CLICK_BUTTONS, BROWSER_CONNECTION_CLICK_MODIFIERS, BROWSER_CONNECTION_CLICK_MAX_MODIFIERS, BrowserConnectionClick;
var init_browserConnectionClickRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionClickRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserConnectionRpc();
    init_browserElementRef();
    init_browserToolCallPolicy();
    init_validation();
    BROWSER_CONNECTION_CLICK_BUTTONS = ["left", "right", "middle"];
    BROWSER_CONNECTION_CLICK_MODIFIERS = [
      "Alt",
      "Control",
      "ControlOrMeta",
      "Meta",
      "Shift"
    ];
    BROWSER_CONNECTION_CLICK_MAX_MODIFIERS = BROWSER_CONNECTION_CLICK_MODIFIERS.length;
    BrowserConnectionClick = defineBrowserRpcMethod("browser.connection.click", parseClickParams, parseClickResult);
  }
});

// shared/browser-rpc/src/protocol/browserConnectionHoverRpc.ts
function parseHoverParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection hover params must be an object.");
  }
  const allowed = /* @__PURE__ */ new Set(["connectionId", "capability", "ref"]);
  if (Object.keys(value).some((field) => !allowed.has(field))) {
    throw new BrowserRpcProtocolError("Browser hover params contain an unsupported field.");
  }
  return {
    ...parseBrowserConnectionCredentials(value),
    ref: requirePublicBrowserElementRef(value.ref, "ref")
  };
}
function parseHoverResult(value) {
  if (!isRecord(value) || value.outcome !== "dispatched") {
    throw new BrowserRpcProtocolError("outcome must be 'dispatched'.");
  }
  return {
    outcome: value.outcome,
    connectionExpiresAt: requirePositiveInteger(
      value.connectionExpiresAt,
      "connectionExpiresAt"
    )
  };
}
var BrowserConnectionHover;
var init_browserConnectionHoverRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionHoverRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserConnectionRpc();
    init_browserElementRef();
    init_validation();
    BrowserConnectionHover = defineBrowserRpcMethod("browser.connection.hover", parseHoverParams, parseHoverResult, {
      cancellationMode: "cooperative"
    });
  }
});

// shared/browser-rpc/src/protocol/browserConnectionKeyboardRpc.ts
function parseBrowserKeyChord(value, platform2 = "Win32") {
  return parseKeyChord(value, platform2);
}
function normalizeBrowserKeyChord(value) {
  return parseKeyChord(value).expression;
}
function parseKeyChord(value, platform2) {
  if (value.length === 0 || value.length > BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS.maxKeyLength) {
    throw new BrowserRpcProtocolError(
      `key must be between 1 and ${BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS.maxKeyLength} characters.`
    );
  }
  const tokens = (value === "+" ? ["Plus"] : value.split("+")).map((token) => token.trim());
  if (tokens.some((token) => token.length === 0)) {
    throw new BrowserRpcProtocolError("key contains an empty chord token.");
  }
  const keyToken = tokens.at(-1);
  const platformModifier = platform2 === void 0 ? 16 : platform2.startsWith("Mac") ? 4 : 2;
  const hasPlatformModifier = tokens.slice(0, -1).some((token) => token.toLowerCase() === "controlormeta");
  let modifiers = 0;
  for (const token of tokens.slice(0, -1)) {
    const bit = token.toLowerCase() === "controlormeta" ? platformModifier : modifierBit(token);
    if ((modifiers & bit) !== 0) {
      throw new BrowserRpcProtocolError(`key repeats modifier '${token}'.`);
    }
    modifiers |= bit;
  }
  const named = NAMED_KEYS.get(keyToken.toLowerCase());
  const parsed = named ? { key: named, modifiers } : parsePrintableKey(keyToken, modifiers);
  const key = parsed.key;
  modifiers = parsed.modifiers;
  rejectClipboardShortcut(key, modifiers);
  const modifierNames = [
    ...modifiers & 2 ? [hasPlatformModifier && platformModifier === 2 ? "ControlOrMeta" : "Control"] : [],
    ...modifiers & 1 ? ["Alt"] : [],
    ...modifiers & 4 ? [hasPlatformModifier && platformModifier === 4 ? "ControlOrMeta" : "Meta"] : [],
    ...modifiers & 16 ? ["ControlOrMeta"] : [],
    ...modifiers & 8 ? ["Shift"] : []
  ];
  const text = modifiers & (1 | 2 | 4 | 16) || !("text" in key) ? void 0 : key.text;
  return {
    expression: [...modifierNames, key.expression].join("+"),
    key: key.key,
    code: key.code,
    virtualKeyCode: key.virtualKeyCode,
    modifiers,
    ...text === void 0 ? {} : { text }
  };
}
function rejectClipboardShortcut(key, modifiers) {
  const controlOrMeta = (modifiers & (2 | 4 | 16)) !== 0;
  const clipboardLetter = ["c", "v", "x"].includes(key.key.toLowerCase());
  const legacyClipboardShortcut = key.code === "Insert" && (modifiers & (2 | 8 | 16)) !== 0 || key.code === "Delete" && (modifiers & 8) !== 0;
  if (controlOrMeta && clipboardLetter || legacyClipboardShortcut) {
    throw new BrowserRpcProtocolError("Clipboard keyboard shortcuts are not supported.");
  }
}
function modifierBit(value) {
  switch (value.toLowerCase()) {
    case "control":
    case "ctrl":
      return 2;
    case "alt":
      return 1;
    case "meta":
    case "command":
      return 4;
    case "shift":
      return 8;
    default:
      throw new BrowserRpcProtocolError(`Unsupported key modifier '${value}'.`);
  }
}
function modifierKey(bit, expression, code, virtualKeyCode) {
  return { bit, expression, key: expression, code, virtualKeyCode, location: 1 };
}
function parsePrintableKey(value, modifiers) {
  const token = PRINTABLE_KEY_TOKENS.get(value) ?? PRINTABLE_KEY_ALIASES.get(value.toLowerCase());
  if (!token) {
    throw new BrowserRpcProtocolError(`Unsupported key '${value}'.`);
  }
  const effectiveModifiers = token.impliesShift ? modifiers | 8 : modifiers;
  const shifted = (effectiveModifiers & 8) !== 0;
  return {
    key: {
      expression: token.definition.expression,
      key: shifted ? token.definition.shiftedKey : token.definition.unshiftedKey,
      code: token.definition.code,
      virtualKeyCode: token.definition.virtualKeyCode,
      text: shifted ? token.definition.shiftedKey : token.definition.unshiftedKey
    },
    modifiers: effectiveModifiers
  };
}
function registerPrintableKey(expression, unshiftedKey, shiftedKey, code, virtualKeyCode, shiftedTokenImpliesShift = true) {
  const definition = { expression, unshiftedKey, shiftedKey, code, virtualKeyCode };
  PRINTABLE_KEY_TOKENS.set(unshiftedKey, { definition, impliesShift: false });
  PRINTABLE_KEY_TOKENS.set(shiftedKey, {
    definition,
    impliesShift: shiftedTokenImpliesShift
  });
  PRINTABLE_KEY_ALIASES.set(code.toLowerCase(), { definition, impliesShift: false });
}
function namedKey(expression, virtualKeyCode, text) {
  return {
    expression,
    key: expression,
    code: expression,
    virtualKeyCode,
    ...text === void 0 ? {} : { text }
  };
}
function parseKeyboardParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection keyboard params must be an object.");
  }
  if (typeof value.key !== "string") {
    throw new BrowserRpcProtocolError("key must be a string.");
  }
  const key = normalizeBrowserKeyChord(value.key);
  const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
  return {
    ...parseBrowserConnectionCredentials(value),
    key,
    ...timeoutMs === void 0 ? {} : { timeoutMs },
    ...value.ref === void 0 ? {} : { ref: requirePublicBrowserElementRef(value.ref, "ref") }
  };
}
function parseKeyboardResult(value) {
  if (!isRecord(value) || value.outcome !== "dispatched") {
    throw new BrowserRpcProtocolError("outcome must be 'dispatched'.");
  }
  return {
    outcome: value.outcome,
    connectionExpiresAt: requirePositiveInteger(
      value.connectionExpiresAt,
      "connectionExpiresAt"
    )
  };
}
var BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS, BROWSER_KEYBOARD_MODIFIER_KEYS, NAMED_KEYS, PRINTABLE_KEY_TOKENS, PRINTABLE_KEY_ALIASES, BrowserConnectionKeyboard;
var init_browserConnectionKeyboardRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionKeyboardRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserToolCallPolicy();
    init_browserConnectionRpc();
    init_validation();
    init_browserElementRef();
    BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS = {
      maxKeyLength: 128,
      maxSequentialCodePoints: 2e3
    };
    BROWSER_KEYBOARD_MODIFIER_KEYS = [
      modifierKey(2, "Control", "ControlLeft", 17),
      modifierKey(1, "Alt", "AltLeft", 18),
      modifierKey(4, "Meta", "MetaLeft", 91),
      modifierKey(8, "Shift", "ShiftLeft", 16)
    ];
    NAMED_KEYS = /* @__PURE__ */ new Map([
      ["enter", namedKey("Enter", 13, "\r")],
      ["tab", namedKey("Tab", 9)],
      ["escape", namedKey("Escape", 27)],
      ["esc", namedKey("Escape", 27)],
      ["backspace", namedKey("Backspace", 8)],
      ["delete", namedKey("Delete", 46)],
      ["insert", namedKey("Insert", 45)],
      ["arrowleft", namedKey("ArrowLeft", 37)],
      ["arrowup", namedKey("ArrowUp", 38)],
      ["arrowright", namedKey("ArrowRight", 39)],
      ["arrowdown", namedKey("ArrowDown", 40)],
      ["home", namedKey("Home", 36)],
      ["end", namedKey("End", 35)],
      ["pageup", namedKey("PageUp", 33)],
      ["pagedown", namedKey("PageDown", 34)],
      ["space", { expression: "Space", key: " ", code: "Space", virtualKeyCode: 32, text: " " }]
    ]);
    for (let index = 1; index <= 12; index += 1) {
      const expression = `F${index}`;
      NAMED_KEYS.set(expression.toLowerCase(), {
        expression,
        key: expression,
        code: expression,
        virtualKeyCode: 111 + index
      });
    }
    PRINTABLE_KEY_TOKENS = /* @__PURE__ */ new Map();
    PRINTABLE_KEY_ALIASES = /* @__PURE__ */ new Map();
    for (let keyCode = 65; keyCode <= 90; keyCode += 1) {
      const upper = String.fromCharCode(keyCode);
      registerPrintableKey(upper, upper.toLowerCase(), upper, `Key${upper}`, keyCode, false);
    }
    for (let digit = 0; digit <= 9; digit += 1) {
      const shifted = ")!@#$%^&*("[digit];
      registerPrintableKey(String(digit), String(digit), shifted, `Digit${digit}`, 48 + digit);
    }
    for (const [expression, unshifted, shifted, code, virtualKeyCode] of [
      ["`", "`", "~", "Backquote", 192],
      ["-", "-", "_", "Minus", 189],
      ["=", "=", "+", "Equal", 187],
      ["[", "[", "{", "BracketLeft", 219],
      ["]", "]", "}", "BracketRight", 221],
      ["\\", "\\", "|", "Backslash", 220],
      [";", ";", ":", "Semicolon", 186],
      ["'", "'", '"', "Quote", 222],
      [",", ",", "<", "Comma", 188],
      [".", ".", ">", "Period", 190],
      ["/", "/", "?", "Slash", 191]
    ]) {
      registerPrintableKey(expression, unshifted, shifted, code, virtualKeyCode);
    }
    PRINTABLE_KEY_ALIASES.set("plus", PRINTABLE_KEY_TOKENS.get("+"));
    BrowserConnectionKeyboard = defineBrowserRpcMethod("browser.connection.keyboard", parseKeyboardParams, parseKeyboardResult, {
      cancellationMode: "cooperative"
    });
  }
});

// shared/browser-rpc/src/protocol/browserConnectionNavigationContract.ts
function parseBrowserConnectionNavigationOperation(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser navigation operation must be an object.");
  }
  if (typeof value.action !== "string" || !BROWSER_CONNECTION_NAVIGATION_ACTIONS.includes(
    value.action
  )) {
    throw new BrowserRpcProtocolError(
      `Unsupported Browser navigation action '${String(value.action)}'.`
    );
  }
  const action = value.action;
  switch (action) {
    case "url":
      requireAllowedKeys(value, ["action"]);
      return { action };
    case "goto": {
      requireAllowedKeys(value, ["action", "url", "timeoutMs"]);
      const requestedUrl = requireString(value.url, "navigation url");
      const url = normalizeBrowserConnectionUrl(requestedUrl);
      if (!url) {
        throw new BrowserRpcProtocolError("Browser navigation URL is unsupported.");
      }
      const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
      return { action, url, ...timeoutMs === void 0 ? {} : { timeoutMs } };
    }
    case "waitForURL": {
      requireAllowedKeys(value, ["action", "pattern", "timeoutMs"]);
      const pattern = requireString(value.pattern, "navigation pattern");
      if (pattern.length > BROWSER_CONNECTION_NAVIGATION_CONSTRAINTS.maxPatternLength) {
        throw new BrowserRpcProtocolError(
          `navigation pattern must not exceed ${BROWSER_CONNECTION_NAVIGATION_CONSTRAINTS.maxPatternLength} characters.`
        );
      }
      const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
      return { action, pattern, ...timeoutMs === void 0 ? {} : { timeoutMs } };
    }
    case "reload":
    case "goBack":
    case "goForward": {
      requireAllowedKeys(value, ["action", "timeoutMs"]);
      const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
      return { action, ...timeoutMs === void 0 ? {} : { timeoutMs } };
    }
  }
}
function parseBrowserConnectionNavigationResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser navigation result must be an object.");
  }
  if (typeof value.action !== "string" || !BROWSER_CONNECTION_NAVIGATION_ACTIONS.includes(
    value.action
  )) {
    throw new BrowserRpcProtocolError("Browser navigation result action is invalid.");
  }
  const url = typeof value.url === "string" ? normalizeBrowserConnectionUrl(value.url) : void 0;
  if (!url) {
    throw new BrowserRpcProtocolError("Browser navigation result URL is unsupported.");
  }
  return {
    action: value.action,
    url,
    connectionExpiresAt: requirePositiveInteger(
      value.connectionExpiresAt,
      "connectionExpiresAt"
    )
  };
}
function requireAllowedKeys(value, allowed) {
  const allowedSet = new Set(allowed);
  const unsupported = Object.keys(value).find((key) => !allowedSet.has(key));
  if (unsupported) {
    throw new BrowserRpcProtocolError(
      `Browser navigation operation contains unsupported field '${unsupported}'.`
    );
  }
}
var BROWSER_CONNECTION_NAVIGATION_ACTIONS, BROWSER_CONNECTION_NAVIGATION_CONSTRAINTS;
var init_browserConnectionNavigationContract = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionNavigationContract.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_browserToolCallPolicy();
    init_browserConnectionUrl();
    init_validation();
    BROWSER_CONNECTION_NAVIGATION_ACTIONS = [
      "url",
      "goto",
      "reload",
      "goBack",
      "goForward",
      "waitForURL"
    ];
    BROWSER_CONNECTION_NAVIGATION_CONSTRAINTS = Object.freeze({
      maxPatternLength: 8192,
      maxTimeoutMs: BROWSER_TOOL_CALL_TIMING.maxExecutionTimeoutMs
    });
  }
});

// shared/browser-rpc/src/protocol/browserActionDiagnostic.ts
function browserActionDiagnosticFromData(value) {
  if (!isRecord(value)) return void 0;
  const reason = typeof value.reason === "string" && BROWSER_ACTION_FAILURE_REASONS.includes(value.reason) ? value.reason : void 0;
  const inputCommitted = value.inputCommitted === true || value.inputCommitted === false && value.committed === true ? true : value.committed === "unknown" ? void 0 : optionalBoolean(value.inputCommitted);
  const dispatchCompleted = optionalBoolean(value.dispatchCompleted);
  const receiptObserved = optionalBoolean(value.receiptObserved);
  const matches = reason === "NOT_UNIQUE" ? locatorMatches(value.matches) : void 0;
  if (reason === void 0 && inputCommitted === void 0 && dispatchCompleted === void 0 && receiptObserved === void 0) {
    return void 0;
  }
  return {
    ...reason === void 0 ? {} : { reason },
    ...inputCommitted === void 0 ? {} : { inputCommitted },
    ...dispatchCompleted === void 0 ? {} : { dispatchCompleted },
    ...receiptObserved === void 0 ? {} : { receiptObserved },
    ...matches === void 0 ? {} : { matches }
  };
}
function locatorMatches(value) {
  if (!isRecord(value) || typeof value.count !== "number" || !Number.isSafeInteger(value.count) || value.count < 2 || !Array.isArray(value.candidates))
    return void 0;
  const candidates = [];
  for (const candidate of value.candidates.slice(0, Math.min(5, value.count))) {
    if (!isRecord(candidate) || candidate.index !== candidates.length) return void 0;
    const index = candidates.length;
    if (candidate.omitted === true) {
      candidates.push({ index, omitted: true });
    } else {
      if (typeof candidate.tag !== "string" || typeof candidate.name !== "string" || typeof candidate.visible !== "boolean" || typeof candidate.enabled !== "boolean")
        return void 0;
      candidates.push({
        index,
        tag: candidate.tag.slice(0, 32),
        ...typeof candidate.role === "string" ? { role: candidate.role.slice(0, 32) } : {},
        name: candidate.name.slice(0, 80),
        visible: candidate.visible,
        enabled: candidate.enabled
      });
    }
  }
  return {
    count: value.count,
    candidates,
    truncated: value.count > candidates.length || value.truncated === true
  };
}
function optionalBoolean(value) {
  return typeof value === "boolean" ? value : void 0;
}
var BROWSER_CONNECTION_LOCATOR_BOUNDARY_REASONS, BROWSER_ACTION_FAILURE_REASONS;
var init_browserActionDiagnostic = __esm({
  "shared/browser-rpc/src/protocol/browserActionDiagnostic.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_validation();
    BROWSER_CONNECTION_LOCATOR_BOUNDARY_REASONS = [
      "BOUNDARY_NOT_FOUND",
      "BOUNDARY_NOT_UNIQUE",
      "NOT_ATTACHED_FRAME_OWNER",
      "NO_PAGE_AUTHOR_CLOSED_ROOT"
    ];
    BROWSER_ACTION_FAILURE_REASONS = [
      "NOT_FOUND",
      "NOT_UNIQUE",
      "NOT_VISIBLE",
      "NOT_ENABLED",
      "NOT_EDITABLE",
      "INPUT_DISPATCH_FAILED",
      "INPUT_RELEASE_FAILED",
      "RECEIPT_UNAVAILABLE",
      "RECEIPT_NOT_OBSERVED",
      "NOT_STABLE",
      "POINTER_INTERCEPTED",
      "PROTECTED_CONTROL",
      "OPENS_NEW_TAB",
      "NO_FOCUS",
      "FOCUS_CHANGED",
      "FRAME_FOCUS_UNRESOLVED",
      "FRAME_OWNER_OCCLUDED",
      "FRAME_OWNER_CLIPPED",
      "FRAME_OWNER_DETACHED",
      "FRAME_TRANSFORM_UNSUPPORTED",
      "FRAME_POINT_UNMAPPABLE",
      "SCREENSHOT_VIEWPORT_CHANGED",
      "SCREENSHOT_INVALID_VIEWPORT",
      "SCREENSHOT_INVALID_DATA",
      "SCREENSHOT_DIMENSION_MISMATCH",
      "SNAPSHOT_INVALID_DATA",
      ...BROWSER_CONNECTION_LOCATOR_BOUNDARY_REASONS
    ];
  }
});

// shared/browser-rpc/src/protocol/browserConnectionTypeRpc.ts
function parseTypeParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection type params must be an object.");
  }
  if (typeof value.text !== "string") {
    throw new BrowserRpcProtocolError("text must be a string.");
  }
  if (value.text.length > BROWSER_CONNECTION_TYPE_CONSTRAINTS.maxTextLength) {
    throw new BrowserRpcProtocolError(
      `text must not exceed ${BROWSER_CONNECTION_TYPE_CONSTRAINTS.maxTextLength} characters.`
    );
  }
  if (value.inputMode !== void 0 && value.inputMode !== "sequential") {
    throw new BrowserRpcProtocolError("inputMode must be 'sequential'.");
  }
  if (value.inputMode === "sequential" && Array.from(value.text).length > BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS.maxSequentialCodePoints) {
    throw new BrowserRpcProtocolError(
      `Sequential text must not exceed ${BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS.maxSequentialCodePoints} code points.`
    );
  }
  if (value.inputMode !== void 0 && value.submitKey !== void 0) {
    throw new BrowserRpcProtocolError("submitKey is not supported with inputMode.");
  }
  if (value.replace !== void 0 && typeof value.replace !== "boolean") {
    throw new BrowserRpcProtocolError("replace must be a boolean.");
  }
  if (value.replace === true && (value.ref === void 0 || value.inputMode !== void 0)) {
    throw new BrowserRpcProtocolError("Replacement requires a ref and no inputMode.");
  }
  if (value.submitKey !== void 0 && typeof value.submitKey !== "string") {
    throw new BrowserRpcProtocolError("submitKey must be a string.");
  }
  const submitKey = value.submitKey === void 0 ? void 0 : normalizeBrowserKeyChord(value.submitKey);
  const ref = value.ref === void 0 ? void 0 : requirePublicBrowserElementRef(value.ref, "ref");
  const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
  return {
    ...parseBrowserConnectionCredentials(value),
    text: value.text,
    ...timeoutMs === void 0 ? {} : { timeoutMs },
    ...ref === void 0 ? {} : { ref },
    ...submitKey === void 0 ? {} : { submitKey },
    ...value.inputMode === void 0 ? {} : { inputMode: value.inputMode },
    ...value.replace === void 0 ? {} : { replace: value.replace }
  };
}
function parseTypeResult(value) {
  if (!isRecord(value) || value.outcome !== "dispatched") {
    throw new BrowserRpcProtocolError("outcome must be 'dispatched'.");
  }
  return {
    outcome: value.outcome,
    connectionExpiresAt: requirePositiveInteger(
      value.connectionExpiresAt,
      "connectionExpiresAt"
    )
  };
}
var BROWSER_CONNECTION_TYPE_CONSTRAINTS, BrowserConnectionType;
var init_browserConnectionTypeRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionTypeRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserConnectionRpc();
    init_browserConnectionKeyboardRpc();
    init_browserElementRef();
    init_validation();
    init_browserToolCallPolicy();
    BROWSER_CONNECTION_TYPE_CONSTRAINTS = {
      maxTextLength: 5e4
    };
    BrowserConnectionType = defineBrowserRpcMethod("browser.connection.type", parseTypeParams, parseTypeResult, {
      cancellationMode: "cooperative"
    });
  }
});

// shared/browser-rpc/src/protocol/browserConnectionLocatorContract.ts
function browserConnectionLocatorBoundaryReasonFromData(value) {
  if (!isRecord(value) || typeof value.reason !== "string") return void 0;
  return BROWSER_CONNECTION_LOCATOR_BOUNDARY_REASONS.includes(
    value.reason
  ) ? value.reason : void 0;
}
function parseBrowserConnectionLocatorOperation(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser Locator operation must be an object.");
  }
  const selector = requireString(value.selector, "selector");
  if (selector.length > BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxSelectorLength) {
    throw new BrowserRpcProtocolError(
      `selector must not exceed ${BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxSelectorLength} characters.`
    );
  }
  if (/internal:control\s*=\s*enter-frame/iu.test(selector)) {
    throw new BrowserRpcProtocolError("Raw frame traversal selectors are not supported.");
  }
  const surfaces = parseLocatorSurfaces(value.surfaces);
  if (typeof value.method !== "string" || !BROWSER_CONNECTION_LOCATOR_METHODS.includes(value.method)) {
    throw new BrowserRpcProtocolError(
      `Unsupported Browser Locator method '${String(value.method)}'.`
    );
  }
  if (!isRecord(value.arguments)) {
    throw new BrowserRpcProtocolError("Browser Locator arguments must be an object.");
  }
  const method = value.method;
  return {
    selector,
    ...surfaces === void 0 ? {} : { surfaces },
    method,
    arguments: parseMethodArguments(method, value.arguments)
  };
}
function parseBrowserConnectionLocatorResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser Locator result must be an object.");
  }
  if (typeof value.method !== "string" || !BROWSER_CONNECTION_LOCATOR_METHODS.includes(value.method)) {
    throw new BrowserRpcProtocolError("Browser Locator result method is invalid.");
  }
  if (!Array.isArray(value.omissions) || value.omissions.some((omission) => omission !== "sensitive-content")) {
    throw new BrowserRpcProtocolError("Browser Locator result omissions are invalid.");
  }
  const method = value.method;
  validateMethodResult(method, value.result);
  let serialized;
  try {
    serialized = JSON.stringify(value.result);
  } catch {
    throw new BrowserRpcProtocolError("Browser Locator result must be JSON serializable.");
  }
  if (new TextEncoder().encode(serialized).byteLength > BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxSerializedResultBytes) {
    throw new BrowserRpcProtocolError("Browser Locator result exceeds its size limit.");
  }
  if (!Number.isSafeInteger(value.connectionExpiresAt) || value.connectionExpiresAt <= 0) {
    throw new BrowserRpcProtocolError("connectionExpiresAt must be a positive integer.");
  }
  return {
    method,
    result: value.result,
    omissions: value.omissions,
    connectionExpiresAt: value.connectionExpiresAt
  };
}
function parseLocatorSurfaces(value) {
  if (value === void 0) return void 0;
  if (!Array.isArray(value) || value.length === 0 || value.length > 64) {
    throw new BrowserRpcProtocolError(
      "Locator surfaces must contain between 1 and 64 boundaries."
    );
  }
  return value.map((surface, index) => {
    if (!isRecord(surface) || surface.kind !== "frame" && surface.kind !== "closed-shadow" || Object.keys(surface).some((key) => key !== "kind" && key !== "selector")) {
      throw new BrowserRpcProtocolError(`Locator surface ${index} is invalid.`);
    }
    const selector = requireString(surface.selector, `surfaces[${index}].selector`);
    if (selector.length > BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxSelectorLength) {
      throw new BrowserRpcProtocolError(`Locator surface ${index} selector is too long.`);
    }
    if (/internal:control\s*=\s*enter-frame/iu.test(selector)) {
      throw new BrowserRpcProtocolError("Raw frame traversal selectors are not supported.");
    }
    return { kind: surface.kind, selector };
  });
}
function parseMethodArguments(method, args) {
  switch (method) {
    case "click":
    case "dblclick": {
      return { ...parseBrowserConnectionClickOptions(args) };
    }
    case "fill":
    case "type":
    case "pressSequentially": {
      requireAllowedKeys2(args, ["value", "timeoutMs"]);
      if (typeof args.value !== "string") {
        throw new BrowserRpcProtocolError(`locator.${method} value must be a string.`);
      }
      if (args.value.length > BROWSER_CONNECTION_TYPE_CONSTRAINTS.maxTextLength) {
        throw new BrowserRpcProtocolError(
          `locator.${method} value must not exceed ${BROWSER_CONNECTION_TYPE_CONSTRAINTS.maxTextLength} characters.`
        );
      }
      const timeoutMs = optionalTimeout(args.timeoutMs);
      if (method === "pressSequentially" && Array.from(args.value).length > BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS.maxSequentialCodePoints) {
        throw new BrowserRpcProtocolError(
          `Sequential text must not exceed ${BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS.maxSequentialCodePoints} code points.`
        );
      }
      return {
        value: args.value,
        ...timeoutMs === void 0 ? {} : { timeoutMs }
      };
    }
    case "press": {
      requireAllowedKeys2(args, ["key", "timeoutMs"]);
      if (typeof args.key !== "string") {
        throw new BrowserRpcProtocolError("locator.press key must be a string.");
      }
      const key = normalizeBrowserKeyChord(args.key);
      const timeoutMs = optionalTimeout(args.timeoutMs);
      return { key, ...timeoutMs === void 0 ? {} : { timeoutMs } };
    }
    case "waitFor": {
      requireAllowedKeys2(args, ["state", "timeoutMs"]);
      if (args.state !== "attached" && args.state !== "detached" && args.state !== "visible" && args.state !== "hidden") {
        throw new BrowserRpcProtocolError(
          "locator.waitFor state must be attached, detached, visible, or hidden."
        );
      }
      const timeoutMs = optionalTimeout(args.timeoutMs);
      return { state: args.state, ...timeoutMs === void 0 ? {} : { timeoutMs } };
    }
    case "scrollIntoViewIfNeeded": {
      requireAllowedKeys2(args, ["timeoutMs"]);
      const timeoutMs = optionalTimeout(args.timeoutMs);
      return timeoutMs === void 0 ? {} : { timeoutMs };
    }
    case "count":
    case "isVisible":
    case "isEnabled":
      requireAllowedKeys2(args, []);
      return {};
    case "allTextContents":
    case "textContent":
    case "innerText": {
      requireAllowedKeys2(args, ["timeoutMs"]);
      const timeoutMs = optionalTimeout(args.timeoutMs);
      return timeoutMs === void 0 ? {} : { timeoutMs };
    }
    case "getAttribute": {
      requireAllowedKeys2(args, ["name", "timeoutMs"]);
      const name = requireString(args.name, "locator.getAttribute name");
      if (name.length > BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxAttributeNameLength) {
        throw new BrowserRpcProtocolError(
          `locator.getAttribute name must not exceed ${BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxAttributeNameLength} characters.`
        );
      }
      const timeoutMs = optionalTimeout(args.timeoutMs);
      return { name, ...timeoutMs === void 0 ? {} : { timeoutMs } };
    }
  }
}
function validateMethodResult(method, result) {
  switch (method) {
    case "click":
    case "dblclick":
    case "fill":
    case "type":
    case "press":
    case "pressSequentially":
    case "waitFor":
    case "scrollIntoViewIfNeeded":
      if (result !== null) {
        throw new BrowserRpcProtocolError(`locator.${method} result must be null.`);
      }
      return;
    case "count":
      if (!Number.isSafeInteger(result) || result < 0 || result > BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxCollectionSize) {
        throw new BrowserRpcProtocolError(
          `locator.count result must not exceed ${BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxCollectionSize}.`
        );
      }
      return;
    case "isVisible":
    case "isEnabled":
      if (typeof result !== "boolean") {
        throw new BrowserRpcProtocolError(`locator.${method} result must be a boolean.`);
      }
      return;
    case "allTextContents":
      if (!Array.isArray(result) || result.length > BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxCollectionSize || result.some((entry) => typeof entry !== "string")) {
        throw new BrowserRpcProtocolError(
          `locator.allTextContents result must contain at most ${BROWSER_CONNECTION_LOCATOR_CONSTRAINTS.maxCollectionSize} strings.`
        );
      }
      return;
    case "textContent":
    case "getAttribute":
      if (result !== null && typeof result !== "string") {
        throw new BrowserRpcProtocolError(
          `locator.${method} result must be a string or null.`
        );
      }
      return;
    case "innerText":
      if (typeof result !== "string") {
        throw new BrowserRpcProtocolError("locator.innerText result must be a string.");
      }
      return;
  }
}
function optionalTimeout(value) {
  return parseBrowserToolTimeoutMs(value);
}
function requireAllowedKeys2(value, allowed) {
  const allowedSet = new Set(allowed);
  const unsupported = Object.keys(value).find((key) => !allowedSet.has(key));
  if (unsupported) {
    throw new BrowserRpcProtocolError(
      `Browser Locator arguments contain unsupported field '${unsupported}'.`
    );
  }
}
var BROWSER_CONNECTION_LOCATOR_CONSTRAINTS, BROWSER_CONNECTION_LOCATOR_METHODS;
var init_browserConnectionLocatorContract = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionLocatorContract.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_browserConnectionClickRpc();
    init_browserActionDiagnostic();
    init_browserConnectionKeyboardRpc();
    init_browserConnectionTypeRpc();
    init_validation();
    init_browserToolCallPolicy();
    init_browserActionDiagnostic();
    BROWSER_CONNECTION_LOCATOR_CONSTRAINTS = Object.freeze({
      maxSelectorLength: 8192,
      maxAttributeNameLength: 256,
      maxSerializedResultBytes: 4 * 1024 * 1024,
      maxCollectionSize: 5e3,
      maxTimeoutMs: BROWSER_TOOL_CALL_TIMING.maxExecutionTimeoutMs
    });
    BROWSER_CONNECTION_LOCATOR_METHODS = [
      "click",
      "dblclick",
      "fill",
      "type",
      "pressSequentially",
      "press",
      "waitFor",
      "scrollIntoViewIfNeeded",
      "count",
      "isVisible",
      "isEnabled",
      "allTextContents",
      "textContent",
      "innerText",
      "getAttribute"
    ];
  }
});

// shared/browser-rpc/src/protocol/browserConnectionScreenshotRpc.ts
function parseScreenshotParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError(
      "Browser connection screenshot params must be an object."
    );
  }
  requireOnlyFields(value, ["connectionId", "capability", "clip", "fullPage", "timeoutMs"]);
  const credentials = parseBrowserConnectionCredentials(value);
  const timeoutMs = parseBrowserToolTimeoutMs(value.timeoutMs);
  if (value.fullPage !== void 0 && typeof value.fullPage !== "boolean") {
    throw new BrowserRpcProtocolError("fullPage must be a boolean.");
  }
  const params = {
    ...credentials,
    ...timeoutMs === void 0 ? {} : { timeoutMs },
    ...value.fullPage === void 0 ? {} : { fullPage: value.fullPage }
  };
  if (value.clip === void 0) return params;
  if (!isRecord(value.clip)) throw new BrowserRpcProtocolError("clip must be a rectangle.");
  requireOnlyFields(value.clip, ["x", "y", "width", "height"]);
  return {
    ...params,
    clip: {
      x: requireClipNumber(value.clip.x, "x", 0),
      y: requireClipNumber(value.clip.y, "y", 0),
      width: requireClipNumber(value.clip.width, "width", 1),
      height: requireClipNumber(value.clip.height, "height", 1)
    }
  };
}
function requireClipNumber(value, field, minimum) {
  if (typeof value !== "number" || !Number.isFinite(value) || value < minimum) {
    throw new BrowserRpcProtocolError(
      `clip.${field} must be a finite number at least ${minimum}.`
    );
  }
  return value;
}
function parseScreenshotResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection screenshot result is invalid.");
  }
  const connectionExpiresAt = requirePositiveInteger(
    value.connectionExpiresAt,
    "connectionExpiresAt"
  );
  if (!isRecord(value.screenshot)) {
    throw new BrowserRpcProtocolError("Browser connection screenshot result is invalid.");
  }
  requireOnlyFields(value, ["screenshot", "connectionExpiresAt"]);
  const screenshot = value.screenshot;
  requireOnlyFields(screenshot, ["data", "mimeType", "width", "height", "sizeBytes"]);
  if (screenshot.mimeType !== "image/jpeg") {
    throw new BrowserRpcProtocolError("mimeType must be 'image/jpeg'.");
  }
  const width = requireDimension(screenshot.width, "width");
  const height = requireDimension(screenshot.height, "height");
  if (width * height > BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS.maxPixels) {
    throw new BrowserRpcProtocolError(
      `Screenshot dimensions must not exceed ${BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS.maxPixels} pixels.`
    );
  }
  const sizeBytes = requirePositiveInteger(screenshot.sizeBytes, "sizeBytes");
  if (sizeBytes > BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS.maxDecodedBytes) {
    throw new BrowserRpcProtocolError(
      `sizeBytes must not exceed ${BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS.maxDecodedBytes}.`
    );
  }
  const data = requireScreenshotData(screenshot.data);
  if (decodedBase64Length(data) !== sizeBytes) {
    throw new BrowserRpcProtocolError("sizeBytes must match the decoded screenshot data.");
  }
  return {
    screenshot: {
      data,
      mimeType: screenshot.mimeType,
      width,
      height,
      sizeBytes
    },
    connectionExpiresAt
  };
}
function requireScreenshotData(value) {
  if (typeof value !== "string" || value.length === 0) {
    throw new BrowserRpcProtocolError("data must be a non-empty base64 string.");
  }
  if (value.length > BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS.maxBase64Characters || value.length % 4 !== 0 || !isCanonicalBase64(value)) {
    throw new BrowserRpcProtocolError("Screenshot data must be bounded canonical base64.");
  }
  return value;
}
function isCanonicalBase64(value) {
  const padding = value.endsWith("==") ? 2 : value.endsWith("=") ? 1 : 0;
  if (/[^A-Za-z0-9+/]/u.test(value.slice(0, value.length - padding))) return false;
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  if (value.endsWith("==")) return (alphabet.indexOf(value.at(-3) ?? "") & 15) === 0;
  if (value.endsWith("=")) return (alphabet.indexOf(value.at(-2) ?? "") & 3) === 0;
  return true;
}
function decodedBase64Length(value) {
  const padding = value.endsWith("==") ? 2 : value.endsWith("=") ? 1 : 0;
  return value.length / 4 * 3 - padding;
}
function requireDimension(value, field) {
  const dimension = requirePositiveInteger(value, field);
  if (dimension > BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS.maxDimension) {
    throw new BrowserRpcProtocolError(
      `${field} must not exceed ${BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS.maxDimension}.`
    );
  }
  return dimension;
}
function requireOnlyFields(value, fields) {
  const allowed = new Set(fields);
  if (Object.keys(value).some((field) => !allowed.has(field))) {
    throw new BrowserRpcProtocolError(
      "Browser screenshot value contains an unsupported field."
    );
  }
}
var MAX_DECODED_BYTES, MAX_BASE64_CHARACTERS, BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS, BrowserConnectionScreenshot;
var init_browserConnectionScreenshotRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionScreenshotRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserConnectionRpc();
    init_validation();
    init_browserToolCallPolicy();
    MAX_DECODED_BYTES = 10 * 1024 * 1024;
    MAX_BASE64_CHARACTERS = 4 * Math.ceil(MAX_DECODED_BYTES / 3);
    BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS = {
      maxBase64Characters: MAX_BASE64_CHARACTERS,
      maxDecodedBytes: MAX_DECODED_BYTES,
      maxDimension: 2e3,
      maxPixels: 4e6
    };
    BrowserConnectionScreenshot = defineBrowserRpcMethod("browser.connection.screenshot", parseScreenshotParams, parseScreenshotResult);
  }
});

// shared/browser-rpc/src/protocol/browserPageSnapshotContract.ts
function parseBrowserPageSnapshot(value) {
  return parseSnapshot(value, requirePublicBrowserElementRef);
}
function parsePrivateBrowserPageSnapshot(value) {
  return parseSnapshot(value, requireBrowserElementRef);
}
function parseSnapshot(value, requireRef) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser snapshot must be an object.");
  }
  const allowedKeys = /* @__PURE__ */ new Set([
    "title",
    "url",
    "content",
    "omissions",
    "focus",
    "selection",
    "frames"
  ]);
  if (Object.keys(value).some((key) => !allowedKeys.has(key))) {
    throw new BrowserRpcProtocolError("Browser snapshot contains an unsupported field.");
  }
  const focus = value.focus === void 0 ? void 0 : requireSnapshotFocus(value.focus, requireRef);
  const selection = value.selection === void 0 ? void 0 : requireSnapshotSelection(value.selection, requireRef);
  const frames = value.frames === void 0 ? void 0 : requireFrameSnapshots(value.frames);
  return {
    title: requireString2(
      value.title,
      "title",
      true,
      BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxTitleLength
    ),
    url: requireString2(value.url, "url", false, BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxUrlLength),
    content: requireString2(
      value.content,
      "content",
      true,
      BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxContentCharacters
    ),
    omissions: requireOmissions(value.omissions),
    ...focus === void 0 ? {} : { focus },
    ...selection === void 0 ? {} : { selection },
    ...frames === void 0 ? {} : { frames }
  };
}
function requireFrameSnapshots(value) {
  if (!Array.isArray(value)) {
    throw new BrowserRpcProtocolError("frames must be an array.");
  }
  let admitted = 0;
  const parseFrames = (candidates, depth) => {
    if (candidates.length > 0 && depth > BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxFrameDepth) {
      throw new BrowserRpcProtocolError("frames nesting exceeds the limit.");
    }
    return candidates.map((candidate) => {
      admitted += 1;
      if (admitted > BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxFrames || !isRecord(candidate)) {
        throw new BrowserRpcProtocolError("frames exceeds the surface limit.");
      }
      const allowedKeys = /* @__PURE__ */ new Set([
        "frameRef",
        "owner",
        "title",
        "url",
        "content",
        "omissions",
        "frames"
      ]);
      if (Object.keys(candidate).some((key) => !allowedKeys.has(key))) {
        throw new BrowserRpcProtocolError("Frame snapshot contains an unsupported field.");
      }
      if (typeof candidate.frameRef !== "string" || !/^f_[0-9a-f]{32}$/u.test(candidate.frameRef)) {
        throw new BrowserRpcProtocolError("frameRef must be an opaque frame reference.");
      }
      if (!Array.isArray(candidate.frames)) {
        throw new BrowserRpcProtocolError("Frame snapshot frames must be an array.");
      }
      return {
        frameRef: candidate.frameRef,
        ...candidate.owner === void 0 ? {} : { owner: parseBrowserFrameSnapshotOwner(candidate.owner) },
        title: requireString2(
          candidate.title,
          "frame.title",
          true,
          BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxTitleLength
        ),
        url: requireString2(
          candidate.url,
          "frame.url",
          false,
          BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxUrlLength
        ),
        content: requireString2(
          candidate.content,
          "frame.content",
          true,
          BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxContentCharacters
        ),
        omissions: requireOmissions(candidate.omissions),
        frames: parseFrames(candidate.frames, depth + 1)
      };
    });
  };
  return parseFrames(value, 1);
}
function parseBrowserFrameSnapshotOwner(value) {
  if (!isRecord(value) || Object.keys(value).some((key) => key !== "id" && key !== "name")) {
    throw new BrowserRpcProtocolError("Frame owner must contain only id or name attributes.");
  }
  const owner = {};
  for (const attribute of ["id", "name"]) {
    if (value[attribute] !== void 0) {
      owner[attribute] = requireString2(
        value[attribute],
        `frame.owner.${attribute}`,
        false,
        BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxFrameOwnerAttributeLength
      );
    }
  }
  if (owner.id === void 0 && owner.name === void 0) {
    throw new BrowserRpcProtocolError("Frame owner must contain an id or name attribute.");
  }
  return owner;
}
function requireSnapshotFocus(value, requireRef) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("focus must be an object.");
  }
  if (Object.keys(value).some((key) => key !== "ref")) {
    throw new BrowserRpcProtocolError("focus contains an unsupported field.");
  }
  return { ref: requireRef(value.ref, "focus.ref") };
}
function requireSnapshotSelection(value, requireRef) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("selection must be an object.");
  }
  const allowedKeys = /* @__PURE__ */ new Set(["ref", "kind", "start", "end", "collapsed", "direction"]);
  if (Object.keys(value).some((key) => !allowedKeys.has(key))) {
    throw new BrowserRpcProtocolError("selection contains an unsupported field.");
  }
  const ref = requireRef(value.ref, "selection.ref");
  if (value.kind !== "input" && value.kind !== "textarea" && value.kind !== "contenteditable") {
    throw new BrowserRpcProtocolError(
      "selection.kind must be input, textarea, or contenteditable."
    );
  }
  const start = requireSelectionOffset(value.start, "selection.start");
  const end = requireSelectionOffset(value.end, "selection.end");
  if (end < start) throw new BrowserRpcProtocolError("selection.end must not precede start.");
  if (typeof value.collapsed !== "boolean" || value.collapsed !== (start === end)) {
    throw new BrowserRpcProtocolError("selection.collapsed does not match its offsets.");
  }
  const direction = value.direction;
  if (direction !== void 0 && (value.kind === "contenteditable" || direction !== "forward" && direction !== "backward" && direction !== "none")) {
    throw new BrowserRpcProtocolError("selection.direction is invalid for its kind.");
  }
  return {
    ref,
    kind: value.kind,
    start,
    end,
    collapsed: value.collapsed,
    ...direction === void 0 ? {} : { direction }
  };
}
function requireSelectionOffset(value, field) {
  if (!Number.isSafeInteger(value) || value < 0 || value > BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxSelectionOffset) {
    throw new BrowserRpcProtocolError(
      `${field} must be an integer between 0 and ${BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxSelectionOffset}.`
    );
  }
  return value;
}
function requireOmissions(value) {
  if (!Array.isArray(value)) {
    throw new BrowserRpcProtocolError("omissions must be an array.");
  }
  const omissions = [];
  for (const omission of value) {
    if (omission !== "child-frames" && omission !== "closed-shadow-roots" && omission !== "advanced-surface-limit" && omission !== "sensitive-content" && omission !== "reference-limit") {
      throw new BrowserRpcProtocolError("omissions contains an unsupported value.");
    }
    if (!omissions.includes(omission)) omissions.push(omission);
  }
  return omissions;
}
function requireString2(value, field, allowEmpty, maxLength) {
  if (typeof value !== "string" || !allowEmpty && value.length === 0) {
    throw new BrowserRpcProtocolError(
      `${field} must be ${allowEmpty ? "a string" : "a non-empty string"}.`
    );
  }
  if (value.length > maxLength) {
    throw new BrowserRpcProtocolError(`${field} must not exceed ${maxLength} characters.`);
  }
  return value;
}
var MAX_CONTENT_CHARACTERS, BROWSER_PAGE_SNAPSHOT_CONSTRAINTS;
var init_browserPageSnapshotContract = __esm({
  "shared/browser-rpc/src/protocol/browserPageSnapshotContract.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_browserElementRef();
    init_validation();
    MAX_CONTENT_CHARACTERS = 16384e3;
    BROWSER_PAGE_SNAPSHOT_CONSTRAINTS = {
      maxContentCharacters: MAX_CONTENT_CHARACTERS,
      maxSerializedResultBytes: 24 * 1024 * 1024,
      maxTitleLength: 512,
      maxUrlLength: 8192,
      maxSelectionOffset: MAX_CONTENT_CHARACTERS,
      maxFrames: 64,
      maxFrameDepth: 64,
      maxFrameOwnerAttributeLength: 512
    };
  }
});

// shared/browser-rpc/src/protocol/browserConnectionSnapshotRpc.ts
function parseSnapshotParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection snapshot params must be an object.");
  }
  const allowedKeys = /* @__PURE__ */ new Set(["connectionId", "capability"]);
  if (Object.keys(value).some((key) => !allowedKeys.has(key))) {
    throw new BrowserRpcProtocolError(
      "Browser snapshot request contains an unsupported field."
    );
  }
  const credentials = parseBrowserConnectionCredentials(value);
  return credentials;
}
function parseSnapshotResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection snapshot result is invalid.");
  }
  if (Object.keys(value).some((key) => key !== "snapshot" && key !== "connectionExpiresAt")) {
    throw new BrowserRpcProtocolError("Browser snapshot result contains an unsupported field.");
  }
  if (new TextEncoder().encode(JSON.stringify(value)).byteLength > BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxSerializedResultBytes) {
    throw new BrowserRpcProtocolError(
      `Browser snapshot result must not exceed ${BROWSER_PAGE_SNAPSHOT_CONSTRAINTS.maxSerializedResultBytes} bytes.`
    );
  }
  return {
    snapshot: parseBrowserPageSnapshot(value.snapshot),
    connectionExpiresAt: requirePositiveInteger(
      value.connectionExpiresAt,
      "connectionExpiresAt"
    )
  };
}
var BrowserConnectionSnapshot;
var init_browserConnectionSnapshotRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionSnapshotRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserConnectionRpc();
    init_browserPageSnapshotContract();
    init_validation();
    BrowserConnectionSnapshot = defineBrowserRpcMethod("browser.connection.snapshot", parseSnapshotParams, parseSnapshotResult);
  }
});

// shared/browser-rpc/src/protocol/browserConnectionRunRpc.ts
function parseRunOpenParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection run params must be an object.");
  }
  const summary = requireString(value.summary, "summary").trim().replaceAll(/\s+/gu, " ");
  if (summary.length > BROWSER_CONNECTION_RUN_CONSTRAINTS.maxSummaryLength) {
    throw new BrowserRpcProtocolError(
      `summary must not exceed ${BROWSER_CONNECTION_RUN_CONSTRAINTS.maxSummaryLength} characters.`
    );
  }
  const sourceFingerprint = requireString(value.sourceFingerprint, "sourceFingerprint");
  if (!SHA256_PATTERN.test(sourceFingerprint)) {
    throw new BrowserRpcProtocolError(
      "sourceFingerprint must be a lowercase SHA-256 hex digest."
    );
  }
  return {
    ...parseBrowserConnectionCredentials(value),
    summary,
    sourceFingerprint
  };
}
function parseBrowserConnectionRunCredentials(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection run credentials must be an object.");
  }
  return {
    ...parseBrowserConnectionCredentials(value),
    runId: requireBoundedString3(value.runId, "runId", RUN_ID_MAX_LENGTH),
    runCapability: requireBoundedString3(
      value.runCapability,
      "runCapability",
      RUN_CAPABILITY_MAX_LENGTH
    )
  };
}
function parseRunOperationParams(value) {
  if (!isRecord(value) || !isRecord(value.operation)) {
    throw new BrowserRpcProtocolError("Browser connection run operation must be an object.");
  }
  const credentials = parseBrowserConnectionRunCredentials(value);
  const name = value.operation.name;
  if (typeof name !== "string" || !BROWSER_CONNECTION_RUN_OPERATION_NAMES.includes(name)) {
    throw new BrowserRpcProtocolError(`Unsupported browser run operation '${String(name)}'.`);
  }
  if (!isRecord(value.operation.arguments)) {
    throw new BrowserRpcProtocolError("Browser run operation arguments must be an object.");
  }
  const params = { ...value.operation.arguments, ...connectionCredentials(credentials) };
  let parsed;
  switch (name) {
    case "snapshot":
      parsed = { ...BrowserConnectionSnapshot.parseParams(params) };
      break;
    case "screenshot":
      parsed = { ...BrowserConnectionScreenshot.parseParams(params) };
      break;
    case "click":
      parsed = { ...BrowserConnectionClick.parseParams(params) };
      break;
    case "hover":
      parsed = { ...BrowserConnectionHover.parseParams(params) };
      break;
    case "keyboard":
      parsed = { ...BrowserConnectionKeyboard.parseParams(params) };
      break;
    case "type":
      parsed = { ...BrowserConnectionType.parseParams(params) };
      break;
    case "locator":
      parsed = {
        ...connectionCredentials(credentials),
        ...parseBrowserConnectionLocatorOperation(value.operation.arguments)
      };
      break;
    case "navigation":
      parsed = {
        ...connectionCredentials(credentials),
        ...parseBrowserConnectionNavigationOperation(value.operation.arguments)
      };
      break;
  }
  return {
    ...credentials,
    operation: {
      name,
      arguments: withoutConnectionCredentials(parsed)
    }
  };
}
function parseRunOperationResult(value) {
  if (!isRecord(value) || typeof value.operation !== "string") {
    throw new BrowserRpcProtocolError("Browser connection run operation result is invalid.");
  }
  let parsed;
  switch (value.operation) {
    case "snapshot":
      parsed = { ...BrowserConnectionSnapshot.parseResult(value.value) };
      break;
    case "screenshot":
      parsed = { ...BrowserConnectionScreenshot.parseResult(value.value) };
      break;
    case "click":
      parsed = { ...BrowserConnectionClick.parseResult(value.value) };
      break;
    case "hover":
      parsed = { ...BrowserConnectionHover.parseResult(value.value) };
      break;
    case "keyboard":
      parsed = { ...BrowserConnectionKeyboard.parseResult(value.value) };
      break;
    case "type":
      parsed = { ...BrowserConnectionType.parseResult(value.value) };
      break;
    case "locator":
      parsed = { ...parseBrowserConnectionLocatorResult(value.value) };
      break;
    case "navigation":
      parsed = { ...parseBrowserConnectionNavigationResult(value.value) };
      break;
    default:
      throw new BrowserRpcProtocolError(
        `Unsupported browser run operation result '${value.operation}'.`
      );
  }
  const connectionExpiresAt = requirePositiveInteger(
    value.connectionExpiresAt,
    "connectionExpiresAt"
  );
  if (parsed.connectionExpiresAt !== connectionExpiresAt) {
    throw new BrowserRpcProtocolError(
      "Nested operation and run result connectionExpiresAt values must match."
    );
  }
  return { operation: value.operation, value: parsed, connectionExpiresAt };
}
function parseRunOpenResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser connection run result must be an object.");
  }
  return {
    runId: requireBoundedString3(value.runId, "runId", RUN_ID_MAX_LENGTH),
    runCapability: requireBoundedString3(
      value.runCapability,
      "runCapability",
      RUN_CAPABILITY_MAX_LENGTH
    ),
    expiresAt: requirePositiveInteger(value.expiresAt, "expiresAt"),
    connectionExpiresAt: requirePositiveInteger(
      value.connectionExpiresAt,
      "connectionExpiresAt"
    )
  };
}
function parseRunCloseResult(value) {
  if (!isRecord(value) || value.closed !== true) {
    throw new BrowserRpcProtocolError("closed must be true.");
  }
  return { closed: true };
}
function connectionCredentials(credentials) {
  return { connectionId: credentials.connectionId, capability: credentials.capability };
}
function withoutConnectionCredentials(value) {
  const rest = { ...value };
  delete rest.connectionId;
  delete rest.capability;
  return rest;
}
function requireBoundedString3(value, field, maxLength) {
  const parsed = requireString(value, field);
  if (parsed.length > maxLength) {
    throw new BrowserRpcProtocolError(`${field} must not exceed ${maxLength} characters.`);
  }
  return parsed;
}
var RUN_ID_MAX_LENGTH, RUN_CAPABILITY_MAX_LENGTH, SHA256_PATTERN, BROWSER_CONNECTION_RUN_CONSTRAINTS, BROWSER_CONNECTION_RUN_OPERATION_NAMES, BrowserConnectionRunOpen, BrowserConnectionRunClose, BrowserConnectionRunOperation;
var init_browserConnectionRunRpc = __esm({
  "shared/browser-rpc/src/protocol/browserConnectionRunRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_browserConnectionClickRpc();
    init_browserConnectionHoverRpc();
    init_browserConnectionKeyboardRpc();
    init_browserConnectionNavigationContract();
    init_browserConnectionLocatorContract();
    init_browserConnectionRpc();
    init_browserConnectionScreenshotRpc();
    init_browserConnectionSnapshotRpc();
    init_browserConnectionTypeRpc();
    init_validation();
    RUN_ID_MAX_LENGTH = 128;
    RUN_CAPABILITY_MAX_LENGTH = 256;
    SHA256_PATTERN = /^[a-f0-9]{64}$/u;
    BROWSER_CONNECTION_RUN_CONSTRAINTS = Object.freeze({
      maxSummaryLength: 160,
      maxRunIdLength: RUN_ID_MAX_LENGTH,
      maxRunCapabilityLength: RUN_CAPABILITY_MAX_LENGTH
    });
    BROWSER_CONNECTION_RUN_OPERATION_NAMES = [
      "snapshot",
      "screenshot",
      "click",
      "hover",
      "keyboard",
      "type",
      "locator",
      "navigation"
    ];
    BrowserConnectionRunOpen = defineBrowserRpcMethod("browser.connection.run.open", parseRunOpenParams, parseRunOpenResult);
    BrowserConnectionRunClose = defineBrowserRpcMethod("browser.connection.run.close", parseBrowserConnectionRunCredentials, parseRunCloseResult);
    BrowserConnectionRunOperation = defineBrowserRpcMethod("browser.connection.run.operation", parseRunOperationParams, parseRunOperationResult);
  }
});

// shared/browser-rpc/src/protocol/browserPageRpc.ts
function parseNavigateParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser page navigate params must be an object.");
  }
  return {
    ...parseBrowserSessionCredentials(value),
    tabId: requireBoundedString4(value.tabId, "tabId", MAX_TAB_ID_LENGTH),
    url: requireNavigableUrl(value.url)
  };
}
function parseNavigateResult(value) {
  if (!isRecord(value) || value.navigated !== true) {
    throw new BrowserRpcProtocolError("navigated must be true.");
  }
  return {
    navigated: true,
    sessionExpiresAt: requirePositiveInteger(value.sessionExpiresAt, "sessionExpiresAt")
  };
}
function requireBoundedString4(value, field, maxLength) {
  const parsed = requireString(value, field);
  if (parsed.length > maxLength) {
    throw new BrowserRpcProtocolError(`${field} must not exceed ${maxLength} characters.`);
  }
  return parsed;
}
function requireNavigableUrl(value) {
  const input = requireBoundedString4(value, "url", BROWSER_PAGE_URL_CONSTRAINTS.maxLength);
  const normalized = normalizeBrowserPageUrl(input);
  if (normalized === void 0) {
    throw new BrowserRpcProtocolError(
      "url must be an absolute HTTP or HTTPS URL without embedded credentials."
    );
  }
  return normalized;
}
function normalizeBrowserPageUrl(input) {
  if (input.length === 0 || input.length > BROWSER_PAGE_URL_CONSTRAINTS.maxLength) {
    return void 0;
  }
  try {
    const parsed = new URL(input);
    if (!BROWSER_PAGE_URL_CONSTRAINTS.protocols.some(
      (protocol) => protocol === parsed.protocol
    ) || parsed.username || parsed.password || parsed.href.length > BROWSER_PAGE_URL_CONSTRAINTS.maxLength) {
      return void 0;
    }
    return parsed.href;
  } catch {
    return void 0;
  }
}
var MAX_TAB_ID_LENGTH, BROWSER_PAGE_URL_CONSTRAINTS, BROWSER_PAGE_NAVIGATION_TIMING, BrowserPageNavigate;
var init_browserPageRpc = __esm({
  "shared/browser-rpc/src/protocol/browserPageRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_errors();
    init_validation();
    init_browserSessionRpc();
    MAX_TAB_ID_LENGTH = 128;
    BROWSER_PAGE_URL_CONSTRAINTS = {
      maxLength: 8192,
      protocols: ["http:", "https:"]
    };
    BROWSER_PAGE_NAVIGATION_TIMING = {
      loadTimeoutMs: 3e4,
      extensionRequestTimeoutMs: 32e3,
      mcpRequestTimeoutMs: 35e3
    };
    BrowserPageNavigate = defineBrowserRpcMethod("browser.page.navigate", parseNavigateParams, parseNavigateResult);
  }
});

// shared/browser-rpc/src/protocol/browserTabRpc.ts
function parseCredentials(value) {
  return parseBrowserSessionCredentials(value);
}
function parseCreateParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser tab create params must be an object.");
  }
  return {
    ...parseCredentials(value),
    ...value.groupName === void 0 ? {} : {
      groupName: requireBoundedString5(
        value.groupName,
        "groupName",
        MAX_GROUP_NAME_LENGTH2
      ).trim()
    }
  };
}
function parseTabParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser tab params must be an object.");
  }
  return {
    ...parseCredentials(value),
    tabId: requireBoundedString5(value.tabId, "tabId", MAX_TAB_ID_LENGTH2)
  };
}
function parseTabSummary(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser tab summary must be an object.");
  }
  const origin = value.origin;
  if (origin !== "agent" && origin !== "user") {
    throw new BrowserRpcProtocolError("origin must be 'agent' or 'user'.");
  }
  const summary = {
    tabId: requireBoundedString5(value.tabId, "tabId", MAX_TAB_ID_LENGTH2),
    origin,
    active: requireBoolean(value.active, "active")
  };
  if (value.url !== void 0) {
    summary.url = requireBoundedString5(value.url, "url", MAX_URL_LENGTH);
  }
  if (value.title !== void 0) {
    summary.title = requireBoundedString5(value.title, "title", MAX_TITLE_LENGTH);
  }
  return summary;
}
function parseTabListResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser tab list result must contain tabs.");
  }
  return {
    tabs: parseBoundedArray(value.tabs, "tabs", parseTabSummary),
    sessionExpiresAt: requirePositiveInteger(value.sessionExpiresAt, "sessionExpiresAt")
  };
}
function parseTabResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser tab result must be an object.");
  }
  return {
    tab: parseTabSummary(value.tab),
    sessionExpiresAt: requirePositiveInteger(value.sessionExpiresAt, "sessionExpiresAt")
  };
}
function parseTabCloseResult(value) {
  if (!isRecord(value) || value.closed !== true) {
    throw new BrowserRpcProtocolError("closed must be true.");
  }
  return {
    closed: true,
    sessionExpiresAt: requirePositiveInteger(value.sessionExpiresAt, "sessionExpiresAt")
  };
}
function parseTabReleaseResult(value) {
  if (!isRecord(value) || value.released !== true) {
    throw new BrowserRpcProtocolError("released must be true.");
  }
  return {
    released: true,
    sessionExpiresAt: requirePositiveInteger(value.sessionExpiresAt, "sessionExpiresAt")
  };
}
function parseUserListTabsResult(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser user tabs result must be an object.");
  }
  return {
    candidates: parseBoundedArray(value.candidates, "candidates", parseTabCandidate),
    sessionExpiresAt: requirePositiveInteger(value.sessionExpiresAt, "sessionExpiresAt")
  };
}
function parseTabCandidate(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser tab candidate must be an object.");
  }
  return {
    candidateRef: requireBoundedString5(value.candidateRef, "candidateRef", MAX_TAB_ID_LENGTH2),
    active: requireBoolean(value.active, "active"),
    ...value.url === void 0 ? {} : { url: requireBoundedString5(value.url, "url", MAX_URL_LENGTH) },
    ...value.title === void 0 ? {} : { title: requireBoundedString5(value.title, "title", MAX_TITLE_LENGTH) }
  };
}
function parseUserClaimTabParams(value) {
  if (!isRecord(value)) {
    throw new BrowserRpcProtocolError("Browser tab claim params must be an object.");
  }
  return {
    ...parseCredentials(value),
    candidateRef: requireBoundedString5(value.candidateRef, "candidateRef", MAX_TAB_ID_LENGTH2)
  };
}
function requireBoundedString5(value, field, maxLength) {
  const parsed = requireString(value, field);
  if (parsed.length > maxLength) {
    throw new BrowserRpcProtocolError(`${field} must not exceed ${maxLength} characters.`);
  }
  return parsed;
}
function requireBoolean(value, field) {
  if (typeof value !== "boolean") {
    throw new BrowserRpcProtocolError(`${field} must be a boolean.`);
  }
  return value;
}
function parseBoundedArray(value, field, parseItem) {
  if (!Array.isArray(value) || value.length > MAX_TAB_RESULTS) {
    throw new BrowserRpcProtocolError(
      `${field} must contain at most ${MAX_TAB_RESULTS} items.`
    );
  }
  return value.map(parseItem);
}
var MAX_TAB_ID_LENGTH2, MAX_GROUP_NAME_LENGTH2, MAX_TITLE_LENGTH, MAX_URL_LENGTH, MAX_TAB_RESULTS, BrowserTabCreate, BrowserTabList, BrowserTabGet, BrowserTabClose, BrowserTabRelease, BrowserUserListTabs, BrowserUserClaimTab;
var init_browserTabRpc = __esm({
  "shared/browser-rpc/src/protocol/browserTabRpc.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_browserRpcMethod();
    init_validation();
    init_browserSessionRpc();
    MAX_TAB_ID_LENGTH2 = 128;
    MAX_GROUP_NAME_LENGTH2 = 128;
    MAX_TITLE_LENGTH = 512;
    MAX_URL_LENGTH = 8192;
    MAX_TAB_RESULTS = 100;
    BrowserTabCreate = defineBrowserRpcMethod("browser.tab.create", parseCreateParams, parseTabResult);
    BrowserTabList = defineBrowserRpcMethod(
      "browser.tab.list",
      parseCredentials,
      parseTabListResult
    );
    BrowserTabGet = defineBrowserRpcMethod(
      "browser.tab.get",
      parseTabParams,
      parseTabResult
    );
    BrowserTabClose = defineBrowserRpcMethod(
      "browser.tab.close",
      parseTabParams,
      parseTabCloseResult
    );
    BrowserTabRelease = defineBrowserRpcMethod("browser.tab.release", parseTabParams, parseTabReleaseResult);
    BrowserUserListTabs = defineBrowserRpcMethod("browser.user.listTabs", parseCredentials, parseUserListTabsResult);
    BrowserUserClaimTab = defineBrowserRpcMethod("browser.user.claimTab", parseUserClaimTabParams, parseTabResult);
  }
});

// shared/browser-rpc/src/productIdentifiers.ts
var PRODUCT_ID, NATIVE_MESSAGING_HOST_NAME;
var init_productIdentifiers = __esm({
  "shared/browser-rpc/src/productIdentifiers.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    PRODUCT_ID = true ? "github-copilot-browser" : "github-copilot-browser";
    NATIVE_MESSAGING_HOST_NAME = typeof __COPILOT_BROWSER_NATIVE_MESSAGING_HOST_NAME__ === "string" ? __COPILOT_BROWSER_NATIVE_MESSAGING_HOST_NAME__ : "com.github.copilot.browser";
  }
});

// shared/browser-rpc/src/index.ts
var src_exports = {};
__export(src_exports, {
  BROWSER_ACTION_FAILURE_REASONS: () => BROWSER_ACTION_FAILURE_REASONS,
  BROWSER_APPROVAL_OUTCOMES: () => BROWSER_APPROVAL_OUTCOMES,
  BROWSER_CONNECTION_CLICK_BUTTONS: () => BROWSER_CONNECTION_CLICK_BUTTONS,
  BROWSER_CONNECTION_CLICK_MAX_MODIFIERS: () => BROWSER_CONNECTION_CLICK_MAX_MODIFIERS,
  BROWSER_CONNECTION_CLICK_MODIFIERS: () => BROWSER_CONNECTION_CLICK_MODIFIERS,
  BROWSER_CONNECTION_FINALIZE_TIMING: () => BROWSER_CONNECTION_FINALIZE_TIMING,
  BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS: () => BROWSER_CONNECTION_KEYBOARD_CONSTRAINTS,
  BROWSER_CONNECTION_LOCATOR_BOUNDARY_REASONS: () => BROWSER_CONNECTION_LOCATOR_BOUNDARY_REASONS,
  BROWSER_CONNECTION_LOCATOR_CONSTRAINTS: () => BROWSER_CONNECTION_LOCATOR_CONSTRAINTS,
  BROWSER_CONNECTION_LOCATOR_METHODS: () => BROWSER_CONNECTION_LOCATOR_METHODS,
  BROWSER_CONNECTION_NAVIGATION_ACTIONS: () => BROWSER_CONNECTION_NAVIGATION_ACTIONS,
  BROWSER_CONNECTION_NAVIGATION_CONSTRAINTS: () => BROWSER_CONNECTION_NAVIGATION_CONSTRAINTS,
  BROWSER_CONNECTION_OPEN_TIMING: () => BROWSER_CONNECTION_OPEN_TIMING,
  BROWSER_CONNECTION_RUN_CONSTRAINTS: () => BROWSER_CONNECTION_RUN_CONSTRAINTS,
  BROWSER_CONNECTION_RUN_OPERATION_NAMES: () => BROWSER_CONNECTION_RUN_OPERATION_NAMES,
  BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS: () => BROWSER_CONNECTION_SCREENSHOT_CONSTRAINTS,
  BROWSER_CONNECTION_TYPE_CONSTRAINTS: () => BROWSER_CONNECTION_TYPE_CONSTRAINTS,
  BROWSER_CONNECTION_URL_CONSTRAINTS: () => BROWSER_CONNECTION_URL_CONSTRAINTS,
  BROWSER_ELEMENT_REF_CONSTRAINTS: () => BROWSER_ELEMENT_REF_CONSTRAINTS,
  BROWSER_KEYBOARD_MODIFIER_KEYS: () => BROWSER_KEYBOARD_MODIFIER_KEYS,
  BROWSER_PAGE_NAVIGATION_TIMING: () => BROWSER_PAGE_NAVIGATION_TIMING,
  BROWSER_PAGE_OPERATIONS: () => BROWSER_PAGE_OPERATIONS,
  BROWSER_PAGE_SNAPSHOT_CONSTRAINTS: () => BROWSER_PAGE_SNAPSHOT_CONSTRAINTS,
  BROWSER_PAGE_URL_CONSTRAINTS: () => BROWSER_PAGE_URL_CONSTRAINTS,
  BROWSER_RPC_VERSION: () => BROWSER_RPC_VERSION,
  BROWSER_SEQUENTIAL_INPUT_DELAY_MS: () => BROWSER_SEQUENTIAL_INPUT_DELAY_MS,
  BROWSER_TOOL_CALL_TIMING: () => BROWSER_TOOL_CALL_TIMING,
  BrowserConnectionClick: () => BrowserConnectionClick,
  BrowserConnectionFinalize: () => BrowserConnectionFinalize,
  BrowserConnectionHover: () => BrowserConnectionHover,
  BrowserConnectionKeyboard: () => BrowserConnectionKeyboard,
  BrowserConnectionOpen: () => BrowserConnectionOpen,
  BrowserConnectionRunClose: () => BrowserConnectionRunClose,
  BrowserConnectionRunOpen: () => BrowserConnectionRunOpen,
  BrowserConnectionRunOperation: () => BrowserConnectionRunOperation,
  BrowserConnectionScreenshot: () => BrowserConnectionScreenshot,
  BrowserConnectionSnapshot: () => BrowserConnectionSnapshot,
  BrowserConnectionType: () => BrowserConnectionType,
  BrowserGetInfo: () => BrowserGetInfo,
  BrowserPageNavigate: () => BrowserPageNavigate,
  BrowserRpcCancelledError: () => BrowserRpcCancelledError,
  BrowserRpcClosedError: () => BrowserRpcClosedError,
  BrowserRpcErrorCode: () => BrowserRpcErrorCode,
  BrowserRpcProtocolError: () => BrowserRpcProtocolError,
  BrowserRpcRemoteError: () => BrowserRpcRemoteError,
  BrowserRpcResponseError: () => BrowserRpcResponseError,
  BrowserRpcTimeoutError: () => BrowserRpcTimeoutError,
  BrowserSessionFinalize: () => BrowserSessionFinalize,
  BrowserSessionOpen: () => BrowserSessionOpen,
  BrowserTabClose: () => BrowserTabClose,
  BrowserTabCreate: () => BrowserTabCreate,
  BrowserTabGet: () => BrowserTabGet,
  BrowserTabList: () => BrowserTabList,
  BrowserTabRelease: () => BrowserTabRelease,
  BrowserUserClaimTab: () => BrowserUserClaimTab,
  BrowserUserListTabs: () => BrowserUserListTabs,
  EXTENSION_APPROVAL_DECISION_MAX_POPUP_OBSERVATION_COUNT: () => EXTENSION_APPROVAL_DECISION_MAX_POPUP_OBSERVATION_COUNT,
  EXTENSION_APPROVAL_DECISION_REPORTING_TIMING: () => EXTENSION_APPROVAL_DECISION_REPORTING_TIMING,
  ExtensionGetInfo: () => ExtensionGetInfo,
  ExtensionInitialize: () => ExtensionInitialize,
  ExtensionReportApprovalDecision: () => ExtensionReportApprovalDecision,
  MAX_BROWSER_FRAME_ACCESS_FRAMES: () => MAX_BROWSER_FRAME_ACCESS_FRAMES,
  MAX_BROWSER_FRAME_ACCESS_ORIGINS: () => MAX_BROWSER_FRAME_ACCESS_ORIGINS,
  MAX_BROWSER_FRAME_ACCESS_ORIGIN_LENGTH: () => MAX_BROWSER_FRAME_ACCESS_ORIGIN_LENGTH,
  NATIVE_MESSAGING_HOST_NAME: () => NATIVE_MESSAGING_HOST_NAME,
  PRODUCT_ID: () => PRODUCT_ID,
  browserActionDiagnosticFromData: () => browserActionDiagnosticFromData,
  browserConnectionLocatorBoundaryReasonFromData: () => browserConnectionLocatorBoundaryReasonFromData,
  browserToolExecutionTimeoutMs: () => browserToolExecutionTimeoutMs,
  isBrowserPageOperation: () => isBrowserPageOperation,
  isBrowserRpcErrorCode: () => isBrowserRpcErrorCode,
  isCanonicalBrowserAccessOrigin: () => isCanonicalBrowserAccessOrigin,
  isCanonicalBrowserFrameAccessOrigin: () => isCanonicalBrowserFrameAccessOrigin,
  isRecord: () => isRecord,
  normalizeBrowserAccessOrigin: () => normalizeBrowserAccessOrigin,
  normalizeBrowserConnectionUrl: () => normalizeBrowserConnectionUrl,
  normalizeBrowserKeyChord: () => normalizeBrowserKeyChord,
  normalizeBrowserPageUrl: () => normalizeBrowserPageUrl,
  parseBrowserConnectionClickOptions: () => parseBrowserConnectionClickOptions,
  parseBrowserConnectionCredentials: () => parseBrowserConnectionCredentials,
  parseBrowserConnectionLocatorOperation: () => parseBrowserConnectionLocatorOperation,
  parseBrowserConnectionLocatorResult: () => parseBrowserConnectionLocatorResult,
  parseBrowserConnectionNavigationOperation: () => parseBrowserConnectionNavigationOperation,
  parseBrowserConnectionNavigationResult: () => parseBrowserConnectionNavigationResult,
  parseBrowserConnectionRunCredentials: () => parseBrowserConnectionRunCredentials,
  parseBrowserFrameSnapshotOwner: () => parseBrowserFrameSnapshotOwner,
  parseBrowserKeyChord: () => parseBrowserKeyChord,
  parseBrowserPageSnapshot: () => parseBrowserPageSnapshot,
  parseBrowserToolTimeoutMs: () => parseBrowserToolTimeoutMs,
  parseExtensionInfo: () => parseExtensionInfo,
  parsePrivateBrowserPageSnapshot: () => parsePrivateBrowserPageSnapshot,
  requireBrowserElementRef: () => requireBrowserElementRef,
  requirePublicBrowserElementRef: () => requirePublicBrowserElementRef,
  shouldReportBrowserRpcError: () => shouldReportBrowserRpcError
});
var init_src = __esm({
  "shared/browser-rpc/src/index.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_version();
    init_validation();
    init_extensionInfo();
    init_extensionRpc();
    init_extensionApprovalDecisionRpc();
    init_browserApproval();
    init_browserAccessOrigin();
    init_browserInstanceRpc();
    init_browserSessionRpc();
    init_browserConnectionRpc();
    init_browserToolCallPolicy();
    init_browserConnectionRunRpc();
    init_browserConnectionClickRpc();
    init_browserActionDiagnostic();
    init_browserConnectionLocatorContract();
    init_browserConnectionNavigationContract();
    init_browserConnectionHoverRpc();
    init_browserElementRef();
    init_browserConnectionKeyboardRpc();
    init_browserConnectionScreenshotRpc();
    init_browserConnectionTypeRpc();
    init_browserConnectionSnapshotRpc();
    init_browserPageSnapshotContract();
    init_browserConnectionUrl();
    init_browserPageRpc();
    init_browserTabRpc();
    init_productIdentifiers();
    init_errors();
  }
});

// shared/browser-rpc/src/connection/protocolPeer.ts
function toAbortSignal(token) {
  const controller = new AbortController();
  if (token.isCancellationRequested) {
    controller.abort();
    return { signal: controller.signal, dispose: () => {
    } };
  }
  const listener = token.onCancellationRequested(() => controller.abort());
  return { signal: controller.signal, dispose: () => listener.dispose() };
}
async function runHandlerWithCancellation(methodName, signal, handler) {
  signal.throwIfAborted();
  let rejectCancellation;
  const cancelled = new Promise((_resolve, reject) => {
    rejectCancellation = reject;
  });
  const onAbort = () => rejectCancellation(new BrowserRpcCancelledError(methodName));
  signal.addEventListener("abort", onAbort, { once: true });
  try {
    return await Promise.race([Promise.resolve().then(handler), cancelled]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}
function isAbortError(error) {
  return error instanceof Error && error.name === "AbortError";
}
function notifyCloseListener(listener, error) {
  try {
    listener(error);
  } catch {
  }
}
function positiveTimeout(value) {
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new TypeError("timeoutMs must be a positive integer.");
  }
  return value;
}
function asError(error) {
  return error instanceof Error ? error : new Error(String(error));
}
var import_vscode_jsonrpc2, BrowserRpcProtocolPeer, RequestBudgetMessageReader;
var init_protocolPeer = __esm({
  "shared/browser-rpc/src/connection/protocolPeer.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    import_vscode_jsonrpc2 = __toESM(require_main(), 1);
    init_errors();
    init_browserRpcMethod();
    BrowserRpcProtocolPeer = class {
      constructor(transport, options = {}) {
        this.options = options;
        if (options.maxIncomingRequests !== void 0 && (!Number.isSafeInteger(options.maxIncomingRequests) || options.maxIncomingRequests <= 0)) {
          throw new TypeError("maxIncomingRequests must be a positive integer.");
        }
        const reader = options.maxIncomingRequests ? new RequestBudgetMessageReader(
          transport.reader,
          options.maxIncomingRequests,
          options.onIncomingRequestLimitExceeded
        ) : transport.reader;
        this.messageConnection = (0, import_vscode_jsonrpc2.createMessageConnection)(reader, transport.writer, {
          error: (message) => this.reportProtocolError(new BrowserRpcProtocolError(message)),
          warn: () => {
          },
          info: () => {
          },
          log: () => {
          }
        });
        this.messageConnection.onError(
          ([error, message]) => this.handleTransportFailure(error, message)
        );
        this.messageConnection.onClose(() => this.handleMessageConnectionClose());
        this.messageConnection.listen();
      }
      options;
      registerNotificationHandler(notification, handler) {
        const registered = this.messageConnection.onNotification(
          getBrowserRpcNotificationType(notification),
          (rawParams) => {
            try {
              handler(
                notification.parseParams(
                  rawParams
                )
              );
            } catch (error) {
              this.reportProtocolError(asError(error), rawParams);
            }
          }
        );
        return () => registered.dispose();
      }
      async sendNotification(notification, params) {
        if (this.disposed) {
          throw new BrowserRpcClosedError("Browser RPC peer was disposed.");
        }
        await this.messageConnection.sendNotification(
          getBrowserRpcNotificationType(notification),
          notification.parseParams(params)
        );
      }
      messageConnection;
      closeListeners = /* @__PURE__ */ new Set();
      disposed = false;
      closeNotified = false;
      closeError;
      transportFailure;
      /** Registers a typed request handler and returns a callback that removes only that handler. */
      registerHandler(method, handler) {
        const registered = this.messageConnection.onRequest(
          getBrowserRpcRequestType(method),
          async (rawParams, cancellationToken) => {
            let params;
            try {
              params = method.parseParams(rawParams);
            } catch (error) {
              if (error instanceof BrowserRpcProtocolError) {
                return new import_vscode_jsonrpc2.ResponseError(
                  BrowserRpcErrorCode.InvalidParams,
                  error.message
                );
              }
              throw error;
            }
            const cancellation = toAbortSignal(cancellationToken);
            try {
              cancellation.signal.throwIfAborted();
              const invokeHandler = () => handler(params, cancellation.signal);
              return method.parseResult(
                method.cancellationMode === "cooperative" ? await invokeHandler() : await runHandlerWithCancellation(
                  method.name,
                  cancellation.signal,
                  invokeHandler
                )
              );
            } catch (error) {
              if (error instanceof BrowserRpcCancelledError || cancellation.signal.aborted && (method.cancellationMode === "eager" || isAbortError(error))) {
                const cancelled = error instanceof BrowserRpcCancelledError ? error : new BrowserRpcCancelledError(method.name);
                return new import_vscode_jsonrpc2.ResponseError(
                  BrowserRpcErrorCode.RequestCancelled,
                  cancelled.message
                );
              }
              if (error instanceof BrowserRpcResponseError) {
                return new import_vscode_jsonrpc2.ResponseError(error.code, error.message, error.data);
              }
              throw error;
            } finally {
              cancellation.dispose();
            }
          }
        );
        return () => registered.dispose();
      }
      /** Subscribes to the single peer-close notification without taking transport ownership. */
      onClose(listener) {
        if (this.closeNotified) {
          notifyCloseListener(listener, this.closeError);
          return () => {
          };
        }
        this.closeListeners.add(listener);
        return () => {
          this.closeListeners.delete(listener);
        };
      }
      /** Sends a typed request. A timeout disposes this peer but leaves transport closure to its owner. */
      async request(method, params, options = {}) {
        if (this.disposed) {
          return Promise.reject(new BrowserRpcClosedError("Browser RPC peer was disposed."));
        }
        const methodName = method.name;
        const timeoutMs = positiveTimeout(
          options.timeoutMs ?? this.options.requestTimeoutMs ?? 5e3
        );
        const parsedParams = method.parseParams(params);
        if (options.signal?.aborted) {
          return Promise.reject(new BrowserRpcCancelledError(methodName));
        }
        return new Promise((resolve3, reject) => {
          const cancellationSource = new import_vscode_jsonrpc2.CancellationTokenSource();
          let settled = false;
          const cleanup = () => {
            clearTimeout(timer);
            options.signal?.removeEventListener("abort", onAbort);
            cancellationSource.dispose();
          };
          const settleReject = (error) => {
            if (settled) {
              return;
            }
            settled = true;
            cleanup();
            reject(error);
          };
          const onAbort = () => cancellationSource.cancel();
          const timer = setTimeout(() => {
            const error = new BrowserRpcTimeoutError(methodName, timeoutMs);
            settleReject(error);
            this.dispose();
            this.notifyClosed(error);
          }, timeoutMs);
          options.signal?.addEventListener("abort", onAbort, { once: true });
          if (options.signal?.aborted) {
            settleReject(new BrowserRpcCancelledError(methodName));
            return;
          }
          this.messageConnection.sendRequest(
            getBrowserRpcRequestType(method),
            parsedParams,
            cancellationSource.token
          ).then(
            (result) => {
              if (settled) {
                return;
              }
              settled = true;
              cleanup();
              try {
                resolve3(method.parseResult(result));
              } catch (error) {
                reject(asError(error));
              }
            },
            (error) => settleReject(this.mapRequestError(error, methodName))
          );
        });
      }
      /** Idempotently stops protocol processing without closing the underlying transport. */
      dispose() {
        if (this.disposed) {
          return;
        }
        this.disposed = true;
        this.messageConnection.dispose();
      }
      mapRequestError(error, methodName) {
        if (error instanceof import_vscode_jsonrpc2.ResponseError) {
          if (error.code === import_vscode_jsonrpc2.ErrorCodes.PendingResponseRejected || error.code === import_vscode_jsonrpc2.ErrorCodes.ConnectionInactive || error.code === import_vscode_jsonrpc2.ErrorCodes.MessageWriteError) {
            return new BrowserRpcClosedError(this.transportFailure?.message ?? error.message);
          }
          if (error.code === BrowserRpcErrorCode.RequestCancelled) {
            return new BrowserRpcCancelledError(methodName);
          }
          return new BrowserRpcRemoteError(error.code, error.message, error.data);
        }
        return asError(error);
      }
      handleTransportFailure(error, message) {
        this.transportFailure = error;
        this.reportProtocolError(error, message);
        this.dispose();
        this.notifyClosed(error);
      }
      handleMessageConnectionClose() {
        this.dispose();
        this.notifyClosed(this.transportFailure);
      }
      reportProtocolError(error, message) {
        try {
          this.options.onProtocolError?.(error, message);
        } catch {
        }
      }
      notifyClosed(error) {
        if (this.closeNotified) {
          return;
        }
        this.closeNotified = true;
        this.closeError = error;
        for (const listener of this.closeListeners) {
          notifyCloseListener(listener, error);
        }
        this.closeListeners.clear();
      }
    };
    RequestBudgetMessageReader = class {
      constructor(reader, maxIncomingRequests, onLimitExceeded) {
        this.reader = reader;
        this.maxIncomingRequests = maxIncomingRequests;
        this.onLimitExceeded = onLimitExceeded;
      }
      reader;
      maxIncomingRequests;
      onLimitExceeded;
      incomingRequestCount = 0;
      get onError() {
        return this.reader.onError;
      }
      get onClose() {
        return this.reader.onClose;
      }
      get onPartialMessage() {
        return this.reader.onPartialMessage;
      }
      listen(callback) {
        return this.reader.listen((message) => {
          if (import_vscode_jsonrpc2.Message.isRequest(message)) {
            this.incomingRequestCount += 1;
            if (this.incomingRequestCount > this.maxIncomingRequests) {
              this.onLimitExceeded?.();
              return;
            }
          }
          callback(message);
        });
      }
      dispose() {
        this.reader.dispose();
      }
    };
  }
});

// shared/browser-rpc/src/connection/browserRpcConnection.ts
function createBrowserRpcConnection(transport, options = {}) {
  return new ManagedBrowserRpcConnection(transport, options);
}
function notifyCloseListener2(listener, error) {
  try {
    listener(error);
  } catch {
  }
}
var ManagedBrowserRpcConnection;
var init_browserRpcConnection = __esm({
  "shared/browser-rpc/src/connection/browserRpcConnection.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcMethod();
    init_protocolPeer();
    ManagedBrowserRpcConnection = class {
      constructor(transport, options) {
        this.transport = transport;
        this.peer = new BrowserRpcProtocolPeer(transport, options);
        this.removePeerCloseListener = this.peer.onClose((error) => this.closeWithError(error));
      }
      transport;
      registerNotificationHandler(notification, handler) {
        return this.peer.registerNotificationHandler(notification, handler);
      }
      sendNotification(notification, params) {
        return this.peer.sendNotification(notification, params);
      }
      peer;
      removePeerCloseListener = () => {
      };
      closeListeners = /* @__PURE__ */ new Set();
      closed = false;
      closeError;
      registerHandler(method, handler) {
        return this.peer.registerHandler(method, handler);
      }
      request(method, params, options = {}) {
        return this.peer.request(method, params, options);
      }
      onClose(listener) {
        if (this.closed) {
          notifyCloseListener2(listener, this.closeError);
          return () => {
          };
        }
        this.closeListeners.add(listener);
        return () => {
          this.closeListeners.delete(listener);
        };
      }
      close() {
        this.closeWithError();
      }
      closeWithError(error) {
        if (this.closed) {
          return;
        }
        this.closed = true;
        this.closeError = error;
        this.removePeerCloseListener();
        this.peer.dispose();
        try {
          this.transport.close();
        } finally {
          for (const listener of this.closeListeners) {
            notifyCloseListener2(listener, error);
          }
          this.closeListeners.clear();
        }
      }
    };
  }
});

// shared/browser-rpc/src/transport/browserRpcTransport.ts
function requireBrowserRpcMessage(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value) || value.jsonrpc !== "2.0") {
    throw new BrowserRpcProtocolError("Message is not Browser RPC 2.0.");
  }
  const message = value;
  if (!import_vscode_jsonrpc3.Message.isRequest(message) && !import_vscode_jsonrpc3.Message.isNotification(message) && !import_vscode_jsonrpc3.Message.isResponse(message)) {
    throw new BrowserRpcProtocolError(
      "Message is not a valid JSON-RPC request, response, or notification."
    );
  }
  return message;
}
var import_vscode_jsonrpc3;
var init_browserRpcTransport = __esm({
  "shared/browser-rpc/src/transport/browserRpcTransport.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    import_vscode_jsonrpc3 = __toESM(require_main(), 1);
    init_errors();
  }
});

// shared/browser-rpc/src/transport/framing.ts
function encodeBrowserRpcFrame(message, maxFrameBytes = DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES) {
  requireFrameLimit(maxFrameBytes);
  const payload = textEncoder.encode(JSON.stringify(message));
  if (payload.byteLength > maxFrameBytes) {
    throw new BrowserRpcProtocolError(`Browser RPC frame exceeds ${maxFrameBytes} bytes.`);
  }
  const frame = new Uint8Array(4 + payload.byteLength);
  new DataView(frame.buffer).setUint32(0, payload.byteLength, true);
  frame.set(payload, 4);
  return frame;
}
function requireFrameLimit(value) {
  if (!Number.isSafeInteger(value) || value <= 0 || value > 4294967295) {
    throw new TypeError("Browser RPC frame limit must be a positive 32-bit integer.");
  }
}
var DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES, MAX_BROWSER_RPC_LARGE_RESULT_FRAME_BYTES, textEncoder, textDecoder, BrowserRpcFrameDecoder, ByteQueue;
var init_framing = __esm({
  "shared/browser-rpc/src/transport/framing.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_errors();
    init_browserRpcTransport();
    DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES = 1024 * 1024;
    MAX_BROWSER_RPC_LARGE_RESULT_FRAME_BYTES = 32 * 1024 * 1024;
    textEncoder = new TextEncoder();
    textDecoder = new TextDecoder("utf-8", { fatal: true });
    BrowserRpcFrameDecoder = class {
      bytes = new ByteQueue();
      maxFrameBytes;
      pendingLength;
      constructor(maxFrameBytes = DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES) {
        requireFrameLimit(maxFrameBytes);
        this.maxFrameBytes = maxFrameBytes;
      }
      /** Appends bytes and returns every complete, validated message now available. */
      push(chunk) {
        this.bytes.append(chunk);
        const messages = [];
        while (true) {
          if (this.pendingLength === void 0) {
            const header = this.bytes.read(4);
            if (!header) break;
            const length = new DataView(
              header.buffer,
              header.byteOffset,
              header.byteLength
            ).getUint32(0, true);
            if (length > this.maxFrameBytes) {
              throw new BrowserRpcProtocolError(
                `Browser RPC frame exceeds ${this.maxFrameBytes} bytes.`
              );
            }
            this.pendingLength = length;
          }
          const payload = this.bytes.read(this.pendingLength);
          if (!payload) break;
          this.pendingLength = void 0;
          let parsed;
          try {
            parsed = JSON.parse(textDecoder.decode(payload));
          } catch (error) {
            throw new BrowserRpcProtocolError("Browser RPC frame contains invalid JSON.", {
              cause: error
            });
          }
          messages.push(requireBrowserRpcMessage(parsed));
        }
        return messages;
      }
      reset() {
        this.bytes.clear();
        this.pendingLength = void 0;
      }
    };
    ByteQueue = class {
      chunks = [];
      head = 0;
      headOffset = 0;
      available = 0;
      append(chunk) {
        if (chunk.byteLength === 0) return;
        this.chunks.push(chunk);
        this.available += chunk.byteLength;
      }
      read(length) {
        if (this.available < length) return void 0;
        if (length === 0) return new Uint8Array(0);
        const first = this.current();
        const firstAvailable = first.byteLength - this.headOffset;
        if (firstAvailable >= length) {
          const result2 = first.subarray(this.headOffset, this.headOffset + length);
          this.advance(length);
          return result2;
        }
        const result = new Uint8Array(length);
        let written = 0;
        while (written < length) {
          const current = this.current();
          const count = Math.min(length - written, current.byteLength - this.headOffset);
          result.set(current.subarray(this.headOffset, this.headOffset + count), written);
          this.advance(count);
          written += count;
        }
        return result;
      }
      advance(length) {
        this.available -= length;
        this.headOffset += length;
        const current = this.current();
        if (this.headOffset !== current.byteLength) return;
        this.chunks[this.head] = void 0;
        this.head += 1;
        this.headOffset = 0;
        if (this.available === 0) {
          this.chunks = [];
          this.head = 0;
          return;
        }
        if (this.head >= 64 && this.head * 2 >= this.chunks.length) {
          this.chunks = this.chunks.slice(this.head);
          this.head = 0;
        }
      }
      clear() {
        this.chunks = [];
        this.head = 0;
        this.headOffset = 0;
        this.available = 0;
      }
      current() {
        const current = this.chunks[this.head];
        if (!current) throw new BrowserRpcProtocolError("Browser RPC frame buffer is invalid.");
        return current;
      }
    };
  }
});

// shared/browser-rpc/src/transport/nodeStreamTransport.ts
function createNodeStreamBrowserRpcTransport(readable, writable, {
  closeWritable = true,
  closeResource,
  maxIncomingFrameBytes = DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES,
  maxOutgoingFrameBytes = DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES,
  onRequestReceived,
  onResponseSent
} = {}) {
  const reader = new FramedStreamMessageReader(
    readable,
    onRequestReceived,
    maxIncomingFrameBytes
  );
  const writer = new FramedStreamMessageWriter(
    writable,
    closeWritable,
    onResponseSent,
    maxOutgoingFrameBytes
  );
  let closed = false;
  return {
    reader,
    writer,
    close() {
      if (closed) {
        return;
      }
      closed = true;
      reader.close();
      writer.end();
      closeResource?.();
    }
  };
}
function asError2(error) {
  return error instanceof Error ? error : new BrowserRpcClosedError(String(error));
}
var import_vscode_jsonrpc4, FramedStreamMessageReader, FramedStreamMessageWriter;
var init_nodeStreamTransport = __esm({
  "shared/browser-rpc/src/transport/nodeStreamTransport.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    import_vscode_jsonrpc4 = __toESM(require_main(), 1);
    init_errors();
    init_browserRpcTransport();
    init_framing();
    FramedStreamMessageReader = class extends import_vscode_jsonrpc4.AbstractMessageReader {
      constructor(readable, onRequestReceived, maxIncomingFrameBytes = DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES) {
        super();
        this.readable = readable;
        this.onRequestReceived = onRequestReceived;
        this.decoder = new BrowserRpcFrameDecoder(maxIncomingFrameBytes);
      }
      readable;
      onRequestReceived;
      decoder;
      listening = false;
      closed = false;
      detach = () => {
      };
      listen(callback) {
        if (this.listening) {
          throw new Error("Browser RPC stream reader is already listening.");
        }
        this.listening = true;
        const onData = (chunk) => {
          try {
            const bytes = typeof chunk === "string" ? Buffer.from(chunk) : chunk;
            for (const message of this.decoder.push(bytes)) {
              if (import_vscode_jsonrpc4.Message.isRequest(message)) {
                this.notifyRequestReceived();
              }
              callback(message);
            }
          } catch (error) {
            const parsedError = asError2(error);
            this.decoder.reset();
            this.fireError(parsedError);
            this.readable.destroy(parsedError);
          }
        };
        const onError = (error) => {
          this.decoder.reset();
          this.fireError(error);
        };
        const onEnd = () => this.close();
        const onClose = () => this.close();
        this.detach = () => {
          this.readable.off("data", onData);
          this.readable.off("error", onError);
          this.readable.off("end", onEnd);
          this.readable.off("close", onClose);
          this.detach = () => {
          };
        };
        this.readable.on("data", onData);
        this.readable.on("error", onError);
        this.readable.on("end", onEnd);
        this.readable.on("close", onClose);
        return import_vscode_jsonrpc4.Disposable.create(() => this.detach());
      }
      close() {
        if (this.closed) return;
        this.closed = true;
        this.detach();
        this.decoder.reset();
        this.fireClose();
      }
      dispose() {
        this.detach();
        this.decoder.reset();
        super.dispose();
      }
      notifyRequestReceived() {
        try {
          this.onRequestReceived?.();
        } catch {
        }
      }
    };
    FramedStreamMessageWriter = class extends import_vscode_jsonrpc4.AbstractMessageWriter {
      constructor(writable, closeWritable, onResponseSent, maxOutgoingFrameBytes = DEFAULT_MAX_BROWSER_RPC_FRAME_BYTES) {
        super();
        this.writable = writable;
        this.closeWritable = closeWritable;
        this.onResponseSent = onResponseSent;
        this.maxOutgoingFrameBytes = maxOutgoingFrameBytes;
        writable.on("error", this.handleWritableError);
        writable.on("close", this.handleWritableClose);
      }
      writable;
      closeWritable;
      onResponseSent;
      maxOutgoingFrameBytes;
      errorCount = 0;
      disposed = false;
      ended = false;
      failure;
      writeTail = Promise.resolve();
      handleWritableError = (error) => {
        if (!this.disposed) {
          this.recordFailure(error);
        }
      };
      handleWritableClose = () => {
        this.writable.off("error", this.handleWritableError);
        this.writable.off("close", this.handleWritableClose);
        if (!this.disposed) {
          this.fireClose();
        }
      };
      write(value) {
        if (this.ended) {
          return Promise.reject(new BrowserRpcClosedError("Browser RPC writer is closed."));
        }
        const current = this.writeTail.then(() => this.writeFrame(value));
        this.writeTail = current.catch(() => {
        });
        return current;
      }
      writeFrame(value) {
        if (this.failure) return Promise.resolve();
        let message;
        let frame;
        try {
          message = requireBrowserRpcMessage(value);
          frame = encodeBrowserRpcFrame(message, this.maxOutgoingFrameBytes);
        } catch (error) {
          const failure = asError2(error);
          this.recordFailure(failure);
          return Promise.resolve();
        }
        return new Promise((resolve3) => {
          try {
            this.writable.write(Buffer.from(frame), (error) => {
              if (error) {
                this.recordFailure(error, message);
                resolve3();
                return;
              }
              if (import_vscode_jsonrpc4.Message.isResponse(message)) this.notifyResponseSent();
              resolve3();
            });
          } catch (error) {
            const failure = asError2(error);
            this.recordFailure(failure, message);
            resolve3();
          }
        });
      }
      end() {
        if (this.ended) {
          return;
        }
        this.ended = true;
        if (this.closeWritable) {
          void this.writeTail.finally(() => this.writable.end());
        }
      }
      dispose() {
        this.disposed = true;
        super.dispose();
      }
      reportError(error, message) {
        this.errorCount += 1;
        this.fireError(error, message, this.errorCount);
      }
      recordFailure(error, message) {
        if (this.failure) return;
        this.failure = error;
        this.reportError(error, message);
      }
      notifyResponseSent() {
        try {
          this.onResponseSent?.();
        } catch {
        }
      }
    };
  }
});

// shared/browser-rpc/src/node/streamConnection.ts
function createNodeStreamBrowserRpcConnection(readable, writable, {
  closeWritable = true,
  maxIncomingFrameBytes,
  maxOutgoingFrameBytes,
  onRequestReceived,
  onResponseSent,
  ...connectionOptions
} = {}) {
  return createBrowserRpcConnection(
    createNodeStreamBrowserRpcTransport(readable, writable, {
      closeWritable,
      maxIncomingFrameBytes,
      maxOutgoingFrameBytes,
      onRequestReceived,
      onResponseSent
    }),
    connectionOptions
  );
}
function createNodeSocketBrowserRpcConnection(socket, {
  maxIncomingFrameBytes,
  maxOutgoingFrameBytes,
  onRequestReceived,
  onResponseSent,
  ...connectionOptions
} = {}) {
  return createBrowserRpcConnection(
    createNodeStreamBrowserRpcTransport(socket, socket, {
      closeWritable: false,
      closeResource: () => socket.destroy(),
      maxIncomingFrameBytes,
      maxOutgoingFrameBytes,
      onRequestReceived,
      onResponseSent
    }),
    connectionOptions
  );
}
var init_streamConnection = __esm({
  "shared/browser-rpc/src/node/streamConnection.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_browserRpcConnection();
    init_nodeStreamTransport();
  }
});

// shared/browser-rpc/src/node/localEndpointDiscovery.ts
import { lstat, opendir, readFile as readFile2 } from "node:fs/promises";
import { homedir as homedir2, tmpdir } from "node:os";
import { isAbsolute as isAbsolute2, join as join2 } from "node:path";
function localEndpointDirectory() {
  const override = process.env[RUNTIME_DIRECTORY_ENV];
  if (override !== void 0) {
    if (!isAbsolute2(override)) {
      throw new Error(`${RUNTIME_DIRECTORY_ENV} must be an absolute path.`);
    }
    return override;
  }
  if (process.platform === "win32") {
    const localAppData = process.env.LOCALAPPDATA;
    const base2 = localAppData && isAbsolute2(localAppData) ? localAppData : join2(homedir2(), "AppData", "Local");
    return join2(base2, "GitHub", "Copilot Browser", "runtime");
  }
  const xdgRuntimeDirectory = process.env.XDG_RUNTIME_DIR;
  const useXdgRuntimeDirectory = xdgRuntimeDirectory !== void 0 && isAbsolute2(xdgRuntimeDirectory);
  const base = useXdgRuntimeDirectory ? xdgRuntimeDirectory : tmpdir();
  const userSuffix = process.getuid === void 0 ? "" : `-${process.getuid()}`;
  return join2(base, `${UNIX_RUNTIME_DIRECTORY_NAME}${useXdgRuntimeDirectory ? "" : userSuffix}`);
}
function localEndpointAddress(endpointId) {
  validateLocalEndpointId(endpointId);
  if (process.platform === "win32") {
    return `${WINDOWS_PIPE_ROOT}${PRODUCT_ID}-${endpointId}`;
  }
  return createUnixSocketAddress(localEndpointDirectory(), endpointId, UNIX_SOCKET_PATH_LIMIT);
}
function createUnixSocketAddress(runtimeDirectory, endpointId, pathLimit) {
  validateLocalEndpointId(endpointId);
  const token = endpointId.replaceAll("-", "");
  const fixedBytes = Buffer.byteLength(join2(runtimeDirectory, ".sock"));
  const availableTokenBytes = pathLimit - 1 - fixedBytes;
  if (availableTokenBytes < MINIMUM_SOCKET_TOKEN_LENGTH) {
    throw new Error(`Local IPC path cannot fit within the ${pathLimit}-byte platform limit.`);
  }
  const address = join2(
    runtimeDirectory,
    `${token.slice(0, Math.min(token.length, availableTokenBytes))}.sock`
  );
  if (Buffer.byteLength(address) >= pathLimit) {
    throw new Error(`Local IPC path exceeds the ${pathLimit}-byte platform limit.`);
  }
  return address;
}
async function discoverLocalEndpointDescriptorRecords() {
  const directory = localEndpointDirectory();
  let entries;
  try {
    entries = await opendir(directory);
  } catch {
    return [];
  }
  const records = [];
  let scanned = 0;
  for await (const entry of entries) {
    scanned += 1;
    if (scanned > MAX_DESCRIPTOR_FILES_SCANNED) break;
    if (!entry.isFile() || !entry.name.endsWith(DESCRIPTOR_SUFFIX)) continue;
    const descriptor = await readDescriptor(directory, entry.name);
    if (!descriptor) continue;
    records.push({ descriptor, processState: classifyLocalEndpointProcess(descriptor.pid) });
  }
  return records.sort((left, right) => right.descriptor.createdAt - left.descriptor.createdAt);
}
function classifyLocalEndpointProcess(pid) {
  try {
    process.kill(pid, 0);
    return "running";
  } catch (error) {
    return isErrorCode(error, "ESRCH") ? "missing" : "unknown";
  }
}
function validateLocalEndpointDiagnostics(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError("Endpoint diagnostics must be an object.");
  }
  const diagnostics = value;
  const requiredKeys = ["browserRpcVersion", "nativeHostVersion", "installationId"];
  const optionalKeys = ["extensionId", "extensionInstanceId", "extensionVersion"];
  if (Object.keys(diagnostics).some((key) => ![...requiredKeys, ...optionalKeys].includes(key))) {
    throw new TypeError("Endpoint diagnostics contain unsupported fields.");
  }
  if (typeof diagnostics.browserRpcVersion !== "number" || !Number.isSafeInteger(diagnostics.browserRpcVersion) || diagnostics.browserRpcVersion <= 0) {
    throw new TypeError("Endpoint diagnostics contain an invalid Browser RPC version.");
  }
  if (!isBoundedString(diagnostics.nativeHostVersion, 128)) {
    throw new TypeError("Endpoint diagnostics contain an invalid Native Host version.");
  }
  if (typeof diagnostics.installationId !== "string" || !/^[0-9a-f]{64}$/iu.test(diagnostics.installationId)) {
    throw new TypeError("Endpoint diagnostics contain an invalid Installation identity.");
  }
  for (const key of optionalKeys) {
    if (diagnostics[key] !== void 0 && !isBoundedString(diagnostics[key], 256)) {
      throw new TypeError(`Endpoint diagnostics contain an invalid ${key}.`);
    }
  }
  return value;
}
function validateLocalEndpointId(endpointId) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(endpointId)) {
    throw new TypeError("endpointId must be a UUID v4 value.");
  }
}
async function readDescriptor(directory, name) {
  const path = join2(directory, name);
  try {
    const info = await lstat(path);
    if (!info.isFile() || info.isSymbolicLink() || info.size > LOCAL_ENDPOINT_DESCRIPTOR_MAX_BYTES) {
      return void 0;
    }
    if (process.platform !== "win32" && (info.uid !== process.getuid?.() || (info.mode & 63) !== 0)) {
      return void 0;
    }
    const value = JSON.parse(await readFile2(path, "utf8"));
    if (!isEndpointDescriptor(value) || name !== `${value.endpointId}${DESCRIPTOR_SUFFIX}`) {
      return void 0;
    }
    return value.address === localEndpointAddress(value.endpointId) ? value : void 0;
  } catch {
    return void 0;
  }
}
function isEndpointDescriptor(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const descriptor = value;
  if (descriptor.schemaVersion !== LOCAL_ENDPOINT_DESCRIPTOR_SCHEMA_VERSION || typeof descriptor.endpointId !== "string" || typeof descriptor.address !== "string" || !Number.isSafeInteger(descriptor.pid) || descriptor.pid <= 0 || !Number.isSafeInteger(descriptor.createdAt) || descriptor.createdAt <= 0) {
    return false;
  }
  if (descriptor.diagnostics === void 0) return true;
  try {
    validateLocalEndpointDiagnostics(descriptor.diagnostics);
    return true;
  } catch {
    return false;
  }
}
function isBoundedString(value, maxLength) {
  return typeof value === "string" && value.length > 0 && value.length <= maxLength;
}
function isErrorCode(error, code) {
  return error !== null && typeof error === "object" && "code" in error && error.code === code;
}
var LOCAL_ENDPOINT_DESCRIPTOR_MAX_BYTES, LOCAL_ENDPOINT_DESCRIPTOR_SCHEMA_VERSION, DESCRIPTOR_SUFFIX, MAX_DESCRIPTOR_FILES_SCANNED, WINDOWS_PIPE_ROOT, UNIX_SOCKET_PATH_LIMIT, UNIX_RUNTIME_DIRECTORY_NAME, MINIMUM_SOCKET_TOKEN_LENGTH, RUNTIME_DIRECTORY_ENV;
var init_localEndpointDiscovery = __esm({
  "shared/browser-rpc/src/node/localEndpointDiscovery.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_productIdentifiers();
    LOCAL_ENDPOINT_DESCRIPTOR_MAX_BYTES = 4 * 1024;
    LOCAL_ENDPOINT_DESCRIPTOR_SCHEMA_VERSION = 1;
    DESCRIPTOR_SUFFIX = ".json";
    MAX_DESCRIPTOR_FILES_SCANNED = 1024;
    WINDOWS_PIPE_ROOT = "\\\\.\\pipe\\";
    UNIX_SOCKET_PATH_LIMIT = process.platform === "darwin" ? 103 : 107;
    UNIX_RUNTIME_DIRECTORY_NAME = "gcb";
    MINIMUM_SOCKET_TOKEN_LENGTH = 20;
    RUNTIME_DIRECTORY_ENV = "COPILOT_BROWSER_RUNTIME_DIR";
  }
});

// shared/browser-rpc/src/node/localEndpointRegistry.ts
import { randomUUID } from "node:crypto";
import { chmod, lstat as lstat2, mkdir, rename, rm, writeFile } from "node:fs/promises";
import { join as join3 } from "node:path";
async function prepareLocalEndpointAddress(endpointId) {
  await ensurePrivateRuntimeDirectory();
  const address = localEndpointAddress(endpointId);
  if (process.platform !== "win32") {
    await rm(address, { force: true });
  }
  return address;
}
async function publishLocalEndpointDescriptor(endpointId, address, diagnostics) {
  validateLocalEndpointId(endpointId);
  if (address !== localEndpointAddress(endpointId)) {
    throw new Error("Local endpoint address does not match its endpoint ID.");
  }
  await ensurePrivateRuntimeDirectory();
  if (process.platform !== "win32") {
    await chmod(address, 384);
    const socket = await lstat2(address);
    if (!socket.isSocket() || socket.uid !== process.getuid?.()) {
      throw new Error("Local IPC socket is not owned by the current user.");
    }
  }
  const descriptor = {
    schemaVersion: LOCAL_ENDPOINT_DESCRIPTOR_SCHEMA_VERSION,
    endpointId,
    address,
    pid: process.pid,
    createdAt: Date.now(),
    ...diagnostics === void 0 ? {} : { diagnostics: validateLocalEndpointDiagnostics(diagnostics) }
  };
  const serialized = JSON.stringify(descriptor);
  if (Buffer.byteLength(serialized) > LOCAL_ENDPOINT_DESCRIPTOR_MAX_BYTES) {
    throw new Error("Local endpoint descriptor exceeds the size limit.");
  }
  const target = descriptorPath(endpointId);
  const temporary = `${target}.${randomUUID()}.tmp`;
  try {
    await writeFile(temporary, serialized, {
      encoding: "utf8",
      flag: "wx",
      mode: 384
    });
    await rename(temporary, target);
  } finally {
    await rm(temporary, { force: true });
  }
}
async function cleanupLocalEndpoint(endpointId, address) {
  validateLocalEndpointId(endpointId);
  if (address !== localEndpointAddress(endpointId)) {
    throw new Error("Local endpoint address does not match its endpoint ID.");
  }
  await rm(descriptorPath(endpointId), { force: true });
  if (process.platform !== "win32") {
    await rm(address, { force: true });
  }
}
async function discoverLocalEndpointAddresses() {
  return (await discoverLocalEndpointDescriptors()).map(({ address }) => address);
}
async function discoverLocalEndpointDescriptors() {
  const records = await discoverLocalEndpointDescriptorRecords();
  const liveDescriptors = [];
  for (const { descriptor, processState } of records) {
    if (processState === "missing") {
      await rm(descriptorPath(descriptor.endpointId), { force: true });
      if (process.platform !== "win32") {
        await rm(descriptor.address, { force: true });
      }
      continue;
    }
    liveDescriptors.push(descriptor);
    if (liveDescriptors.length > MAX_DISCOVERED_ENDPOINTS) {
      liveDescriptors.sort((left, right) => right.createdAt - left.createdAt);
      liveDescriptors.length = MAX_DISCOVERED_ENDPOINTS;
    }
  }
  return liveDescriptors.sort((left, right) => right.createdAt - left.createdAt).slice(0, MAX_DISCOVERED_ENDPOINTS);
}
async function ensurePrivateRuntimeDirectory() {
  const directory = localEndpointDirectory();
  await mkdir(directory, { recursive: true, mode: 448 });
  if (process.platform === "win32") {
    return;
  }
  const info = await lstat2(directory);
  if (!info.isDirectory() || info.isSymbolicLink()) {
    throw new Error("Local runtime path must be a real directory.");
  }
  if (info.uid !== process.getuid?.()) {
    throw new Error("Local runtime directory is not owned by the current user.");
  }
  if ((info.mode & 63) !== 0) {
    throw new Error("Local runtime directory must not be accessible by other users.");
  }
}
function descriptorPath(endpointId) {
  return join3(localEndpointDirectory(), `${endpointId}${DESCRIPTOR_SUFFIX2}`);
}
var DESCRIPTOR_SUFFIX2, MAX_DISCOVERED_ENDPOINTS;
var init_localEndpointRegistry = __esm({
  "shared/browser-rpc/src/node/localEndpointRegistry.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_localEndpointDiscovery();
    DESCRIPTOR_SUFFIX2 = ".json";
    MAX_DISCOVERED_ENDPOINTS = 64;
  }
});

// shared/browser-rpc/src/node/index.ts
var node_exports = {};
__export(node_exports, {
  MAX_BROWSER_RPC_LARGE_RESULT_FRAME_BYTES: () => MAX_BROWSER_RPC_LARGE_RESULT_FRAME_BYTES,
  cleanupLocalEndpoint: () => cleanupLocalEndpoint,
  createNodeSocketBrowserRpcConnection: () => createNodeSocketBrowserRpcConnection,
  createNodeStreamBrowserRpcConnection: () => createNodeStreamBrowserRpcConnection,
  discoverLocalEndpointAddresses: () => discoverLocalEndpointAddresses,
  discoverLocalEndpointDescriptors: () => discoverLocalEndpointDescriptors,
  localEndpointAddress: () => localEndpointAddress,
  localEndpointDirectory: () => localEndpointDirectory,
  prepareLocalEndpointAddress: () => prepareLocalEndpointAddress,
  publishLocalEndpointDescriptor: () => publishLocalEndpointDescriptor
});
var init_node = __esm({
  "shared/browser-rpc/src/node/index.ts"() {
    "use strict";
    init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
    init_streamConnection();
    init_framing();
    init_localEndpointRegistry();
  }
});

// plugin/shared/scripts/nativeMessagingRegistration.mjs
init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
import { execFile as execFile2 } from "node:child_process";
import { createHash as createHash2, randomUUID as randomUUID2 } from "node:crypto";
import { once } from "node:events";
import { connect } from "node:net";
import { mkdir as mkdir2, readFile as readFile3, readdir, rename as rename2, rm as rm2, stat as stat2, writeFile as writeFile2 } from "node:fs/promises";
import { setTimeout as delay } from "node:timers/promises";
import { dirname as dirname2, isAbsolute as isAbsolute3, join as join4, resolve as resolve2 } from "node:path";
import { promisify as promisify2 } from "node:util";

// plugin/shared/scripts/pluginPlan.mjs
init_define_COPILOT_BROWSER_PLUGIN_CHANNEL();
import { execFile } from "node:child_process";
import { createHash } from "node:crypto";
import { readFile, stat } from "node:fs/promises";
import { homedir, platform } from "node:os";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

// plugin/shared/.plugin/plugin.json
var plugin_default = {
  name: "browser-use",
  description: "GitHub Copilot Browser Use plugin.",
  version: "0.0.4",
  author: {
    name: "GitHub"
  },
  mcpServers: ".mcp.json",
  skills: "skills",
  postInstallMessage: "Load the matching GitHub Copilot extension, then start a new session. If the extension is not installed or enabled, use `/browser-use:doctor` for channel-appropriate installation guidance. Browser registration activates automatically at session start, and Browser guidance loads automatically when needed. Use `/browser-use:activate` to activate this installation immediately or repair setup, `/browser-use:doctor` for diagnostics, and `/browser-use:deactivate` before uninstalling or replacing this installation."
};

// plugin/dev/channel.json
var channel_default = {
  channel: "dev",
  productId: "github-copilot-browser-dev",
  nativeMessagingHostName: "com.github.copilot.browser.dev",
  extensionId: "dpkmommpdhajlaebcicbbmfdmkohmehi",
  extensionName: "GitHub Copilot",
  advancedPageSurfaces: true,
  extensionPublicKey: "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0FaW7/YkDngCegAuXXxhhP72dJ3cERtCgXZ4oRLAzUU7yU2YTH7P/9pBvGcI7fhZKU0FvMtvGcakDnA5+5W7bcUlWx8R3oNSQe1OcTRDqk9yayKUnQb4I83yogkF2tWzsnt3sQNn/LzSFeXVWAYINLvhJ7O0dKJoh1rVH2/TzSkumq7Ey4OHb0bIefWYwJUEFXGj+F5amYDj4NowjekJTL1aiOAIj44xrLn06LvzYF3B58fqKgJzbBpuKjUbm5igCN/oydnlxc6SUaBhx6ilLAt/kFLzGnlkM9/l2h95RyJlvSYLcYhoWM6/R6IdqyE11s/aOGt3y/QIPgU6HuQnnwIDAQAB"
};

// plugin/shared/scripts/pluginPlan.mjs
var pluginRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
var execFileAsync = promisify(execFile);
var channel = typeof define_COPILOT_BROWSER_PLUGIN_CHANNEL_default === "object" ? define_COPILOT_BROWSER_PLUGIN_CHANNEL_default : channel_default;
var installRootEnvironment = `COPILOT_BROWSER_${channel.channel.replaceAll("-", "_").toUpperCase()}_INSTALL_ROOT`;
var PluginUserError = class extends Error {
};
function parsePluginVersion(value) {
  const match = /^(\d+(?:\.\d+){2,3})(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(
    value
  );
  if (!match) throw new PluginUserError("The plugin version is invalid.");
  const coreParts = match[1].split(".");
  const prerelease = match[2]?.split(".");
  if ([...coreParts, ...prerelease ?? []].some(
    (part) => /^\d+$/.test(part) && (part.length > 1 && part.startsWith("0") || !Number.isSafeInteger(Number(part)))
  )) {
    throw new PluginUserError("The plugin version is invalid.");
  }
  return { core: coreParts.map(Number), prerelease };
}
async function createRegistrationPlan() {
  const distDirectory = join(pluginRoot, "dist");
  const sourceNativeHostBundle = join(distDirectory, "native-host.cjs");
  const sourceBundle = await readRequiredFile(sourceNativeHostBundle);
  const bundleSha256 = createHash("sha256").update(sourceBundle).digest("hex");
  const installationSha256 = createHash("sha256").update(sourceBundle).update("\0").update(platform()).update("\0").update(normalizePath(pluginRoot)).digest("hex");
  const installRoot = pluginInstallRoot();
  const version = validateVersion(plugin_default.version);
  const versionDirectory = join(installRoot, "versions", `${version}-${installationSha256}`);
  const nativeHostBundle = join(versionDirectory, "native-host.cjs");
  const launcherPath = join(
    versionDirectory,
    platform() === "win32" ? "native-host.bat" : "native-host"
  );
  const manifest = {
    name: channel.nativeMessagingHostName,
    description: "GitHub Copilot Browser Native Messaging Host",
    path: launcherPath,
    type: "stdio",
    allowed_origins: [`chrome-extension://${channel.extensionId}/`]
  };
  const manifestPaths = nativeMessagingManifestPaths(installRoot);
  const registryKey = platform() === "win32" ? `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${channel.nativeMessagingHostName}` : void 0;
  return {
    channel: channel.channel,
    hostName: channel.nativeMessagingHostName,
    extensionId: channel.extensionId,
    pluginRoot,
    sourceNativeHostBundle,
    bundleSha256,
    installationSha256,
    installRoot,
    version,
    versionDirectory,
    activeInstallationPath: join(installRoot, "active-installation.json"),
    pendingInstallationPath: join(installRoot, "pending-installation.json"),
    activationLockPath: join(installRoot, ".activation-lock"),
    nativeHostBundle,
    launcherPath,
    manifestPaths,
    registryKey,
    manifest
  };
}
function launcherContent(nativeHostBundle, installationId, productVersion) {
  if (!/^[0-9a-f]{64}$/u.test(installationId)) {
    throw new PluginUserError("The Browser installation identity is invalid.");
  }
  validateVersion(productVersion);
  if (platform() === "win32") {
    return `@echo off\r
"${escapeBatchPath(process.execPath)}" "${escapeBatchPath(nativeHostBundle)}" --installation-id "${installationId}" --product-version "${productVersion}" %*\r
`;
  }
  return `#!/bin/sh
exec ${shellQuote(process.execPath)} ${shellQuote(nativeHostBundle)} --installation-id ${shellQuote(installationId)} --product-version ${shellQuote(productVersion)} "$@"
`;
}
async function launcherIsExecutable(path) {
  if (platform() === "win32") return true;
  try {
    return ((await stat(path)).mode & 64) !== 0;
  } catch (error) {
    if (isMissingFileError(error)) return false;
    throw error;
  }
}
async function readRequiredFile(path) {
  try {
    return await readFile(path);
  } catch (error) {
    if (isMissingFileError(error)) {
      throw new PluginUserError(
        "Required Browser Use plugin files are missing. Reinstall the plugin."
      );
    }
    throw error;
  }
}
function pathsEqual(left, right) {
  const normalizedLeft = resolve(left);
  const normalizedRight = resolve(right);
  return platform() === "win32" ? normalizedLeft.toLowerCase() === normalizedRight.toLowerCase() : normalizedLeft === normalizedRight;
}
function chromiumConfigRoot(environment = process.env) {
  const configured = environment.XDG_CONFIG_HOME;
  return configured && isAbsolute(configured) ? resolve(configured) : join(homedir(), ".config");
}
function manifestMatchesPlan(actual, plan) {
  return actual !== null && typeof actual === "object" && actual.name === plan.manifest.name && actual.description === plan.manifest.description && typeof actual.path === "string" && pathsEqual(actual.path, plan.launcherPath) && actual.type === plan.manifest.type && Array.isArray(actual.allowed_origins) && actual.allowed_origins.length === 1 && actual.allowed_origins[0] === plan.manifest.allowed_origins[0];
}
async function readRegistryDefaultValue(registryKey) {
  try {
    const { stdout } = await execFileAsync("reg.exe", ["query", registryKey, "/ve"], {
      windowsHide: true
    });
    return /^\s+.*?\s+REG_SZ\s+(.+)$/m.exec(stdout)?.[1]?.trim();
  } catch (error) {
    if (!isMissingRegistryKeyError(error)) throw error;
    return void 0;
  }
}
function isMissingFileError(error) {
  return isFileSystemError(error, "ENOENT");
}
function isFileSystemError(error, code) {
  return error !== null && typeof error === "object" && "code" in error && error.code === code;
}
function isMissingRegistryKeyError(error) {
  return error !== null && typeof error === "object" && "code" in error && (error.code === 1 || error.code === "1");
}
function pluginInstallRoot() {
  const override = process.env[installRootEnvironment];
  if (override !== void 0) {
    if (!isAbsolute(override)) {
      throw new PluginUserError(`${installRootEnvironment} must be an absolute path.`);
    }
    return resolve(override);
  }
  if (platform() === "win32") {
    const localAppData = process.env.LOCALAPPDATA;
    const base2 = localAppData && isAbsolute(localAppData) ? localAppData : join(homedir(), "AppData", "Local");
    return join(base2, "GitHub", "Copilot Browser", channel.channel);
  }
  if (platform() === "darwin") {
    return join(
      homedir(),
      "Library",
      "Application Support",
      "GitHub",
      "Copilot Browser",
      channel.channel
    );
  }
  const xdgDataHome = process.env.XDG_DATA_HOME;
  const base = xdgDataHome && isAbsolute(xdgDataHome) ? xdgDataHome : join(homedir(), ".local", "share");
  return join(base, "github-copilot", "browser", channel.channel);
}
function nativeMessagingManifestPaths(installRoot) {
  const filename = `${channel.nativeMessagingHostName}.json`;
  if (platform() === "win32") return [join(installRoot, filename)];
  if (platform() === "darwin") {
    return [
      join(
        homedir(),
        "Library",
        "Application Support",
        "Google",
        "Chrome",
        "NativeMessagingHosts",
        filename
      ),
      join(
        homedir(),
        "Library",
        "Application Support",
        "Microsoft Edge",
        "NativeMessagingHosts",
        filename
      )
    ];
  }
  const configRoot = chromiumConfigRoot();
  return [
    join(configRoot, "google-chrome", "NativeMessagingHosts", filename),
    join(configRoot, "microsoft-edge", "NativeMessagingHosts", filename)
  ];
}
function escapeBatchPath(value) {
  if (/["\r\n]/.test(value)) {
    throw new PluginUserError("The Node.js executable path is unsupported.");
  }
  return value.replaceAll("%", "%%");
}
function shellQuote(value) {
  return `'${value.replaceAll("'", `'"'"'`)}'`;
}
function validateVersion(version) {
  parsePluginVersion(version);
  return version;
}
function normalizePath(path) {
  return platform() === "win32" ? path.toLowerCase() : path;
}

// plugin/shared/scripts/nativeMessagingRegistration.mjs
var execFileAsync2 = promisify2(execFile2);
var ACTIVATION_LOCK_WAIT_MS = 5e3;
var ACTIVATION_LOCK_STALE_MS = 12e4;
var CONNECTION_WAIT_MS = 15e3;
var CONNECTION_POLL_INTERVAL_MS = 500;
var CONNECTION_PROBE_TIMEOUT_MS = 1e3;
var MAX_CONNECTION_CANDIDATES = 32;
var MAX_CONNECTION_PROBES = 4;
async function runActivationCli(args) {
  try {
    if (!parseArguments(args, "activate")) return false;
    await activateBrowserRegistration();
    console.log("Browser setup activated for this installation.");
    return true;
  } catch (error) {
    reportError(error);
    return false;
  }
}
async function runSessionStartActivation(plan) {
  try {
    await activateBrowserRegistration(plan);
    return true;
  } catch {
    return false;
  }
}
async function waitForBrowserConnection({ timeoutMs = CONNECTION_WAIT_MS } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Math.min(timeoutMs, CONNECTION_WAIT_MS));
  const sockets = /* @__PURE__ */ new Set();
  try {
    return await abortable(
      pollBrowserConnection(controller.signal, sockets),
      controller.signal
    );
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
    controller.abort();
    for (const socket of sockets) socket.destroy();
  }
}
async function pollBrowserConnection(signal, sockets) {
  const { BrowserGetInfo: BrowserGetInfo2, BROWSER_RPC_VERSION: BROWSER_RPC_VERSION2 } = await Promise.resolve().then(() => (init_src(), src_exports));
  const { createNodeSocketBrowserRpcConnection: createNodeSocketBrowserRpcConnection2, discoverLocalEndpointAddresses: discoverLocalEndpointAddresses2 } = await Promise.resolve().then(() => (init_node(), node_exports));
  while (!signal.aborted) {
    const addresses = (await discoverLocalEndpointAddresses2().catch(() => [])).slice(
      0,
      MAX_CONNECTION_CANDIDATES
    );
    if (signal.aborted) return false;
    let next = 0;
    const results = await Promise.all(
      Array.from({ length: Math.min(MAX_CONNECTION_PROBES, addresses.length) }, async () => {
        const infos2 = [];
        while (next < addresses.length && !signal.aborted) {
          const info = await probe(addresses[next++], signal);
          if (info) infos2.push(info);
        }
        return infos2;
      })
    );
    const infos = results.flat();
    const identityCounts = /* @__PURE__ */ new Map();
    for (const { extensionInstanceId } of infos) {
      identityCounts.set(
        extensionInstanceId,
        (identityCounts.get(extensionInstanceId) ?? 0) + 1
      );
    }
    if (infos.some(({ extensionInstanceId }) => identityCounts.get(extensionInstanceId) === 1)) {
      return true;
    }
    await delay(CONNECTION_POLL_INTERVAL_MS, void 0, { signal });
  }
  return false;
  async function probe(address, signal2) {
    const probeSignal = AbortSignal.any([
      signal2,
      AbortSignal.timeout(CONNECTION_PROBE_TIMEOUT_MS)
    ]);
    let socket;
    let rpc;
    try {
      probeSignal.throwIfAborted();
      socket = connect(address);
      sockets.add(socket);
      await once(socket, "connect", { signal: probeSignal });
      rpc = createNodeSocketBrowserRpcConnection2(socket, {
        requestTimeoutMs: CONNECTION_PROBE_TIMEOUT_MS
      });
      const info = await rpc.request(BrowserGetInfo2, {}, { signal: probeSignal });
      return info.protocolVersion === BROWSER_RPC_VERSION2 && info.extensionId === channel.extensionId ? info : void 0;
    } catch {
      return void 0;
    } finally {
      rpc?.close();
      socket?.destroy();
      sockets.delete(socket);
    }
  }
}
function abortable(operation, signal) {
  signal.throwIfAborted();
  return new Promise((resolve3, reject) => {
    const abort = () => reject(signal.reason);
    signal.addEventListener("abort", abort, { once: true });
    operation.then(resolve3, reject).finally(() => signal.removeEventListener("abort", abort));
  });
}
async function activateBrowserRegistration(plan) {
  plan ??= await createRegistrationPlan();
  return withActivationLock(plan, async () => {
    await installNativeHostBundle(plan);
    await writeFileIfChanged(
      plan.launcherPath,
      launcherContent(plan.nativeHostBundle, plan.installationSha256, plan.version),
      493
    );
    const candidate = activeInstallationFor(plan);
    await writeFileAtomically(
      plan.pendingInstallationPath,
      `${JSON.stringify(candidate, null, 2)}
`,
      384
    );
    await applyRegistration(plan, plan.manifest);
    await writeFileAtomically(
      plan.activeInstallationPath,
      `${JSON.stringify(candidate, null, 2)}
`,
      384
    );
    await rm2(plan.pendingInstallationPath, { force: true });
    await removeInactiveInstallations(plan);
    return { activated: true, version: plan.version };
  });
}
function activeInstallationFor(plan) {
  const launcher = launcherContent(plan.nativeHostBundle, plan.installationSha256, plan.version);
  return {
    version: plan.version,
    installationSha256: plan.installationSha256,
    pluginRoot: plan.pluginRoot,
    bundleSha256: plan.bundleSha256,
    launcherSha256: createHash2("sha256").update(launcher).digest("hex"),
    manifest: plan.manifest
  };
}
async function readActiveInstallation(plan) {
  return readInstallationState(plan.activeInstallationPath, plan, "active");
}
async function readPendingInstallation(plan) {
  return readInstallationState(plan.pendingInstallationPath, plan, "pending");
}
async function readInstallationState(path, plan, label) {
  const content = await readFile3(path, "utf8").catch((error) => {
    if (isMissingFileError(error)) return void 0;
    throw error;
  });
  if (content === void 0) return void 0;
  try {
    const active = JSON.parse(content);
    if (!validActiveInstallation(active, plan)) throw new Error("invalid active installation");
    return active;
  } catch {
    throw new PluginUserError(
      `Browser ${label} activation state is invalid. Reinstall the plugin or remove the Browser setup.`
    );
  }
}
async function removeOwnedInstallationState(path, installation, plan) {
  if (installation?.installationSha256 === plan.installationSha256 && pathsEqual(installation.pluginRoot, plan.pluginRoot)) {
    await rm2(path, { force: true });
  }
}
function validActiveInstallation(active, plan) {
  const versionsRoot = resolve2(plan.installRoot, "versions");
  const launcherPath = active && typeof active === "object" && typeof active.manifest?.path === "string" ? resolve2(active.manifest.path) : void 0;
  const expectedVersionDirectory = typeof active?.version === "string" && typeof active?.installationSha256 === "string" ? resolve2(versionsRoot, `${active.version}-${active.installationSha256}`) : void 0;
  const expectedLauncher = expectedVersionDirectory ? resolve2(
    expectedVersionDirectory,
    process.platform === "win32" ? "native-host.bat" : "native-host"
  ) : void 0;
  try {
    if (typeof active?.version === "string") parsePluginVersion(active.version);
    else return false;
  } catch {
    return false;
  }
  return typeof active?.version === "string" && typeof active.installationSha256 === "string" && /^[0-9a-f]{64}$/.test(active.installationSha256) && typeof active.bundleSha256 === "string" && /^[0-9a-f]{64}$/.test(active.bundleSha256) && typeof active.launcherSha256 === "string" && /^[0-9a-f]{64}$/.test(active.launcherSha256) && typeof active.pluginRoot === "string" && isAbsolute3(active.pluginRoot) && launcherPath !== void 0 && expectedLauncher !== void 0 && pathsEqual(launcherPath, expectedLauncher) && Object.keys(active).length === 6 && Object.keys(active.manifest).length === 5 && active.manifest.name === plan.hostName && active.manifest.description === plan.manifest.description && active.manifest.type === "stdio" && Array.isArray(active.manifest.allowed_origins) && active.manifest.allowed_origins.length === 1 && active.manifest.allowed_origins[0] === plan.manifest.allowed_origins[0];
}
async function removeInactiveInstallations(plan) {
  const versionsRoot = resolve2(plan.installRoot, "versions");
  const entries = await readdir(versionsRoot, { withFileTypes: true }).catch((error) => {
    if (isMissingFileError(error)) return [];
    throw error;
  });
  await Promise.allSettled(
    entries.filter((entry) => entry.isDirectory()).map((entry) => resolve2(versionsRoot, entry.name)).filter((path) => !pathsEqual(path, plan.versionDirectory)).map((path) => rm2(path, { recursive: true, force: true }))
  );
}
async function applyRegistration(plan, manifest) {
  const manifestContent = `${JSON.stringify(manifest, null, 2)}
`;
  for (const manifestPath of plan.manifestPaths) {
    await writeFileAtomically(manifestPath, manifestContent, 384);
  }
  if (plan.registryKey) {
    await execFileAsync2(
      "reg.exe",
      ["add", plan.registryKey, "/ve", "/t", "REG_SZ", "/d", plan.manifestPaths[0], "/f"],
      { windowsHide: true }
    );
  }
}
async function withActivationLock(plan, operation) {
  await mkdir2(plan.installRoot, { recursive: true, mode: 448 });
  const deadline = Date.now() + ACTIVATION_LOCK_WAIT_MS;
  const owner = { pid: process.pid, token: randomUUID2(), createdAt: Date.now() };
  const ownerPath = join4(plan.activationLockPath, "owner.json");
  while (true) {
    try {
      await mkdir2(plan.activationLockPath);
      try {
        await writeFile2(ownerPath, `${JSON.stringify(owner)}
`, { mode: 384 });
      } catch (error) {
        await rm2(plan.activationLockPath, { recursive: true, force: true });
        throw error;
      }
      break;
    } catch (error) {
      if (!isFileSystemError2(error, "EEXIST")) throw error;
      if (await removeAbandonedActivationLock(plan.activationLockPath)) {
        continue;
      }
      if (Date.now() >= deadline) {
        throw new PluginUserError("Browser activation is already in progress.");
      }
      await delay(50);
    }
  }
  try {
    return await operation();
  } finally {
    const currentOwner = await readLockOwner(ownerPath);
    if (currentOwner?.token === owner.token) {
      await rm2(plan.activationLockPath, { recursive: true, force: true });
    }
  }
}
async function removeAbandonedActivationLock(lockPath) {
  const ownerPath = join4(lockPath, "owner.json");
  const [owner, lock] = await Promise.all([
    readLockOwner(ownerPath),
    stat2(lockPath).catch(() => void 0)
  ]);
  if (owner) {
    if (processIsAlive(owner.pid)) return false;
  } else if (lock === void 0 || Date.now() - lock.mtimeMs < ACTIVATION_LOCK_STALE_MS) {
    return false;
  }
  const abandonedPath = `${lockPath}.${owner?.token ?? randomUUID2()}.abandoned`;
  try {
    await rename2(lockPath, abandonedPath);
  } catch (error) {
    if (isFileSystemError2(error, "ENOENT") || isFileSystemError2(error, "EEXIST")) return false;
    throw error;
  }
  await rm2(abandonedPath, { recursive: true, force: true });
  return true;
}
async function readLockOwner(path) {
  try {
    const owner = JSON.parse(await readFile3(path, "utf8"));
    return Number.isSafeInteger(owner?.pid) && owner.pid > 0 && typeof owner.token === "string" && Number.isSafeInteger(owner.createdAt) ? owner : void 0;
  } catch {
    return void 0;
  }
}
function processIsAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return isFileSystemError2(error, "EPERM");
  }
}
async function runDeactivationCli(args) {
  try {
    if (!parseArguments(args, "deactivate")) return;
    const plan = await createRegistrationPlan();
    const removedRegistration = await deactivateBrowserRegistration(plan);
    console.log("Copilot Browser deactivation complete.");
    console.log(
      removedRegistration ? "Browser setup owned by this installation was removed." : "No Browser registration owned by this installation was removed."
    );
    console.log(
      "A Browser runtime that is already running may remain available until the browser disconnects."
    );
  } catch (error) {
    reportError(error);
  }
}
async function deactivateBrowserRegistration(plan) {
  return withActivationLock(plan, async () => {
    let removedRegistryKey = false;
    if (plan.registryKey) {
      const registeredManifest = await readRegistryDefaultValue(plan.registryKey);
      if (registeredManifest && pathsEqual(registeredManifest, plan.manifestPaths[0]) && await manifestFileMatchesPlan(registeredManifest, plan)) {
        await execFileAsync2("reg.exe", ["delete", plan.registryKey, "/f"], {
          windowsHide: true
        });
        removedRegistryKey = true;
      }
    }
    const removedManifests = await Promise.all(
      plan.manifestPaths.map((path) => removeOwnedManifest(path, plan))
    );
    const removedRegistration = removedRegistryKey || removedManifests.some(Boolean);
    await Promise.all([
      removeOwnedInstallationState(
        plan.activeInstallationPath,
        await readActiveInstallation(plan).catch(() => void 0),
        plan
      ),
      removeOwnedInstallationState(
        plan.pendingInstallationPath,
        await readPendingInstallation(plan).catch(() => void 0),
        plan
      )
    ]);
    return removedRegistration;
  });
}
function parseArguments(args, command) {
  if (args.length === 1 && (args[0] === "--help" || args[0] === "-h")) {
    console.log(`Usage: node ${command}.mjs`);
    return false;
  }
  if (args.length > 0) throw new PluginUserError(`Usage: node ${command}.mjs`);
  return true;
}
async function installNativeHostBundle(plan) {
  const source = await readRequiredFile(plan.sourceNativeHostBundle);
  const sourceSha256 = createHash2("sha256").update(source).digest("hex");
  if (sourceSha256 !== plan.bundleSha256) {
    throw new PluginUserError(
      "Plugin files changed while activation was running. Run activation again."
    );
  }
  const installed = await readFile3(plan.nativeHostBundle).catch((error) => {
    if (isMissingFileError(error)) return void 0;
    throw error;
  });
  if (installed !== void 0) {
    const installedSha256 = createHash2("sha256").update(installed).digest("hex");
    if (installedSha256 === plan.bundleSha256) return;
  }
  await writeFileAtomically(plan.nativeHostBundle, source, 384);
}
async function writeFileIfChanged(path, content, mode) {
  const current = await readFile3(path, "utf8").catch((error) => {
    if (isMissingFileError(error)) return void 0;
    throw error;
  });
  if (current !== content || !await launcherIsExecutable(path)) {
    await writeFileAtomically(path, content, mode);
  }
}
async function removeOwnedManifest(path, plan) {
  try {
    const manifest = JSON.parse(await readFile3(path, "utf8"));
    if (manifestMatchesPlan(manifest, plan)) {
      await rm2(path, { force: true });
      return true;
    }
    return false;
  } catch (error) {
    if (isMissingFileError(error)) return false;
    throw error;
  }
}
async function manifestFileMatchesPlan(path, plan) {
  try {
    return manifestMatchesPlan(JSON.parse(await readFile3(path, "utf8")), plan);
  } catch (error) {
    if (isMissingFileError(error)) return false;
    throw error;
  }
}
async function writeFileAtomically(path, content, mode) {
  await mkdir2(dirname2(path), { recursive: true, mode: 448 });
  const temporaryPath = `${path}.${process.pid}.${randomUUID2()}.tmp`;
  try {
    await writeFile2(temporaryPath, content, { mode });
    await rename2(temporaryPath, path);
  } finally {
    await rm2(temporaryPath, { force: true });
  }
}
function isFileSystemError2(error, code) {
  return error !== null && typeof error === "object" && "code" in error && error.code === code;
}
function reportError(error) {
  console.error(
    `[copilot-browser] ${error instanceof PluginUserError ? error.message : "Browser setup could not complete. Reinstall the plugin or try again."}`
  );
  process.exitCode = 1;
}
export {
  activateBrowserRegistration,
  createRegistrationPlan,
  installNativeHostBundle,
  readActiveInstallation,
  readPendingInstallation,
  runActivationCli,
  runDeactivationCli,
  runSessionStartActivation,
  waitForBrowserConnection
};
