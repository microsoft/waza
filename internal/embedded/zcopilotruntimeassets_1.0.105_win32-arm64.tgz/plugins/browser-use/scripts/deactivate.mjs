#!/usr/bin/env node
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

import { runDeactivationCli } from "./nativeMessagingRegistration.mjs";

await runDeactivationCli(process.argv.slice(2));
