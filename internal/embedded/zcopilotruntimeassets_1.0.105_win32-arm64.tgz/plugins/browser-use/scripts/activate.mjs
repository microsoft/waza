#!/usr/bin/env node
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

import {
    runActivationCli,
    runSessionStartActivation,
    waitForBrowserConnection,
} from "./nativeMessagingRegistration.mjs";

const args = process.argv.slice(2);
const sessionStart = args.length === 1 && args[0] === "--session-start";
if (sessionStart) {
    const activated = await runSessionStartActivation();
    if (activated) {
        await waitForBrowserConnection();
    }
    process.exitCode = 0;
} else {
    const activated = await runActivationCli(args);
    if (activated) {
        const connected = await waitForBrowserConnection();
        console.log(
            connected
                ? "Browser runtime connected with a compatible RPC version."
                : "Browser runtime not connected. Run /browser-use:doctor for details.",
        );
    }
}
