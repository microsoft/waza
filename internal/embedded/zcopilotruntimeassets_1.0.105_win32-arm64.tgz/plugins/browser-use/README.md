# GitHub Copilot Browser

This is the production release of the GitHub Copilot Browser extension and Browser Use Copilot CLI
plugin. The browser extension and plugin are published as separate artifacts and must use the same
product version.

## Prerequisites

- Node.js 22 or later; confirm that `node --version` works in a terminal.
- Google Chrome or Microsoft Edge 127 or later.
- GitHub Copilot CLI with plugin support and an account that can use it.

## 1. Install the browser extension

Install **GitHub Copilot** from the
[Chrome Web Store](https://chromewebstore.google.com/detail/github-copilot/hblomdgalaelcilcdepgohfcogjiijhe).
Browser confirmation is required; the Copilot plugin does not install the extension or grant its
permissions automatically.

The same Chrome Web Store listing supports Microsoft Edge. If Edge prompts you, select **Allow
extensions from other stores**, confirm the choice, and then add the extension. A separate Microsoft
Edge Add-ons listing is not currently required.

If the extension is already installed, confirm that it is enabled. The production release does not
use an unpacked extension.

## 2. Install the Copilot CLI plugin

Until the Copilot plugin marketplace entry is available:

1. Extract the production plugin ZIP.
2. Start Copilot CLI.
3. Run `/plugin install <absolute-path-to-the-extracted-plugin-directory>`.
4. Start a new Copilot CLI session.

The plugin's `sessionStart` hook activates Browser registration automatically. To use Browser
immediately in the current session, run `/browser-use:doctor` first and follow its
reported next action. Use `/browser-use:activate` only when diagnostics recommend
activation or when you explicitly need to make this installation active.

## 3. Verify setup

Run `/browser-use:doctor` for read-only installation and connectivity diagnostics.

If the extension is not connected:

- follow the `browser-extension` check's installation or enablement guidance;
- confirm that Chrome or Edge is open;
- run `/browser-use:activate` when Browser registration is incomplete;
- restart the browser when diagnostics report an inactive Browser runtime.

The plugin does not infer that the extension is missing solely because no Native Host is connected.

## 4. Use Browser

Ask Copilot to complete a task in the browser. The `browser-use` skill loads automatically when live
browser interaction is needed. Review browser prompts and approve only requests you initiated.
Complete sign-in and other sensitive steps yourself.

Advanced Page Surfaces is available as a default-Off experimental setting in production builds.
Open the extension's **Manage** page to enable it for new Browser Connections when a task needs
approved iframe or closed Shadow Root access.

## Replace or uninstall

1. Close browser tasks that are still using this installation.
2. Run `/browser-use:deactivate`.
3. Run `/plugin uninstall browser-use`.
4. Remove the browser extension only if you no longer want to use GitHub Copilot Browser.
