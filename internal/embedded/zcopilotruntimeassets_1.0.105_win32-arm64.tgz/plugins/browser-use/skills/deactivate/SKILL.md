---
name: deactivate
description: Deactivate the Browser Use plugin before uninstalling or replacing this installation.
---

Perform a controlled deactivation of this Browser Use plugin installation before it is
uninstalled or replaced.

Resolve `../../scripts/deactivate.mjs` relative to this skill's directory and run exactly:

```text
node <absolute-path-to-deactivate.mjs>
```

Report whether deactivation succeeded. Do not use Browser tools after deactivation.

Deactivation affects only this plugin installation. Other Copilot Browser installations are not
changed.

Active Copilot CLI, VS Code, IntelliJ, or other agent sessions do not prevent deactivation. If the
subsequent plugin uninstall or replacement reports files in use, ask the user to close those
sessions and retry the uninstall or replacement. Never stop the current agent host, CLI, IDE,
language server, or MCP processes, and never terminate processes in bulk by executable name.