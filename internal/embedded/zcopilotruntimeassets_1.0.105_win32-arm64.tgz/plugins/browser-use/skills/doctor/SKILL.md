---
name: doctor
description: Diagnose Copilot Browser installation, setup, or connectivity problems without changing state.
---

Run a read-only diagnostic assessment of this Browser Use plugin installation.

First run `node --version`. Node.js 22 or later is required by this plugin for Browser
diagnostics. If Node.js is unavailable or older than 22, report the prerequisite and stop.

Resolve `../../scripts/doctor.mjs` relative to this skill's directory and run:

```text
node <absolute-path-to-doctor.mjs> --json
```

Keep diagnostics read-only. After the script completes, use `list_browser` to check connectivity.
Summarize the result instead of reproducing the diagnostic output. When `list_browser` returns no
instances, use the diagnostic check IDs to identify the failing layer:

- `browser-prerequisite`: install or update Chrome/Edge when this check fails;
- `browser-extension`: follow the check's channel-specific installation or enablement guidance when
  it warns or fails. Preserve any reported installation URL exactly; do not invent or substitute a
  store link when the check does not provide one;
- `browser-extension-version`: update the Extension when it is older; upgrade or restart
  the plugin session when the Extension is newer;
- `active-installation`: run `/browser-use:activate` when the active setup is absent or
  older; upgrade or restart the current plugin session when it is older than the active setup;
- `browser-runtime-processes`: restart Chrome or Edge when an inactive Browser runtime is still
  running;
- Browser setup checks: run `/browser-use:activate` when registration is incomplete;
- otherwise, open or restart Chrome/Edge and retry after the Extension connects.

Report the outcome under these headings:

- **Installation**: report whether the plugin is ready to use.
- **Connectivity**: report whether a browser connection is available.
- **Next action**: provide one concrete remediation for each warning or failure. Recommend
  `/browser-use:activate` when setup is incomplete. Do not perform repairs automatically.

When diagnostics report plugin files in use, report that active agent sessions must be closed before
uninstalling or replacing this installation. Do not terminate those processes automatically.
