import { createSessionRpc } from "./generated/rpc.js";
import type { ModelSwitchAutoTierResult } from "./generated/rpc.js";
import type { OpenCanvasInstance } from "./generated/rpc.js";
import type { MessageOptions, ResponseSchema, ContextTier, ReasoningEffort, ReasoningSummary, AutoTier, ModelCapabilitiesOverride, SessionCapabilities, SessionConfig, SessionEvent, SessionEventHandler, SessionEventType, SessionUiApi, TranscriptRecovery, TypedSessionEventHandler } from "./types.js";
import { type SessionWorkflowApi } from "./workflow.js";
/** Assistant message event - the final response from the assistant. */
export type AssistantMessageEvent = Extract<SessionEvent, {
    type: "assistant.message";
}>;
/**
 * Represents a single conversation session with the Copilot CLI.
 *
 * A session maintains conversation state, handles events, and manages tool execution.
 * Sessions are created via {@link CopilotClient.createSession} or resumed via
 * {@link CopilotClient.resumeSession}.
 *
 * @example
 * ```typescript
 * const session = await client.createSession({ model: "gpt-4" });
 *
 * // Subscribe to events
 * session.on((event) => {
 *   if (event.type === "assistant.message") {
 *     console.log(event.data.content);
 *   }
 * });
 *
 * // Send a message and wait for completion
 * await session.sendAndWait({ prompt: "Hello, world!" });
 *
 * // Clean up
 * await session.disconnect();
 * ```
 */
/**
 * Fixed name of the runtime's built-in tool-search tool. A client can replace
 * its behavior by registering a {@link Tool} with this exact name and
 * `overridesBuiltInTool: true`.
 */
export declare class CopilotSession {
    readonly sessionId: string;
    private connection;
    private _workspacePath?;
    private _transcriptRecovery?;
    private eventHandlers;
    private typedEventHandlers;
    private toolHandlers;
    /** Settles once every earlier `setTools` call has finished. */
    private setToolsQueue;
    private pendingExternalTools;
    private canvases;
    private bearerTokenProviders;
    private commandHandlers;
    private workflows;
    private workflowAbortControllers;
    private permissionHandler?;
    private mcpAuthHandler?;
    private userInputHandler?;
    private elicitationHandler?;
    private exitPlanModeHandler?;
    private autoModeSwitchHandler?;
    private skillProvider?;
    private hooks?;
    private transformCallbacks?;
    private _rpc;
    private _internalRpc;
    private traceContextProvider?;
    private readonly managedSettingsEnabled;
    private _capabilities;
    private openCanvasInstances;
    private disconnected;
    private readonly pendingResponseWaits;
    private readonly pendingStructuredWaits;
    private completionRpcUnsupported;
    private disconnecting;
    private onDisconnected?;
    /**
     * Friendly workflow API for running registered workflows by name or handle.
     *
     * @experimental Part of the experimental Dynamic Workflows surface and may
     * change or be removed in future SDK or CLI releases.
     */
    readonly workflow: SessionWorkflowApi;
    private settleWorkflowRun;
    /**
     * Resolve when a workflow run reaches a terminal status.
     *
     * The subscription is installed *before* the first read so a transition
     * landing between the two cannot be missed, and re-reads are serialized so
     * overlapping invalidation events cannot interleave — the run's revision
     * advances once per operation, so a burst of events is common and must
     * collapse into a single in-flight read. A bounded periodic re-read keeps a
     * dropped invalidation from leaving the wait pending forever.
     */
    private waitForWorkflowRun;
    /**
     * Typed session-scoped RPC methods.
     */
    get rpc(): ReturnType<typeof createSessionRpc>;
    /**
     * Path to the session workspace directory when infinite sessions are enabled.
     * Contains checkpoints/, plan.md, and files/ subdirectories.
     * Undefined if infinite sessions are disabled.
     */
    get workspacePath(): string | undefined;
    /** Recovery observed while loading this session; undefined on a clean resume. */
    get transcriptRecovery(): TranscriptRecovery | undefined;
    /**
     * Host capabilities reported when the session was created or resumed.
     * Use this to check feature support before calling capability-gated APIs.
     */
    get capabilities(): SessionCapabilities;
    /**
     * Interactive UI methods for showing dialogs to the user.
     * Only available when the CLI host supports elicitation
     * (`session.capabilities.ui?.elicitation === true`).
     *
     * @example
     * ```typescript
     * if (session.capabilities.ui?.elicitation) {
     *   const ok = await session.ui.confirm("Deploy to production?");
     * }
     * ```
     */
    get ui(): SessionUiApi;
    /**
     * Sends a message to this session and returns once it is admitted.
     *
     * The message is processed asynchronously. Subscribe to events via {@link on}
     * to receive streaming responses and other session events.
     *
     * @param options - The message options including the prompt and optional attachments
     * @returns The submitted user message's ID, not an assistant response ID.
     *          When this send starts a run, root assistant messages carry it as originatingMessageId.
     * @throws Error if the session has been disconnected or the connection fails
     *
     * @example
     * ```typescript
     * const messageId = await session.send({
     *   prompt: "Explain this code",
     *   attachments: [{ type: "file", path: "./src/index.ts" }]
     * });
     * ```
     */
    send(prompt: string): Promise<string>;
    send(options: MessageOptions): Promise<string>;
    private sendMessage;
    private createSendParams;
    /**
     * Sends a message and waits for its response to complete.
     *
     * Supported local runtimes correlate completion and the response with this
     * message. Unsupported runtimes retain the legacy non-Autopilot `session.idle`
     * or request-correlated `session.autopilot_stopped` wait. Autopilot completion
     * does not wait for or stop attached shells.
     *
     * Events are still delivered to handlers registered via {@link on} while waiting.
     * Sub-agent events with a non-empty `agentId` do not complete the wait or supply its reply.
     * With a schema as the second argument, returns its parsed, validated result.
     * Structured waits select only root-agent output originating from this send;
     * other queued work may delay session.idle but cannot replace the result.
     *
     * @param options - The message options including the prompt and optional attachments
     * @param timeout - Timeout in milliseconds (default: 60000). Controls how long to wait; does not abort in-flight agent work.
     * @returns A promise that resolves with this message's final assistant response,
     *          or undefined if no assistant message was received
     * @throws Error if the run is aborted before completion
     * @throws Error if the timeout is reached before completion
     * @throws Error if the session has been disconnected or the connection fails
     *
     * @example
     * ```typescript
     * // Send and wait for completion with default 60s timeout
     * const response = await session.sendAndWait({ prompt: "What is 2+2?" });
     * console.log(response?.data.content); // "4"
     * ```
     */
    sendAndWait(prompt: string, timeout?: number): Promise<AssistantMessageEvent | undefined>;
    sendAndWait<TResult>(options: MessageOptions | string, responseSchema: ResponseSchema<TResult>, timeout?: number): Promise<TResult>;
    sendAndWait(options: MessageOptions, timeout?: number): Promise<AssistantMessageEvent | undefined>;
    private sendWithCompletion;
    private sendAndWaitForStructuredMessage;
    private assertConnected;
    /**
     * Subscribes to events from this session.
     *
     * Events include assistant messages, tool executions, errors, and session state changes.
     * Multiple handlers can be registered and will all receive events.
     *
     * @param eventType - The specific event type to listen for (e.g., "assistant.message", "session.idle")
     * @param handler - A callback function that receives events of the specified type
     * @returns A function that, when called, unsubscribes the handler
     *
     * @example
     * ```typescript
     * // Listen for a specific event type
     * const unsubscribe = session.on("assistant.message", (event) => {
     *   console.log("Assistant:", event.data.content);
     * });
     *
     * // Later, to stop receiving events:
     * unsubscribe();
     * ```
     */
    on<K extends SessionEventType>(eventType: K, handler: TypedSessionEventHandler<K>): () => void;
    /**
     * Subscribes to all events from this session.
     *
     * @param handler - A callback function that receives all session events
     * @returns A function that, when called, unsubscribes the handler
     *
     * @example
     * ```typescript
     * const unsubscribe = session.on((event) => {
     *   switch (event.type) {
     *     case "assistant.message":
     *       console.log("Assistant:", event.data.content);
     *       break;
     *     case "session.error":
     *       console.error("Error:", event.data.message);
     *       break;
     *   }
     * });
     *
     * // Later, to stop receiving events:
     * unsubscribe();
     * ```
     */
    on(handler: SessionEventHandler): () => void;
    private upsertOpenCanvasFromEvent;
    private removeOpenCanvasFromEvent;
    private removeOpenCanvas;
    private upsertOpenCanvas;
    private _claimExternalTool;
    /**
     * Snapshot of canvas instances currently known to be open for this session.
     * Populated from the `session.resume` response and live `session.canvas.opened`
     * and `session.canvas.closed` events. Returns a defensive copy — mutating the
     * returned array has no effect on the session.
     */
    get openCanvases(): OpenCanvasInstance[];
    private assertElicitation;
    private _elicitation;
    private _confirm;
    private _select;
    private _input;
    private requireSkillProvider;
    /**
     * Runs a provider call with an abort signal tied to the runtime's request
     * cancellation. Failures are logged locally and reported generically.
     */
    private callSkillProvider;
    /**
     * Retrieves all events and messages from this session's history.
     *
     * This returns the complete conversation history including user messages,
     * assistant responses, tool executions, and other session events.
     *
     * @returns A promise that resolves with an array of all session events
     * @throws Error if the session has been disconnected or the connection fails
     *
     * @example
     * ```typescript
     * const events = await session.getEvents();
     * for (const event of events) {
     *   if (event.type === "assistant.message") {
     *     console.log("Assistant:", event.data.content);
     *   }
     * }
     * ```
     */
    getEvents(): Promise<SessionEvent[]>;
    /**
     * Disconnects this session and releases all in-memory resources (event handlers,
     * tool handlers, permission handlers).
     *
     * Session state on disk (conversation history, planning state, artifacts) is
     * preserved, so the conversation can be resumed later by calling
     * {@link CopilotClient.resumeSession} with the session ID. To permanently
     * remove all session data including files on disk, use
     * {@link CopilotClient.deleteSession} instead.
     *
     * After calling this method, the session object can no longer be used.
     *
     * @returns A promise that resolves when the session is disconnected
     * @throws Error if the connection fails
     *
     * @example
     * ```typescript
     * // Clean up when done — session can still be resumed later
     * await session.disconnect();
     * ```
     */
    disconnect(): Promise<void>;
    /** Enables `await using session = ...` syntax for automatic cleanup. */
    [Symbol.asyncDispose](): Promise<void>;
    /**
     * Aborts the currently processing message in this session.
     *
     * Use this to cancel a long-running request. The session remains valid
     * and can continue to be used for new messages.
     *
     * @returns A promise that resolves when the abort request is acknowledged
     * @throws Error if the session has been disconnected or the connection fails
     *
     * @example
     * ```typescript
     * // Start a long-running request
     * const messagePromise = session.send({ prompt: "Write a very long story..." });
     *
     * // Abort after 5 seconds
     * setTimeout(async () => {
     *   await session.abort();
     * }, 5000);
     * ```
     */
    abort(): Promise<void>;
    /**
     * Change the model for this session.
     * The new model takes effect for the next message. Conversation history is preserved.
     *
     * @param model - Model ID to switch to
     * @param options - Optional settings for the new model
     *
     * @example
     * ```typescript
     * await session.setModel("gpt-5.4");
     * await session.setModel("claude-sonnet-4.6", { reasoningEffort: "high" });
     *
     * // Select the Auto model and its routing preference in one call.
     * await session.setModel("auto", { autoTier: "intelligence" });
     * ```
     */
    setModel(model: string, options?: {
        reasoningEffort?: ReasoningEffort;
        reasoningSummary?: ReasoningSummary;
        contextTier?: ContextTier;
        modelCapabilities?: ModelCapabilitiesOverride;
        /**
         * Routing preference to apply when `model` is `auto`.
         *
         * Pass `null` to return to the provider's default Auto routing. The
         * runtime rejects this option when `model` is anything other than
         * `auto`; use {@link setAutoTier} to change the preference without
         * changing the selected model.
         *
         * @experimental Part of an experimental Auto routing surface and may
         * change or be removed in a future release.
         */
        autoTier?: AutoTier | null;
    }): Promise<void>;
    /**
     * Change the Auto routing preference without changing the selected model.
     *
     * The runtime does not apply the preference immediately. It records the
     * request and commits it only when a later user turn using the `auto` model
     * successfully obtains a usable model from the provider. A `pending` status
     * therefore confirms that the request was accepted, not that it took effect.
     *
     * Watch for the outcome through the `session.model_change` event on success,
     * or the ephemeral `session.auto_tier_switch_failed` event on failure. You
     * can also read the current committed and in-flight state at any time with
     * `session.rpc.model.getCurrent()`.
     *
     * Only the most recent request survives: issuing a new request replaces any
     * earlier one that has not yet been claimed by a turn.
     *
     * @param autoTier - Routing preference to activate, or `null` to return to
     *   the provider's default Auto routing
     * @returns The runtime's immediate acknowledgement and Auto preference snapshot
     *
     * @experimental Part of an experimental Auto routing surface and may change
     * or be removed in a future release.
     *
     * @example
     * ```typescript
     * const result = await session.setAutoTier("intelligence");
     * if (result.status === "pending") {
     *     // Takes effect on a later turn that uses the `auto` model.
     * }
     * ```
     */
    setAutoTier(autoTier: AutoTier | null): Promise<ModelSwitchAutoTierResult>;
    /**
     * Replace the tools this client supplies to the session.
     *
     * `tools` becomes the complete set of tools this client implements,
     * replacing the ones it supplied when the session was created or resumed,
     * or in an earlier call. Built-in, MCP, and plugin tools, and tools other
     * connected clients supply, are unaffected. Pass an empty array to remove
     * all of this client's tools.
     *
     * Tools are defined the same way as for `createSession`: calls to tools
     * with a `handler` are dispatched to it, and tools without one are
     * declaration-only. Once the runtime accepts the replacement, every tool
     * call this session dispatches uses the new handlers; calls already
     * running finish on their original handlers. If the runtime rejects the
     * replacement, this rejects and the previous tools and handlers stay in
     * place. Concurrent calls on the same session are applied one at a time,
     * in the order they are made.
     *
     * The agent sees the new tools from its next model request, which can fall
     * within a turn in progress. A model request already in flight was made
     * with the previous tools, so the agent can still call a tool you removed.
     * This session doesn't answer that call, and it can stay pending until the
     * turn is aborted. If a running turn might still call a tool you remove,
     * replace tools while the session is idle.
     *
     * @param tools - The complete set of tools this client supplies
     * @throws Error if the session disconnects before the replacement is applied
     *
     * @experimental Wraps the experimental `session.tools.set` RPC and may change
     * or be removed in a future release.
     *
     * @example
     * ```typescript
     * await session.setTools([
     *     defineTool("search_issues", {
     *         description: "Search the issues shown on the current page",
     *         parameters: z.object({ query: z.string() }),
     *         handler: async ({ query }) => searchIssues(query),
     *     }),
     * ]);
     * ```
     */
    setTools(tools: NonNullable<SessionConfig["tools"]>): Promise<void>;
    /**
     * Log a message to the session timeline.
     * The message appears in the session event stream and is visible to SDK consumers
     * and (for non-ephemeral messages) persisted to the session event log on disk.
     *
     * @param message - Human-readable message text
     * @param options - Optional log level and ephemeral flag
     *
     * @example
     * ```typescript
     * await session.log("Processing started");
     * await session.log("Disk usage high", { level: "warning" });
     * await session.log("Connection failed", { level: "error" });
     * await session.log("Debug info", { ephemeral: true });
     * ```
     */
    log(message: string, options?: {
        level?: "info" | "warning" | "error";
        ephemeral?: boolean;
    }): Promise<void>;
}
