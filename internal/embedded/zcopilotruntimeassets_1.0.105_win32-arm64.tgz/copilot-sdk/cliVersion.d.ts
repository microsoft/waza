export declare const COPILOT_CLI_VERSION = "0.0.0-dev";
export declare const COPILOT_CLI_USE_NPM_PACKAGE = false;
