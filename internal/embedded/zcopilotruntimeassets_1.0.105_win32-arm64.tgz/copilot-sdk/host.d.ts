import type { HostExitedNotification, HostPublishSessionResult, HostUnpublishSessionResult, HostListSessionsResult, HostLocalServerOptions, HostGitHubEnvironmentOptions } from "./generated/rpc.js";
import type { CopilotSession } from "./session.js";
import type { SessionConfig, ResumeSessionConfig } from "./types.js";
/** Verified host admission identity, independent of inference authentication. @experimental */
export type AhpSessionAuthentication = {
    mode: "github";
    identity: string;
} | {
    mode: "custom";
    identity: string;
} | {
    mode: "none";
};
/** Explicit host-wide admission policy. @experimental */
export type AhpHostAuthentication = {
    mode: "github";
} | {
    mode: "none";
} | {
    mode: "custom";
    /** Stable owner identity. Every accepted credential must match exactly. */
    requireIdentity: string;
    /** Receives a decrypted admission token, never used as an inference credential. */
    authenticate: (request: {
        token: string;
        signal: AbortSignal;
    }) => Promise<{
        identity: string;
        /** Required future RFC3339 expiration, enforced by the host. */
        expiresAt: string;
    } | null>;
};
/** Host-selected defaults for a fresh application-owned session. @experimental */
export interface AhpSessionCreateRequest {
    /** Trusted admission context supplied by the host, not by the connecting client. */
    authentication: AhpSessionAuthentication;
    /** Pass these settings to createSession, adding your prompt, tools and callbacks. */
    config: Omit<SessionConfig, "onPermissionRequest">;
    /** Aborted when participation ends, including timeout or owner disconnection. */
    signal: AbortSignal;
}
/** Host-selected settings for resuming a durable application-owned AHP session. @experimental */
export interface AhpSessionResumeRequest {
    /** Trusted admission context under the application's current host policy. */
    authentication: AhpSessionAuthentication;
    sessionId: string;
    /** Pass to resumeSession, adding application tools, hooks and callbacks. */
    config: Omit<ResumeSessionConfig, "onPermissionRequest">;
    /** Aborted when participation ends; late results are still released exactly once. */
    signal: AbortSignal;
}
/**
 * A listener-task exit report, or an owner disconnect that cannot acknowledge cleanup.
 * `reason: "exited"` means the hosting task failed, not that the runtime process died.
 * In-process hosts have no process exit code (`exitCode` is absent).
 * @experimental
 */
export type AhpHostExit = HostExitedNotification;
/**
 * Options for runtime-supervised AHP hosting. Select at least one transport.
 * Callbacks are captured at startup;
 * later changes to this options object do not reconfigure an existing host.
 * @experimental
 */
export interface AhpHostOptions {
    /** Required even in copilot-cli client mode. Anonymous access must be explicitly selected. */
    authentication: AhpHostAuthentication;
    /** Stable catalog identity; must agree with githubEnvironment.computeId when both are supplied. */
    computeId?: string;
    /**
     * Absolute directory on the runtime host to serve through AHP.
     * Defaults to the runtime's configured working directory; does not change process or session working directories.
     */
    workspace?: string;
    /** Enable a local WebSocket listener; an empty object selects loopback defaults. */
    localServer?: HostLocalServerOptions;
    /** Register a Mission Control environment and enable remote WPS connections; requires github authentication. */
    githubEnvironment?: HostGitHubEnvironmentOptions;
    /** Remote creation admission, independent of factories. Omitted means denied. */
    allowCreatingNewSessions?: boolean;
    /** Called at most once when hosting ends, not on runtime process death. Local, never serialized. */
    onExit?: (exit: AhpHostExit) => void;
    /**
     * Materialize a fresh session on this client. Preserve the supplied config
     * (including its sessionId and workingDirectory); add your own prompt and tools.
     * The callback and all tool/hook functions stay in the application.
     */
    createSession?: (request: AhpSessionCreateRequest) => Promise<CopilotSession>;
    /**
     * Resume a durable application-owned session, including a previously published session.
     * Return the original object from this client's resumeSession, or an existing
     * attached original without reconfiguring it. Published resident sessions
     * attach directly and never invoke this callback.
     */
    resumeSession?: (request: AhpSessionResumeRequest) => Promise<CopilotSession>;
    /**
     * Called once per handoff with the original returned object after AHP detaches
     * or the handoff fails. The SDK never disconnects or destroys this object.
     */
    onSessionReleased?: (session: CopilotSession) => void | Promise<void>;
}
/**
 * A connection-owned AHP listener supervised by the runtime.
 *
 * The runtime hosts the listener in-process, without a companion executable. Disconnecting
 * the owning client also stops the host; reconnecting does not reclaim it.
 * Stopping a host does not delete its underlying sessions.
 * Its durable AHP catalog is shared by successive hosts in the runtime's
 * effective Copilot home and compute identity; a concurrent host for that catalog is rejected.
 *
 * @experimental
 */
export declare class AhpHost {
    private readonly disposeHost;
    private readonly publishHostSession;
    private readonly listHostSessions;
    private readonly unpublishHostSession;
    private readonly updateCreationPolicy;
    readonly hostId: string;
    /** Local WebSocket URL. Absent when only the GitHub environment is enabled. */
    readonly url: string | undefined;
    /** Mission Control environment ID, when GitHub hosting is enabled. */
    readonly environmentId: string | undefined;
    /** Connection token, when required by the listener. Treat this value as a secret. */
    readonly token: string | undefined;
    /** Legacy separate host process ID. Absent for in-process listeners; use dispose() to stop. */
    readonly pid: number | undefined;
    /** Ask the runtime to stop the listener and await its cleanup, on every call. */
    dispose(): Promise<void>;
    /** Change subsequent remote admissions without disconnecting clients; admitted creation may finish. */
    setAllowCreatingNewSessions(allowed: boolean): Promise<void>;
    /** Publish an attached application session into the durable compute-scoped host catalog. */
    publishSession(sessionId: string): Promise<HostPublishSessionResult>;
    /**
     * Withdraw a live or dormant application publication and revoke AHP attachments.
     * Preserves local history, worktrees and ongoing work; returns false when already absent.
     * Rejects nonapplication publications. Does not stop the host.
     */
    unpublishSession(sessionId: string): Promise<HostUnpublishSessionResult>;
    /** List all live and dormant catalog sessions advertised by this host. */
    listSessions(): Promise<HostListSessionsResult>;
    [Symbol.asyncDispose](): Promise<void>;
}
